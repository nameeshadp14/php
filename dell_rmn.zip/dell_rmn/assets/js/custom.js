$(document).ready(function(){
	
	$('.progress').hide();
	jQuery.validator.addMethod("NoSpace", function(value, element) { 
		  return !value.startsWith(" ")&& value != ""; 
		}, "No space allowed start of the string");	
	
	jQuery.validator.addMethod("needsSelection", function (value, element) {
        var count = $(element).find('option:selected').length; return count > 0;  
    }, "Select atleast one value");
	
	jQuery.validator.addMethod("pwcheck", function(value,element) {
		   return /^([a-zA-Z0-9]{6,})$/.test(value) ;// consists of only these
		},'Please Enter at least 6 charecter');
//validating for alphanumeric and 0-9 numbers
	jQuery.validator.addMethod("alphanumeric", function(value, element) {
        return this.optional(element) || /^[a-zA-Z0-9]+$/.test(value);
	},'Please Enter only alphabets and 0-9 numbers'); 
	var appsite_url =$("#app_siteurl").attr("data-appsite_url");
//	Add User Email Validation
	jQuery.validator.addMethod("email", function(value, element) {
		  // allow any non-whitespace characters as the host part 
		  return this.optional( element ) || /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
		}, 'Please enter a valid email address.');
		  
// Scheduler report date
		  
		  $( "#sch_ed_date" ).datepicker(
			     { 
			        maxDate: '0', 
			        beforeShow : function()
			        	{
			                jQuery( this ).datepicker('option','minDate', jQuery('#sch_st_date').val() );
			            },
			            altFormat: "dd-mm-yy", 
			            dateFormat: "dd-mm-yy"
			        }
			);

			$( "#sch_st_date" ).datepicker( 
			        {
			            maxDate: '0', 
			            beforeShow : function()
			            {
			                jQuery( this ).datepicker('option','minDate');
			            } , 
			            altFormat: "dd-mm-yy", 
			            dateFormat: "dd-mm-yy"
			        }
			);
			
//Region report date
			$("#reg_st_date").datepicker({
				
				maxDate:'0',
				beforeShow:function(){
					jQuery(this).datepicker('option','minDate');
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
				
			});
			
			$("#reg_ed_date").datepicker({
				
				maxDate:'0',
				beforeShow: function(){
					jQuery(this).datepicker('option','minDate',jQuery('#reg_st_date').val());
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
				
			});
			
			
//Brand report date		
			
			$("#brd_st_date").datepicker({
				
				maxDate:'0',
				beforeShow:function()
				{
					jQuery(this).datepicker('option','minDate');
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
			});
			
			$("#brd_ed_date").datepicker({
				maxDate:'0',
				beforeShow: function()
				{
					jQuery(this).datepicker('option','minDate',jQuery('#brd_st_date').val());
				},
				altFormat: "dd-mm-yy", 
	            dateFormat: "dd-mm-yy"
			});
			
			
// city report date
          $("#city_st_date").datepicker({
				maxDate:'0',
				beforeShow:function()
				{
					jQuery(this).datepicker('option','minDate');
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
			});
          
		  $("#city_ed_date").datepicker({
				maxDate:'0',
				beforeShow: function()
				{
					jQuery(this).datepicker('option','minDate',jQuery('#city_st_date').val());
				},
				altFormat: "dd-mm-yy", 
	            dateFormat: "dd-mm-yy"
			});
			
// Asset report date	
			$( "#asset_date" ).datepicker( 
			        {
			            maxDate: '0', 
			            beforeShow : function()
			            {
			                jQuery( this ).datepicker('option','minDate' );
			            } , 
			            altFormat: "dd-mm-yy", 
			            dateFormat: "dd-mm-yy"
			        }
			);
			
			
// Store wise report
			$("#store_st_date").datepicker({
				
				maxDate:'0',
				beforeShow:function(){
					jQuery(this).datepicker('option','minDate');
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
				
			});
			
			$("#store_ed_date").datepicker({
				
				maxDate:'0',
				beforeShow: function(){
					jQuery(this).datepicker('option','minDate',jQuery('#store_st_date').val());
				},
				altFormat:"dd-mm-yy",
				dateFormat:"dd-mm-yy"
				
			});
			
			
//ASSET Handle Registered date and expirey date - vignesh - 19062018
	$('#asset_reg_date').datepicker({
		 useCurrent: false,
		 changeMonth: true,
		 changeYear: true,
		 dateFormat: 'dd/mm/yy',
		 minDate: 0,
		 onSelect: function () {
	       var dt2 = $('#asset_expiry_date');
		   var startDate = $(this).datepicker('getDate');
		   var minDate = $(this).datepicker('getDate');
		   var dt2Date = dt2.datepicker('getDate');
		   //difference in days. 86400 seconds in day, 1000 ms in second
		   var dateDiff = (dt2Date - minDate)/(86400 * 1000);
		   startDate.setDate(startDate.getDate() + 30);
		   if (dt2Date == null || dateDiff < 0) {
		   		dt2.datepicker('setDate', minDate);
		   }
		   else if (dateDiff > 30){
		   		dt2.datepicker('setDate', startDate);
		   }
		   //sets dt2 maxDate to the last day of 30 days window
		   dt2.datepicker('option', 'minDate', minDate);
	   }
	});
	$('#asset_expiry_date').datepicker({
		useCurrent: false,
		changeMonth: true,
	    changeYear: true,
	    dateFormat: 'dd/mm/yy',
		minDate: 0
	});
	
	$('#st__date').datepicker({
		 useCurrent: false,
		 changeMonth: true,
		 changeYear: true,
		 dateFormat: 'dd/mm/yy',
		 minDate: 0,
		 onSelect: function () {
	       var dt2 = $('#ed__date');
		   var startDate = $(this).datepicker('getDate');
		   var minDate = $(this).datepicker('getDate');
		   var dt2Date = dt2.datepicker('getDate');
		   //difference in days. 86400 seconds in day, 1000 ms in second
		   var dateDiff = (dt2Date - minDate)/(86400 * 1000);
		   startDate.setDate(startDate.getDate() + 30);
		   if (dt2Date == null || dateDiff < 0) {
		   		dt2.datepicker('setDate', minDate);
		   }
		   else if (dateDiff > 30){
		   		dt2.datepicker('setDate', startDate);
		   }
		   //sets dt2 maxDate to the last day of 30 days window
		   dt2.datepicker('option', 'minDate', minDate);
	   }
	});
	$('#ed__date').datepicker({
		useCurrent: false,
		changeMonth: true,
	    changeYear: true,
	    dateFormat: 'dd/mm/yy',
		
	});
	$('#asset_date').datepicker({
		useCurrent: false,
		changeMonth: true,
	    changeYear: true,
	    dateFormat: 'dd/mm/yy',
		
	});
	$('#sch_st_date').datepicker({
			useCurrent: false,
			changeMonth: true,
		    changeYear: true,
		    dateFormat: 'dd/mm/yy',
		
		});
	$('#sch_ed_date').datepicker({
		useCurrent: false,
		changeMonth: true,
	    changeYear: true,
	    dateFormat: 'dd/mm/yy',
		
	});
    
	$('#brd_st_date').datepicker({
		useCurrent:false,
		changeMonth:true,
		changeYear:true,
		dateFormat:'dd/mm/yy'
		
	});
	$('#brd_ed_date').datepicker({
		useCurrent:false,
		changeMonth:true,
		dateFormat:'dd/mm/yy'
		
	});

	//===========LOGIN FORM VALIDTION ==========
	$("#login_form").validate({
		rules: {
			email: {
				required: true,
				email: true,
				NoSpace :true
				
			},
			pass_word: "required",
		},
	});
	
	//===========REGION VALIDTION ==========
	$("#brand_management").validate({
		rules: {
			brand_name: {
				required: true,
				NoSpace :true
				
			},
			status: {
				required: true,
			},
		},
	});
	//===========REGION VALIDTION ==========
	$("#region_management").validate({
		rules: {
			region_name: {
				required: true,
				NoSpace :true
			},
		},
	});
	//===========REGION VALIDTION ==========
	$("#city_management").validate({
		rules: {
			city_name: {
				required: true,
				NoSpace :true
			},
			region: {
				required: true,
			},
		},
		messages: {
			region: {
				required: 'Select The region'
			}
		}
	});
	//===========STORE VALIDTION ==========
	$("#store_management").validate({
		rules: {
			store_name: {
				required: true,
				NoSpace :true
			},
			store_code: {
				required: true,
				NoSpace :true
			},
			store_email: {
				required: true,
				NoSpace :true,
				email :true
			},
			store_contact_email:{
				required: true,
				NoSpace :true,
				email :true
			},
			store_contact_number: {
				required: true,
				NoSpace :true
			},
			store_type: {
				required: true,
			},
			region_id: {
				required: true,
			},
		},
		
	});
	
	//===========MODEL VALIDTION ==========
	$("#model_management").validate({
		rules: {
			model_name: {
				required: true,
				NoSpace :true
			},
			status: {
				required: true,
			},
			brand_id: {
				required: true,
			},
		},
	});
	
	//===========MODEL VALIDTION ==========
	$("#asset_management").validate({
		rules: {
			asset_code: {
				required: true,
				NoSpace :true
			},
			model_id: {
				required: true,
			},
			asset_store_id: {
				required: true,
			},
			asset_status: {
				required: true,
			},
		},
	});
	//Conffirmation box for delete data	
	$(".remove_data").on('click',function(e){
	    e.preventDefault();
	    var link = $(this).attr('href');
		bootbox.confirm({
		    message: "Do you want delete this data?",
		    buttons: {
		        confirm: {
		            label: 'Confirm',
		            className: 'btn-success'
		        },
		        cancel: {
		            label: 'Cancel',
		            className: 'btn-danger'
		        }
		    },
		    callback: function (result) {
		        if(result==true){
		        	window.location.href = link;
		        }
		    }
		});
	});
	
	
	//COPY THE TYPE OF SUBMIT - VIGNESH - 13062018
	$(".video_btn_type").on('click',function(){
		$("#btn_type").val($(this).data("btnttype"));
	})
	//VIDEO PREVIEW  - VIGNESH - 13062018
	$('body').on("change", "#videofile", function(evt) {
		var $source = $('#preview_here');
		$source[0].src = URL.createObjectURL(this.files[0]);
		$source.parent()[0].load();
		$(".preview_video").css('display','block');
	});
	
	$("#videofile").change(function (){ 
		 $(".video_error").html(""); 
	     var iSize = ($("#videofile")[0].files[0].size / 1024); 
	     if (iSize / 1024 > 1) 
	     { 
	        if (((iSize / 1024) / 1024) > 1) 
	        { 
				$(".video_error").html("Size should be less then 15 MB"); 
				$("#videofile").val('');
	        }
	        else
	        { 
	            iSize = (Math.round((iSize / 1024) * 100) / 100)
				if(iSize > 15){
					$(".video_error").html("Size should be less then 15 MB"); 
					$("#videofile").val('');
				}
	           
	        } 
	     }else{
	    	 $(".video_error").html(""); 
	     } 
	   }); 

	//===========Video Validation ==========
	$("#video_management").validate({
		rules: {
			video_name: {
				required: true,
				NoSpace :true
			},
			status:{
				required: true,
			},
			videofile: {
			      required: true,
			      accept: "video/*"
			 }
		},
		submitHandler: function() {
			var cur_btntype=$("#btn_type").val();
			$('.myprogress').css('width', '0');
			$('.progress').show();
			$('.msg').text('');
			var filename = $('#video_name').val();
			var myfile = $('#myfile').val();
			var csrf_token = $('#dell_csrf_token_name').val();
			var video_status = $('#status').val();
			
			var formData = new FormData();
			formData.append('upload_video', $('#videofile')[0].files[0]);
			formData.append('video_name', filename);
			formData.append('video_status', video_status);
			formData.append('dell_csrf_token_name', csrf_token);
			$('#save_continue_btn').attr('disabled', 'disabled');
			$('#save_add_btn').attr('disabled', 'disabled');
			
			$.ajax({
					url: appsite_url+'video/add/',
					data: formData,
					processData: false,
					contentType: false,
					type: 'POST',
					// this part is progress bar
					xhr: function () {
					    var xhr = new window.XMLHttpRequest();
					    xhr.upload.addEventListener("progress", function (evt) {
					    	if (evt.lengthComputable) {
							    var percentComplete = evt.loaded / evt.total;
							    percentComplete = parseInt(percentComplete * 100);
							    $('.myprogress').text(percentComplete + '%');
							    $('.myprogress').css('width', percentComplete + '%');
					        }
					    }, false);
					    return xhr;
					},
					success: function (response) {
						$('.progress').hide();
						 var response_type = response.split(",");
						  if(response_type[0] == 1){
							  if(cur_btntype == 1){
								  $('.msg').html("<div class='alert alert-success alert-dismissible'>"+
										  "<p>Video uploaded successfully..You will redirect to edit</p>"+ 
							              "</div>");
										 setTimeout(function(){
											 window.location = appsite_url+"video/edit/"+response_type[1];
										 } ,3000);
							  }else{
								  $('.msg').html("<div class='alert alert-success alert-dismissible'>"+
										  "<p>Video uploaded successfully..Add a new video </p>"+
							              
							              "</div>");
										 setTimeout(function(){
											 window.location=appsite_url+'video/add/';
									} ,3000);
							  }
						  }else{
							    $('#save_continue_btn').attr('disabled', false);
								$('#save_add_btn').attr('disabled', false);
							    $('.msg').html("<div class='alert alert-danger alert-dismissible'>"+
						                "<p>Unable to upload the file..Try again..</p>"+
						              "</div>");
						  }
					}
			});
		}
	});
	
	$.validator.addMethod('filesize', function (value, element, param) {
	    return this.optional(element) || (element.files[0].size <= param)
	}, 'File size must be less than {0}');

	//===========Video Validation ==========
	$("#update_video_management").validate({
		rules: {
			video_name: {
				required: true,
				NoSpace :true
			},
			status:{
				required: true,
			},
			videofile: {
			      accept: "video/*",
			 }
		},
		submitHandler: function() {
			$('.progress').show();
			var cur_btntype=$("#btn_type").val();
			 $('.myprogress').css('width', '0');
			$('.msg').text('');
			var filename = $('#video_name').val();
			var myfile = $('#myfile').val();
			var csrf_token = $('#dell_csrf_token_name').val();
			var video_status = $('#status').val();
			var video_id = $('#video_id').val();
		
			var formData = new FormData();
			formData.append('upload_video', $('#videofile')[0].files[0]);
			formData.append('video_name', filename);
			formData.append('video_id', video_id);
			formData.append('video_status', video_status);
			formData.append('dell_csrf_token_name', csrf_token);
			$('#add_video_btn').attr('disabled', 'disabled');
//			$('.msg').text('Uploading in progress...');
			$.ajax({
					url: appsite_url+'video/edit/'+video_id,
					data: formData,
					processData: false,
					contentType: false,
					type: 'POST',
					// this part is progress bar
					xhr: function () {
					    var xhr = new window.XMLHttpRequest();
					    xhr.upload.addEventListener("progress", function (evt) {
					    	if (evt.lengthComputable) {
							    var percentComplete = evt.loaded / evt.total;
							    percentComplete = parseInt(percentComplete * 100);
							    $('.myprogress').text(percentComplete + '%');
							    $('.myprogress').css('width', percentComplete + '%');
					        }
					    }, false);
					    return xhr;
					},
					success: function (response) {
						$('.progress').hide();
						 var response_type = response.split(",");
						  if(response_type[0] == 1){
								  $('.msg').html("<div class='alert alert-success alert-dismissible'>"+
							                "<p>Video details updated successfully.</p>"+
							              "</div>");
										 setTimeout(function(){
											 window.location.reload();
									} ,3000);
						  }else{
							  $('.msg').html("<div class='alert alert-danger alert-dismissible'>"+
						                "<p>Unable to upload the file..Try again..</p>"+
						              "</div>");
						  }
					}
			});
		}
	});
	
	//COPY THE TYPE OF SUBMIT - VIGNESH - 13062018
	$(".video_btn_type").on('click',function(){
		$("#btn_type").val($(this).data("btnttype"));
	})
	
	//VIDEO PREVIEW  - VIGNESH - 13062018
	$('body').on("click", ".playlist_preview_video", function() {
		var $source = $('#preview_here');
		var video_url =$(this).attr("data-url");
		$source[0].src = appsite_url+'uploads/videos/'+video_url;
		$source.parent()[0].load();
		$(".preview_video").css('display','block');
	});
//========Automatically Preview the fist videos from the list================
	
	$('.checkboxes li:first .playlist_preview_video').click();
	//===========PLaylist VALIDTION ==========
	$("#playlist_management").validate({
		rules: {
			playlist_name: {
				required: true,
			},
			status: {
				required: true,
			},
		},
	});
	//===========REGION VALIDTION ==========
	$("#group_management").validate({
		rules: {
			'group_name': {
				required: true,
				NoSpace :true
			},
			'model_id[]': {
				required: true,
				needsSelection:true
			},
		},
		 ignore: ':hidden:not("#model_id")', // Tells the validator to check the hidden select
	});
	
	//===========schedular VALIDTION ==========
	$("#schedular_management").validate({
		
		rules: {
			'sch_name': {
				required: true,
				NoSpace :true
			},
			'sch_status': {
				required: true,
				needsSelection:true
			},
			'sch_type':{
				required: true,
				needsSelection:true
			},
			'region_id': {
				required:{
                    depends: function(element) {
	                   	 return($('#sch_type').val()=="" || $('#sch_type').val()=='1'||$('#region_id')!='');
	                }
				}
			},
			'store_id':{
				required:{
                    depends: function(element) {
                    	return($('#sch_type').val()=="" || $('#sch_type').val()=='2'||$('#store_id')!='');
	                }
				}
			},
			'group_id':{
				required:{
                    depends: function(element) {
                    	return($('#sch_type').val()=="" || $('#sch_type').val()=='3'||$('#group_id')!='');
	                }
				}
			},
			'st_date':{
				required: true,
			},
			'ed_date':{
				required: true,
			},
			'playlist_id[]': {
				required: true,
				needsSelection:true,
			},
		
		},
		 ignore: ':hidden:not("#playlist_id")', // Tells the validator to check the hidden select
		 
		
	});
	 
//====User management Validation===
	$("#user_management").validate({ 
		rules: {
			
			'user_name':{
				required: true,
				NoSpace :true
			},
			'email_id':{
				required: true,
				NoSpace :true,
				email :true
			},
			'user_password':{
				required: true,
				NoSpace :true,
				pwcheck:true,
			},
			
			'password':{
			required: true,
			NoSpace :true,
			pwcheck:true,
			},
			'cpassword':{
				required: true,
				NoSpace :true,
				pwcheck:true,
				equalTo: "#user_password",
			},
			'edit_password':{
				required: true,
				NoSpace :true,
				pwcheck:true,
				equalTo: "#user_password",
			},
			'user_role':{
				required: true,
			},
			'user_status':{
				required: true,
			},
			'region_type':{
				required: true,
				needsSelection:true
			},
			'region_select': {
				required:{
                    depends: function(element) {
	                   	 return($('#region_type').val()=="" || $('#region_type').val()=='4'||$('#region_select')!='');
	                }
				}
			},
		},
	});
	
	//===password======
	$("#password_management").validate({
		
          rules: {
			
			'old_password':{
				required: true,
				NoSpace :true,
				pwcheck:true,
				
			},
			'new_password':{
				required: true,
				NoSpace :true,
				pwcheck:true,
			},
			'conf_password':{
				required: true,
				NoSpace :true,
				pwcheck:true,
				equalTo: "#new_password",
			},
		},
		
	});
	
	//=======Keyup, it is using for playlists searching========
	$("#myInput").on("keyup", function() {
	    var value = $(this).val().toLowerCase();
	    $('.checkboxes .list-unstyled').filter(function() {
	    var x=$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	    	    
	    });
	  });
	  
	$("#sch_type").change(function(){
        $('#region,#store,#group').hide();
        $('#region_id').val('');
        $('#brand_id').val('');
        $('#group_id').val('');
        var value=$(this).val();
        if(value=='1'){
            $('#region').show();
        }else if(value=='2'){
            $('#store').show();
        }else if(value=='3'){
            $('#group').show();
        }
    });
	
	$("#region_type").change(function(){
        $('#region').hide();
        $('#region_select').val('');
      
        var value=$(this).val();
        if(value =='4'){          //the value of the region in the Dropdown
              $('#region').show();
        }
    });

    $("#sch_typeforedit").change(function(){
        $('#region,#store,#group').hide();
        var value=$(this).val();
        if(value=='1'){
            $('#region_id').val($('#reg_id_hdn').val());
            $('#region').show();
        }
        else if(value=='2'){
            $('#store_id').val($('#brnd_id_hdn').val());
            $('#store').show();
        }
        else if(value=='3'){
            $('#group_id').val($('#grp_id_hdn').val());
                   $('#group').show();
        }
    });
	
	
	
});

