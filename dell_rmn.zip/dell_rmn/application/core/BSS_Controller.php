<?php

class BSS_Controller extends CI_Controller
{
    public function __construct() {
        parent::__construct();
		$this->load->library(array('session', 'form_validation','template','pagination'));
		$this->load->helper(array('form', 'url','string','text','custom'));
		//check the login redirection 
		$this->isAdmin = $this->session->userdata('user_role') == 1 ? true : false;
		$this->isEditor = $this->session->userdata('user_role') == 2 ? true : false;
		$this->isUser = $this->session->userdata('user_role') == 3 ? true : false;//viewer
		$this->isRegion=$this->session->userdata('user_role')==4? true : false;
		$this->regionID=$this->session->userdata('region_id');
		$this->isUserID = $this->session->userdata('user_id');
		if($this->router->fetch_class() != "api"):
			if( $this->router->fetch_class()== "auth"):
				if ($this->router->fetch_method() != "logout"):
					if ($this->session->userdata('logged_in') == 1):
						redirect('/dashboard');
					endif;
				endif;
			else:
				if($this->session->userdata('logged_in') !=1):
					redirect('/');
				endif;
			endif;
		endif;
    }
}