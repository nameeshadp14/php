<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('get_user_details')){
   function get_user_details($user_id){
       //get main CodeIgniter object
       $ci =& get_instance();
       
       //load databse library
       $ci->load->database();
       
       //get data from database
       $query = $ci->db->get_where('users',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result;
       }else{
           return false;
       }
   }
}

if ( ! function_exists('convert_date_format')){
	function convert_date_format($cur_date){
		return date("d-m-Y",strtotime($cur_date));
		
	}
}

//Add the parament from post UPDATED BY DATE AND ID - Vignesh - 15-May-2018
if ( ! function_exists('get_status')){
	function get_status($params){
		return $params ==1 ? 'Active':'Inactive';
	}
}
//Add the parament from post UPDATED BY DATE AND ID - Vignesh - 15-May-2018
if ( ! function_exists('get_asset_status')){
	function get_asset_status($params){
		if($params ==1){
			$data='Active';
		}elseif($params ==2){
			$data='Expired';
		}else{
			$data='Inactive';
		}
		return $data;
	}
}

//Add the parament from post UPDATED BY DATE AND ID - Vignesh - 15-May-2018
if ( ! function_exists('get_store_type')){
	function get_store_type($params){
		if($params ==1){
			$data='DES';
		}elseif($params ==2){
			$data='LFR';
		}else{
			$data='MBO';
		}
		return $data;
	}
}


if ( ! function_exists('convertdb_date_format')){
	function convertdb_date_format($cur_date){
		if($cur_date !=""){
			$cur_date=explode("/",$cur_date);
		}
		$updated_date=$cur_date[2]."-".$cur_date[1]."-".$cur_date[0];
		return $updated_date;

	}
	


if ( ! function_exists('time_am_pm')){
	function time_am_pm($i){
		$j=$i+1;
		$iam=$i>=12?$i==12?($i).' PM':($i-12).' PM':$i.' AM';
		$jam=$j>=12?$j==12?($j).' PM':($j-12).' PM':$j.' AM';
		return $iam.' - '.$jam;
	}
}

if (! function_exists('date_from_to')) {
	function date_from_to($date1,$date2){
		$first_date1=str_replace('%2000:00:00', '', $date1);
		$second_date2=str_replace('%2023:59:59', '', $date2);
		$dat1=date('d-m-Y',strtotime($first_date1));
		$dat2=date('d-m-Y',strtotime($second_date2));
		return '<span class="from_date"> <strong>From Date : </strong>' . $dat1 . '</span><span class="to_date"> '.' <strong>To Date :</strong> '.$dat2.'</span> ';
		
	}
	
}
}




