<?php
$config['error_prefix'] = '<div class="error_prefix">';
$config['error_suffix'] = '</div>';