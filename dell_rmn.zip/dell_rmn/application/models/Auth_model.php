<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model{
	
	public  function __construct(){
		parent::__construct();
	}
	/*
	 * Login Validate - Check
	 */
	public  function login($param=array()) {
		$this->db->select('user_id,name,role_id,region_id,is_active');
		$this->db->from('rmn_user');
		$this->db->where('email_id',$param['email']);
		$this->db->where('password',md5($param['pass_word']));
		return $this->db->get()->result_array();
	}
	
	/*
	 * Function to update the status of the scheduler in DB
	 */
	public function update_sch_status(){
		$data=array('sch_status'=>2);
		$cur_date=date("Y-m-d");
		$this->db->from('rmn_scheduler');
		$this->db->where('ed_date <',$cur_date);
		$this->db->where('sch_status',1);
		
		return $this->db->update('rmn_scheduler',$data);
	}
	/* public function update_assets_status(){
		$data=array('asset_status'=>2);
		$cur_date=date("Y-m-d");
		$this->db->from('rmn_asset_master');
		$this->db->where('asset_expiry_date <',$cur_date);
		$this->db->where('asset_status',1);
	
		return $this->db->update('rmn_asset_master',$data);
	} */
}