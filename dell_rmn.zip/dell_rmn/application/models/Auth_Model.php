<?php
class Auth_Model extends CI_Model{
	
	public  function __construct(){
		parent::__construct();
	}
	/*
	 * Login Validate - Check
	 */
	public  function login($param=array()) {
		$this->db->select('user_id,name,role_id,is_active');
		$this->db->from('rmn_user');
		$this->db->where('email_id',$param['email']);
		$this->db->where('password',md5($param['pass_word']));
		return $this->db->get()->result_array();
	}
}