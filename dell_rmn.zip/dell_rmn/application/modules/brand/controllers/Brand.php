<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('brand_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$params['limit'] = RECORDS_PER_PAGE;
		$filter_data=$this->input->get();
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "brand/index";
		$total_row = $this->brand_model->get_all_brands_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_brand"] = $this->brand_model->get_all_brands($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Brand');
		$this->template->set('page_breadcrumb', 'List of Brand');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Brand');
		$this->template->set('page_breadcrumb', 'Add - Brand');
		
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('brand_name','Brand Name','trim|required|is_unique[rmn_region_master.region_name]');
			$this->form_validation->set_rules('status','Status','trim|required');
			if($this->form_validation->run())
			{
				$params = array(
						'brand_name' => $this->input->post('brand_name'),
						'brand_status' => $this->input->post('status'),
						);
				$this->brand_model->add($params);
				$this->session->set_flashdata('success_msg', 'New Brand added successfully.');
				redirect('brand');
			}
		}
		$this->template->load('template', 'contents' , 'add_brand',$data);
	}
	public function edit($id){
		$data = array();
		$data['brand_info']=$this->brand_model->get_brand_details($id);
		if($data['brand_info']['brand_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Brand');
			$this->template->set('page_breadcrumb', 'Edit - Brand');
		
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('brand_name','Brand Name','trim|required|edit_unique[rmn_brand_master.brand_name.brand_id.'.$id.']');
				
				if($this->form_validation->run())
				{
					$params = array(
							'brand_name' => $this->input->post('brand_name'),
							'brand_status' => $this->input->post('status'),
					);
					$this->brand_model->edit_brand($params,$id);
					$this->session->set_flashdata('success_msg', 'Brand updated successfully.');
					redirect('brand');
				}
			}
			$this->template->load('template', 'contents' , 'edit_brand',$data);
		}else{
			redirect('unauthorize');
		}
	}
	/*
	 * Delete The Brand - Vignesh -06062018
	 */
	public function remove($id){
		$data = array();
		$data['brand_info']=$this->brand_model->get_brand_details($id);
		if($data['brand_info']['brand_id']){
			if($this->brand_model->remove_brand($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Brand has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Brand has been used in the application.');
			}
			redirect('brand');
		}else{
			redirect('unauthorize');
		}
	}
	
}
