<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_brands_count($filter_data=null)
	{
		if(count($filter_data)>0){
				$this->db->like('brand_name',$filter_data['brand'],'both');
				$this->db->like('brand_status',$filter_data['status']);
		}
		$this->db->where('brand_status !=',-1);
		$this->db->from('rmn_brand_master');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_brands($filter_data=null,$params = array())
	{
		if(count($filter_data)>0){
			$this->db->like('brand_name',$filter_data['brand'],'both');
			$this->db->like('brand_status',$filter_data['status']);
		}
		$this->db->where('brand_status !=',-1);
		$this->db->order_by('brand_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		return $this->db->get('rmn_brand_master')->result_array();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_active_brands()
	{
		$this->db->where('brand_status',1);
		$this->db->order_by('brand_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		return $this->db->get('rmn_brand_master')->result_array();
	}
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_brand_master',$param);
		return true;
	}
	
	/*
	 * Get the region details by id
	 */
	public function  get_brand_details($id){
		$this->db->where('brand_id',$id);
		return $this->db->get('rmn_brand_master')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_brand($param,$id){
		$this->db->where('brand_id',$id);
		return $this->db->update('rmn_brand_master',$param);
	}
	
	/*
	 * Remove the Brand
	 */
	public function remove_brand($id){
		if($this->checkbrandtatus($id)== 1 ){
			$this->db->where('brand_id',$id);
			$param=array('brand_status'=> -1);
			$this->db->update('rmn_brand_master',$param);
			return 1;
		}else{
			return -1;
		}
	}
	/*
	 * Check region relation table exist or not
	 */
	public function checkbrandtatus($id){
		$flag=0;
		$this->db->select(" COUNT(m.`brand_id`) AS model ,COUNT(`sdu`.`brand_id`) AS scheduler");
		$this->db->where('b.brand_id',$id);
		$this->db->where('b.brand_status !=',-1);
		$this->db->where('m.model_status !=',-1);
		$this->db->where('sdu.sch_status !=',-1);
		$this->db->join('rmn_scheduler sdu','sdu.brand_id=b.brand_id','left');
		$this->db->join('rmn_model_master m','m.brand_id=b.brand_id','left');
		$this->db->from('rmn_brand_master b');
		$query=$this->db->get()->row_array();
		if( $query['model']==0 && $query['scheduler']==0){
			return 1;
		}else{
			return -1;
		}
	}
}
