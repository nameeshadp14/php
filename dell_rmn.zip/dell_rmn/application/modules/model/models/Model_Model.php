<?php
class Model_Model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_models_count($filter_data=null)
	{
		if(count($filter_data)>0){
			$this->db->like('m.model_name',$filter_data['model_name'],'both');
			$this->db->like('m.model_status',$filter_data['status']);
			$this->db->like('m.brand_id',$filter_data['brand_id']);
		}
		$this->db->where('m.model_status !=',-1);
		$this->db->join('rmn_brand_master as r ','r.brand_id=m.brand_id','left');
		$this->db->from('rmn_model_master as m');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_models($filter_data=null,$params = array())
	{
		if(count($filter_data)>0){
			$this->db->like('m.model_name',$filter_data['model_name'],'both');
			$this->db->like('m.model_status',$filter_data['status']);
			$this->db->like('m.brand_id',$filter_data['brand_id']);
		}
		$this->db->order_by('model_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->where('m.model_status !=',-1);
		$this->db->select('*');
		$this->db->join('rmn_brand_master as r ','r.brand_id=m.brand_id','left');
		return $this->db->get('rmn_model_master m')->result_array();
	}
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_model_master',$param);
		return true;
	}
	
	/*
	 * Get the region details by id
	 */
	public function  get_model_details($id){
		$this->db->where('model_id',$id);
		return $this->db->get('rmn_model_master')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_asset($param,$id){
		$this->db->where('model_id',$id);
		return $this->db->update('rmn_model_master',$param);
	}

	/*
	 * Remove the model
	 */
	public function remove_model($id){
		if($this->checkModelstatus($id)== 1 ){
			$this->db->where('model_id',$id);
			$param=array('model_status'=> -1);
			$this->db->update('rmn_model_master',$param);
			return 1;
		}else{
			return -1;
		}
	}
	/*
	 * Check region relation table exist or not
	 */
	public function checkModelstatus($id){
		$flag=0;
		$this->db->select(" COUNT(a.model_id) AS model");
		$this->db->where('m.model_id',$id);
		$this->db->join('rmn_asset_master a','a.model_id=m.model_id','left');
		$this->db->from('rmn_model_master m');
		$query=$this->db->get()->row_array();
		if($query['model'] ==0){
			return 1;
		}else{
			return -1;
		}
	}
}
