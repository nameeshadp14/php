<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_models_count($filter_data=null)
	{
		if(count($filter_data)>0){
			$this->db->like('m.model_name',$filter_data['model_name'],'both');
			$this->db->like('m.model_status',$filter_data['status']);
			$this->db->like('m.brand_id',$filter_data['brand_id']);
		}
		$this->db->where('m.model_status !=',-1);
		$this->db->join('rmn_brand_master as r ','r.brand_id=m.brand_id','left');
		$this->db->from('rmn_model_master as m');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_models($filter_data=null,$params = array())
	{
		
		if(count($filter_data)>0){
			$this->db->like('m.model_status',$filter_data['status']);
			$this->db->like('m.model_name',$filter_data['model_name'],'both');
			if($filter_data['brand_id']!=null){
				$this->db->where('m.brand_id',$filter_data['brand_id']);
			}
			
		}
		$this->db->order_by('m.model_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->where('m.model_status !=',-1);
		$this->db->select('m.*,r.brand_name');
		$this->db->join('rmn_brand_master r ','r.brand_id=m.brand_id','left');
		return $this->db->get('rmn_model_master m')->result_array();
	}
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_model_master',$param);
		return true;
	}
	
	/*
	 * Get the region details by id
	 */
	public function  get_model_details($id){
		$this->db->where('model_id',$id);
		return $this->db->get('rmn_model_master')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_asset($param,$id){
		$this->db->where('model_id',$id);
		return $this->db->update('rmn_model_master',$param);
	}

	/*
	 * Remove the model
	 */
	public function remove_model($id){
		if($this->checkModelstatus($id)== 1 ){
			$this->db->where('model_id',$id);
			$param=array('model_status'=> -1);
			$this->db->update('rmn_model_master',$param);
			return 1;
		}else{
			return -1;
		}
	}
	/*
	 * Check region relation table exist or not
	 */
	public function checkModelstatus($id){
		$flag=0;
		$this->db->select('COUNT(g.group_id) AS count');
		$this->db->where('m.model_id',$id);
		$this->db->where('g.group_status!=',-1);
		$this->db->join('rmn_model_group_mapping as gm','gm.model_id=m.model_id','left');
		$this->db->join('rmn_group_master as g','g.group_id=gm.group_id','left');
		$model=$this->db->get('rmn_model_master as m')->row()->count;
		$this->db->select("COUNT(a.model_id) AS count");
		$this->db->where('m.model_id',$id);
		$this->db->where('a.asset_status!=',-1);
		$this->db->join('rmn_asset_master a','a.model_id=m.model_id','left');
		$query=$this->db->get('rmn_model_master m')->row()->count;
		if($query['count']==0 && $model['count']==0){
			return 1;
		}else{
			return -1;
		}
	}
}
