<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('model_model');
		$this->load->model('brand/brand_model');
	}
	/*
	 * List of asset details - Vignesh - 0502018
	 */
	public function index()
	{
		$data = array();
		$params=array();
		$params['limit'] = RECORDS_PER_PAGE;
		$filter_data=$this->input->get();
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "model/index";
		$total_row = $this->model_model->get_all_models_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$data['brand_info']=$this->brand_model->get_all_brands();
		$params['offset'] = $page;
		$data["list_of_models"] = $this->model_model->get_all_models($filter_data,$params);
		
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Model');
		$this->template->set('page_breadcrumb', 'List of Model');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	/*
	 * Add the asset details - Vignesh - 0502018
	 */
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Model');
		$this->template->set('page_breadcrumb', 'Add - Model');
		$data['brand_info']=$this->brand_model->get_all_brands();
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('model_name','Model Name','trim|required');
			$this->form_validation->set_rules('status','Status','trim|required');
			$this->form_validation->set_rules('brand_id','Brand','trim|required|callback_model_check');
			if($this->form_validation->run())
			{
				$params = array(
						'model_name' => $this->input->post('model_name'),
						'model_status' => $this->input->post('status'),
						'brand_id' => $this->input->post('brand_id'),
						);
				$this->model_model->add($params);
				$this->session->set_flashdata('success_msg', 'New Model added successfully.');
				redirect('model');
			}
		}
		$this->template->load('template', 'contents' , 'add_model',$data);
	}
	public function model_check(){
		$model_name = $this->input->post('model_name');
		$brand_id = $this->input->post('brand_id');
		$model_id = $this->input->post('model_id');
		$this->db->select('*');
		$this->db->from('rmn_model_master');
		$this->db->where('model_name',$model_name);
		$this->db->where('brand_id',$brand_id);
		$query=$this->db->get();
		$result=$query->row_array();
		$cnt_data=$query->num_rows();
		if($cnt_data > 0){
			if($model_id !=''){
				if($model_id != $result['model_id']): 
					$this->form_validation->set_message('model_check', 'The model already exist for brand');
					return false;
				else:
					return true;
				endif;
			}
			$this->form_validation->set_message('model_check', 'The model already exist for brand');
			return false;
		}
		return true;
	}
	/*
	 * Edit the asset details - Vignesh - 0502018
	 */
	public function edit($id){
		$data = array();
		$data['model_info']=$this->model_model->get_model_details($id);
		if($data['model_info']['model_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Model');
			$this->template->set('page_breadcrumb', 'Edit - Model');
			$data['brand_info']=$this->brand_model->get_all_brands();
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('model_name','Model Name','trim|required');
				$this->form_validation->set_rules('status','Status','trim|required');
				$this->form_validation->set_rules('brand_id','Brand','trim|required|callback_model_check');
				
				
				if($this->form_validation->run())
				{
					$params = array(
						'model_name' => $this->input->post('model_name'),
						'model_status' => $this->input->post('status'),
						'brand_id' => $this->input->post('brand_id'),
					);
					$this->model_model->edit_asset($params,$id);
					$this->session->set_flashdata('success_msg', 'Model updated successfully.');
					redirect('model');
				}
			}
			$this->template->load('template', 'contents' , 'edit_model',$data);
		}else{
			redirect('unauthorize');
		}
	}
	/*
	 * Delete The region - Vignesh -06062018
	 */
	public function remove($id){
		$data = array();
		$data['model_info']=$this->model_model->get_model_details($id);
		if($data['model_info']['model_id']){
			if($this->model_model->remove_model($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Model has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Model has been used in the application.');
			}
			redirect('model');
		}else{
			redirect('unauthorize');
		}
	}
	
}
