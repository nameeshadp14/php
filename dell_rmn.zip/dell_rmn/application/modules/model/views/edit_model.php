<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit Model
		<a href="<?php echo base_url('model');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <form class="frm_inner cmn_form" id="model_management" method="post" action="">
            <div class="row m_left m_right">
                <div class="col-md-6 form-group">
                    <label>Model Name <span class="text-danger">*</span></label>
                    <input type="text" name="model_name" id="model_name" data-toggle="tooltip"value="<?php echo set_value("model_name",$model_info['model_name']); ?>" class="form-control">
                	<span class="text-danger"><?php echo form_error('model_name');?></span>
                </div>
                <div class="col-md-6 form-group">
                    <label>Brand <span class="text-danger">*</span></label>
                    <select name="brand_id" id="brand_id" class="form-control">
                    <option value="">--Select Brand--</option>
                    	<?php foreach($brand_info as $brand) :?>
                    		<option value="<?php echo $brand['brand_id']?>" <?php echo $model_info['brand_id']==$brand['brand_id']?'selected=selected':''; ?>><?php echo $brand['brand_name']?></option>
                   		 <?php endforeach;?>
                   	</select>
                	<span class="text-danger"><?php echo form_error('brand_id');?></span>
                </div>
                 <div class="clearfix"></div>
                 <div class="col-md-6 form-group">
                    <label>Status <span class="text-danger">*</span></label>
                    <select name="status" id="status" class="form-control">
                    		<option value="">--Select Status--</option>
                    		<option value="1" <?php echo $model_info['model_status']==1?'selected=selected':''; ?>>Active</option>
                    		<option value="0" <?php echo $model_info['model_status']==0?'selected=selected':''; ?>>Inactive</option>
                    
                    </select>
                	<span class="text-danger"><?php echo form_error('status');?></span>
                </div>
                <div class="clearfix"></div>
                <div class="text-right btn_ar">
                    <div class="col-md-12 p_right">
                    		<input type="hidden" name="model_id" value="<?php echo $model_info['model_id'];?>" />
                            <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                            <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
                    </div>
                </div>
        </form>
    </div>
</div>