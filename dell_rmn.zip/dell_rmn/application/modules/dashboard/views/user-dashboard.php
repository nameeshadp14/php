<style>
#asset_pie_chart,#schedule_pie_chart ,#chartdiv{
  width: 100%;
  height: 500px;
}
</style>
<?php
if(!isset($schedule_report[0]['schedule_cnt'])) $schedule_report[0]=0;
if(!isset($schedule_report[1]['schedule_cnt'])) $schedule_report[1]=0; //To define and initialize the array index if it is not defined
if(!isset($schedule_report[2]['schedule_cnt'])) $schedule_report[2]=0;
$scheduler_active=0;
$schedule_inactive=0;//default initailization
$scheduler_expired=0;

$active_assets=count($asset_report['active_assets']);
$inactive_assets=$asset_report['inactive_assets'];
$expired_assets=count($asset_report['expired_assets']);
foreach ($schedule_report as $schedules){  //To check for the indices of the array and assign it to the particular schedule count
	

		$s_cnt = $schedules['schedule_cnt'] ;
		$status = $schedules['sch_status'] ;
		
	
	switch ($status){
		case "inactive":$schedule_inactive=($s_cnt);
		break;
		case "active":$scheduler_active=($s_cnt);
		break;
		case "expired":$scheduler_expired=($s_cnt);
		break;
		
	}
	
}
?>
	<!-- amCharts javascript sources -->
<script type="text/javascript" src="<?php echo base_url('assets/js/amcharts.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/pie.js');?>"></script>
<div class="dsh_cht">
    <div class="row m_left m_right">
        <div class="col-md-6 padd_six">
            <div class="cht_in bg_white">
                <h3 class="cmn_tit">Assets Report</h3>
                <div id="asset_pie_chart"></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="cht_in bg_white">
                <h3 class="cmn_tit">Schedules Report</h3>
                <div id="schedule_pie_chart"></div>
            </div>
        </div>
    </div>
</div>
<div class="assets_rep bg_white">
    <h3 class="cmn_tit">Region Based Asset Report</h3>

    <div class="asts_no">
        <div class="row m_left m_right ">
        <?php foreach($region_report as $res){ ?>
            <div class="col-md-3">
                <div class="row m_left m_right">
                    <div class="col-md-5 col-xs-5  assets_rep_no">
                        <h4><?php echo $res['region_name'];?></h4>
                        <p><?php if ($res['total'] >0){?>
                        		<a href=" <?php echo base_url().'dashboard/getasset_based_region/region/'.$res['region_id'].'/all';?>"><?php echo $res['total']?></a>
                        	<?php }else{?>
			    	 				<?php echo $res['total'];?>
			    	 		<?php }?>
                        </p>
                    </div>
                    <div class="col-md-6 col-xs-6 p_left  assets_rep_cont br_right">
                        <ul class="list-unstyled">
                            <li><span class="ac_status">Active</span><span class="colon">:</span>
                            	<span>
                            	 	<a <?php if($res['active'] > 0) { ?>href="<?php echo base_url().'dashboard/getasset_based_region/region/'.$res['region_id'].'/active';?>" <?php } ?>><?php  echo $res['active']?>
								</span>
							</li>
                            <li><span class="ac_status">Inactive</span><span class="colon">:</span>
                            	<span>
                            	 	<a <?php if($res['inactive'] > 0) { ?>href="<?php echo base_url().'dashboard/getasset_based_region/region/'.$res['region_id'].'/inactive';?>" <?php } ?>><?php  echo $res['inactive']?>
								</span>
                            </li>
                            <li><span class="ac_status">Expired</span><span class="colon">:</span>
                            	<span>
                            	 	<a <?php if($res['expired'] > 0) { ?>href="<?php echo base_url().'dashboard/getasset_based_region/region/'.$res['region_id'].'/expired';?>" <?php } ?>><?php  echo $res['expired']?>
								</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
           <?php }?>
        </div>
    </div>
</div>
<!-- Store based Report -->
<div class="stored_bs_rep bg_white">
    <div class="row m_left m_right">
        <div class="col-md-8 col-xs-8">
            <h3 class="cmn_tit">Store Based Asset Report</h3>
        </div>
        <div class="col-md-4 col-xs-4 text-right ex_im">
            <a href="<?php echo base_url().'dashboard/export/store';?>">Export<img src="<?php echo base_url('assets/images/export_new.png'); ?>"></a>
        </div>
    </div>
    <div class="st_bs_tab">
        <div class="row m_left m_right">
            <div class="col-md-8">
                <div class="table-responsive table_scroll">  <!--  Added scroll feature for the table-->
                    <table class="table">
                        <tr>
                            <th>Sno</th>
                            <th>Store Name</th>
                            <th class="text-center">Total Asset</th>
                        </tr>
                        <?php $sno=1;
						foreach($store_report as $store){?>
						  <tr>
						    <td><?php echo $sno;?></td>
						    <td><?php echo $store['store_name'];?></td>
						    <?php if ($store['count']>0){?>
						    <td class="text-center"><a href="<?php echo base_url().'dashboard/getasset_based_store/store/'.$store['store_id'];?>"><?php echo $store['count'];?></a></td>
						    <?php }else{?>
						  	 <td class="text-center"><?php echo $store['count'];?></td>
						    <?php }?>
						  </tr>
					<?php $sno++;}?>
                        <tr>
                           <!--  <td>5</td>
                            <td>KA_Bangalore_Brigade_RD_Premier_IT_Solutions_Pvt_L</td>
                            <td 6</td> -->
                        </tr>
                    </table>
                </div>
            </div>
            <div class="col-md-4">
                <div class="st_bs_tab_cont">
                    <ul class="list-unstyled">
                        <li><span class="tot_play">Total Playlist</span><span>
                        <?php if($total_playlists > 0){?>
			       		<a href="<?php echo base_url().'dashboard/getplaylistdetail';?>" ><?php echo $total_playlists ;?></a>
			       		<?php }else{?>
			       		<?php echo $total_playlists;?>
			       		<?php }?>
                        </span></li>
                        <li><span class="tot_play">Total Model</span><span>
                        <?php if($total_models > 0){?>
			       		<a href="<?php echo base_url().'dashboard/getmodeldetail';?>"><?php echo $total_models ;?></a>
						<?php }else{?>
						<?php echo $total_models ;?>
						<?php }?>
                        </span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Store based report End -->
<div class="total_act_expire st_bs_tab">
    <div class="row m_left m_right">
        <div class="col-md-6 padd_six">
            <div class="left_dash_table bg_white table_scroll">
                <div class="row m_left m_right">
                    <div class="col-md-8 col-xs-8 ">
                        <h3 class="cmn_tit">Total Asset Active Expired</h3>
                    </div>
                    <div class="col-md-4 col-xs-4  text-right ex_im">
                        <a href="<?php echo base_url().'dashboard/export/activeexpired';?>">Export<img src="<?php echo base_url('assets/images/export_new.png'); ?>"></a>
                    </div>
                </div>
                <div class="table_sp">
                    <table class="table">
                        <tr>
                            <th>Service Tag</th>
                            <th>Days</th>
                        </tr>
                        <?php 
					       foreach($active_expired_assets as $active_expire){?>
					       <tr>
						       	<td><?php echo $active_expire['asset_service_tag'] ;?></td> <!--  added two more columns-->
						       	<td><?php echo $active_expire['days'];?></td>
						    </tr>
						   <?php }?>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left_dash_table bg_white table_scroll">
                <div class="row m_left m_right">
                    <div class="col-md-8 col-xs-8">
                        <h3 class="cmn_tit">Inactive Asset more than 3 days</h3>
                    </div>
                    <div class="col-md-4 col-xs-4 text-right ex_im">
                        <a href="<?php echo base_url().'dashboard/export/inactiveasset'?>">Export<img src="<?php echo base_url('assets/images/export_new.png'); ?>"></a>
                    </div>
                </div>
                <div class="table_sp">
                    <table class="table">
                        <tr>
                            <th>Service Tag</th>
                            <th>Days</th>
                        </tr>
                        <?php 
				       foreach($inactive_asset as $inactive){?>
				       <tr>
					       	<td> <?php echo $inactive['service_tag'] ;?></td>
					       	<td> <?php echo $inactive['days'];?></td>
					    </tr>
					   <?php }?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php //echo $active_assets;?>
<?php //echo $active_assets+$inactive_assets+$expired_assets;?>
	<script type="text/javascript">
	AmCharts.makeChart("asset_pie_chart",
		{
			"type": "pie",
			"balloonText": "[[title]]<br><span style='font-size:14px'><b>[[value]]</b></span>",
			"depth3D": 1,
			"innerRadius": "87%",
			"labelText": "",
			"minRadius": 90,
			"startAngle": 219.6,
			"accessibleLabel": "",
			"alpha": 0.56,
			"hideLabelsPercent": 12,
			"titleField": "category",
			"valueField": "asset_cnt",
			"accessibleTitle": "",
			"allLabels": [
				{
					"id": "total_label_name",
					"size": 16,
					"text": "Total Assets",
					"x": "42%",
					"y": "46%"
				},
				{
					"id": "total_count",
					"size": 14,
					"text": <?php echo $active_assets+$inactive_assets+$expired_assets;?>,
					"x": "49%",
					"y": "54%"
				},
				{
					"bold": true,
					"id": "Label-6",
					"size": 14,
					"text": "Total Registered : <?php echo $active_assets+$inactive_assets+$expired_assets;?>",
					"x": "32%",
					"y": "95%"
				}
			],
			"balloon": {},
			"legend": {
				"enabled": true,
				"align": "center",
				"markerType": "circle"
			},
			"titles": [],
			"dataProvider": [
				{
					"category": "Active",
					"asset_cnt": <?php echo $active_assets;?>
				},
				{
					"category": "Inactive",
					"asset_cnt":<?php echo $inactive_assets;?>
				},
				{
					"category": "Expired",
					"asset_cnt": <?php echo $expired_assets;?>
				}
			],
			"listeners": [{
			    "event": "clickSlice",
			    "method": function(event) {
			       // alert(event.dataItem.dataContext.urlField);
			    }
			}]
			
		}
	);

	
AmCharts.makeChart("schedule_pie_chart",
	{
		"type": "pie",
		"balloonText": "[[title]]<br><span style='font-size:14px'><b>[[value]]</b></span>",
		"depth3D": 1,
		"innerRadius": "87%",
		"labelText": "",
		"minRadius": 90,
		"startAngle": 219.6,
		"accessibleLabel": "",
		"alpha": 0.56,
		"hideLabelsPercent": 12,
		"titleField": "category",
		"valueField": "column-1",
		"accessibleTitle": "",
		"allLabels": [
			{
				"id": "total_label_name",
				"size": 16,
				"text": "Total Schedules",
				"x": "42%",
				"y": "46%"
			},
			{
				"id": "total_count",
				"size": 14,
				"text": "<?php echo $scheduler_active+$schedule_inactive+$scheduler_expired;?>",
				"x": "49%",
				"y": "54%"
			},
			
			{
				"bold": true,
				"id": "Label-6",
				"size": 14,
				"text": "Total Registered : <?php echo $scheduler_active+$schedule_inactive+$scheduler_expired;?>",
				"x": "32%",
				"y": "95%"
			}
		],
		"balloon": {},
		"legend": {
			"enabled": true,
			"align": "center",
			"markerType": "circle"
		},
		"titles": [],
		"dataProvider": [
			{
				"category": "Active",
				"column-1": <?php echo $scheduler_active;?>
			},
			{
				"category": "Inactive",
				"column-1": <?php echo $schedule_inactive;?>
			},
			{
				"category": "Expired",
				"column-1": <?php echo $scheduler_expired;?>
			}
		]
	}
);

		</script>