
<div class="bg_white col-md-12">
	<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow p_top">
	 	<div class="box-body">	
	 	<div class="pull-right">
		 		<a href="<?php echo base_url();?>"	class="btn btn-success btn-xs ">Go back</a>
		 		</div>
		    <table id="master_datatables" class="table table-striped">
				 <thead>
					<tr>
						<th>S.No</th>
						<th>Scheduler  Id</th>
						<th>Scheduler Name</th>
					</tr>
				  </thead>
				  <tbody>
                    <?php 
                   $inc = $sno + 1;
                    foreach ( $scheduler as $sch ) {?>
	                    <tr>
							<td><?php echo $inc; ?></td>
							<td><?php echo $sch['sch_id']; ?></td>
							<td><?php echo $sch['sch_name']; ?></td>
						</tr>
                    <?php $inc++;}?>
                </tbody>
		    </table>
			<div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
            </div>
  </div>
</div>