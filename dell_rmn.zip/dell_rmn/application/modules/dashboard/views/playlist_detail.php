
<div class="bg_white col-md-12">
	<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow p_top">
	 	<div class="box-body">	
	 	<div class="pull-right">
		 		<a href="<?php echo base_url();?>"	class="btn btn-success btn-xs ">Go back</a>
		 		<a href='<?php echo base_url().'dashboard/export/'.$this->uri->segment (2);?>'
					class="btn btn-success btn-xs m_left_10">Export<span
					class="glyphicon glyphicon-export"></span>
				</a>    
		 		</div>
		    <table id="master_datatables" class="table table-striped">
				 <thead>
					<tr>
						<th>S.No</th>
						<th>Playlist  Id</th>
						<th>Playlist Name</th>
					</tr>
				  </thead>
				  <tbody>
                    <?php 
                    $sno = $sno+1;
                    foreach ( $playlist as $list ) {?>
	                    <tr>
							<td><?php echo $sno; ?></td>
							<td><?php echo $list['playlist_id']; ?></td>
							<td><?php echo $list['playlist_name']; ?></td>
						</tr>
                    <?php $sno ++;}?>
                </tbody>
		    </table>
			<div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
            </div>
  </div>
</div>