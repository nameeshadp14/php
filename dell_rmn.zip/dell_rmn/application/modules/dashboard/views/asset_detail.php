
<div class="bg_white col-md-12">
	<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow p_top">
	 	<div class="box-body"><div>	<?php  echo "Region Based Assets Report";?></div>
	 	 <div class="pull-right"> 
    <a href="<?php echo base_url('dashboard');?>" class="btn btn-success btn-xs m_left_10">Go back</a>
   <a href=<?php if ($this->uri->segment (2)=='getasset_based_store'){?>'<?php echo base_url().'dashboard/export/'.$this->uri->segment (2);?>'<?php }?>'<?php echo base_url().'dashboard/exportforregion/'.$this->uri->segment (4).'/'.$this->uri->segment (5);?>'
    					class="btn btn-success btn-xs m_left_10">Export<span
					class="glyphicon glyphicon-export"></span>
				</a>    
		</div>
		    <table id="master_datatables" class="table table-striped">
				 <thead>
					<tr>
						<th>S.No</th>
						<th>Asset Code</th>
						<th>Service tag</th>
						<th>Location</th>
						<th>Store code</th>
						<th>Store name</th>
						<th>Store Contact Number</th>
					</tr>
				  </thead>
				  <tbody>
                    <?php 
                    $type = $this->uri->segment(3);
                    $assets = array();
                    if($type == 'asset'){
                    	$assets = $asset_detail;
                    }elseif($type == 'store'){
                    	$assets = $store_asset;
                    }elseif($type == 'region'){
                    	$assets = $region_asset;
					}
                      $inc = $sno + 1;
                    foreach ($assets as $asset ) {?>
	                    <tr>
							<td><?php echo $inc; ?></td>
							<td><?php echo $asset['asset_code']; ?></td>
							<td><?php echo $asset['asset_service_tag']; ?></td>
							<td><?php echo $asset['region_name']; ?></td>
							<td><?php echo $asset['store_code']; ?></td>
							<td><?php echo $asset['store_name']; ?></td>
							<td><?php echo $asset['store_contact_number']?>
						</tr>
                    <?php $inc++;}?>
                </tbody>
		    </table>
			<div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
            </div>
  </div>
  </div>
</div>