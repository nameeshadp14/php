<form action="" method="post">
 <div class="form-group">
    <label for="email">Email address:</label>
    <input type="TEXT" class="form-control" value="<?php echo set_value('email'); ?>" id="email">
    <?php echo form_error('email'); ?>
  </div>
  <div class="form-group">
    <label for="pwd">Username:</label>
    <input type="text" class="form-control" id="username" value="<?php echo set_value('username'); ?>">
    <?php echo form_error('username'); ?>
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-default" name="btn_name" value="save">Submit</button>
</form>