<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	// get current_asset_report - Vignesh - 10-11-2018
	public function current_asset_report(){
		$result=array();
		$this->db->from('rmn_asset_master a');
		if($this->regionID!=''){
			$this->db->where('s.region_id',$this->regionID);
			$this->db->join('rmn_store_master as s','s.store_id=a.asset_store_id');
		}
		$result['total_asset']=$this->db->count_all_results();
		$result['active_assets']=$this->active_asset_list();
		$result['expired_assets']=$this->expired_asset_list();
		$result['inactive_assets']=$result['total_asset'] - count($result['active_assets']) - count($result['expired_assets']);
		return $result;
	}
	// get the active assets 
	public function active_asset_list($asset_list = array()){
		$this->db->where('DATE(h.pingdatetime)',date("Y-m-d"));
		if(count($asset_list)==0){
			$this->db->select('DISTINCT(a.asset_id) AS asset');
			$this->db->join('rmn_asset_hearbeat as h','h.asset_id=a.asset_id');
			if($this->regionID!=''){
				$this->db->join('rmn_store_master s','s.store_code=h.store_code');
				$this->db->where('region_id',$this->regionID);
			}
		return $this->db->get('rmn_asset_master a')->result_array();//print_r($r);exit;
		}else{
			$this->db->select('count(DISTINCT(h.asset_id)) AS asset');
			$this->db->where_in('h.asset_id',$asset_list);
			if($this->regionID!=''){
				$this->db->join('rmn_store_master s','s.store_code=h.store_code');
				$this->db->where('region_id',$this->regionID);
			}
			$active_asset = $this->db->get('rmn_asset_hearbeat h')->row()->asset;
			return $active_asset;
		}
	}
	// get the expired assets Praveen-13-10-2018
	public function expired_asset_list($region_id =''){
		if($region_id ==''){
			$this->db->select('distinct(a.asset_id)');
			if($this->regionID!=''){
				$this->db->where('s.region_id',$this->regionID);
				$this->db->join('rmn_store_master as s','s.store_id=a.asset_store_id');
			}
			$this->db->where('asset_expiry_date <',date("Y-m-d H:i:s"));
			//$this->db->where('asset_status',2);
			$this->db->from('rmn_asset_master a');
			return $this->db->get()->result_array();//print_r($r);exit;	
		}else{
			$this->db->select('count(distinct(a.asset_id)) AS Count');
			$this->db->where('a.asset_expiry_date <',date("Y-m-d H:i:s"));
			$this->db->where('r.region_id',$region_id);
			$this->db->join('rmn_store_master s','r.region_id=s.region_id');
			$this->db->join('rmn_asset_master a','s.store_id=a.asset_store_id');
			$asset =$this->db->get('rmn_region_master r')->row()->Count;
			return $asset;
		}
	}
	// get asset details based on store and asset status
	public function getassetdetail($asset_status = '',$store_id = '',$result_type = '',$params =''){
		$asset = array();
		if($store_id !=''){
			$store = array();
			$this->db->select('DISTINCT(a.asset_id)');
			$this->db->where('s.store_id',$store_id);
			$this->db->join('rmn_asset_master a','s.store_id=a.asset_store_id','left');
			$store_asset =$this->db->get('rmn_store_master s')->result_array();
			foreach($store_asset as $str_asst){
				$store[] = $str_asst['asset_id'];
			}
			$asset = $store;
		}else{
			if($asset_status == 'all'){
				$total=array();
				$this->db->select('asset_id,asset_code,asset_service_tag');
				//get Total Assets
				$total_asst= $this->db->get('rmn_asset_master')->result_array();
				foreach($total_asst as $asst){
					$total[]=$asst['asset_id'];
				}
				$asset = $total;
			}else if($asset_status =='active'){
				$act_ast=array();
				//get Total active Assets based on current date
				$asset_active = $this->active_asset_list();
				foreach($asset_active as $act_asset){
					$act_ast[] =$act_asset['asset_id'];
				}
				$asset =$act_ast;
			}
			else if($asset_status == 'inactive'){
				$total_asset = array();
				$active_asset = array();
				$expired_asset=array();
				//get Total asset
				$total = $this->getallasset();
				foreach ($total as $tot_asset){
					$total_asset[] = $tot_asset['asset_id'];
				}
				//get Total active Assets based on current date
				$active = $this->dashboard_model->active_asset_list();
				foreach ($active as $act_asset){
					$active_asset[] = $act_asset['asset_id'];
				}
				//get Total expired Assets based on current date
				$expired = $this->dashboard_model->expired_asset_list();
				foreach ($expired as $exp_asset){
					$expired_asset[] = $exp_asset['asset_id'];
				}
				// get inactive asset (Total-active-expired)
				$asset= array_diff($total_asset,(array_merge($active_asset,$expired_asset)));
			}else if($asset_status == 'expired'){
				$expire=array();
				// get Expired asset based on current date
				$expired_asset = $this->expired_asset_list();
				foreach($expired_asset as $expasset){
					$expire[] = $expasset['asset_id'];
				}
				$asset =$expire;
			}
		}//echo 'hii';
		if(count($asset)>0){//echo 'helo';
			$r=array();
			$r= $this->get_asset_list($asset,$result_type,$params);//print_r($r);exit;
			return $r;
		}
		
	}
	// get get asset details
	public function get_asset_list($asset ='',$result_type='',$params =''){
		if(count($asset)>0){
			$this->db->select("asst.asset_id,asst.asset_service_tag,asst.asset_code,sm.store_code,sm.store_name,reg.region_name,sm.store_contact_number");
			$this->db->join('rmn_store_master sm','sm.store_id=asst.asset_store_id','left');
			$this->db->join('rmn_region_master reg','reg.region_id=sm.region_id','left');
			$this->db->where_in('asst.asset_id',$asset);
			if($result_type == '1'){
				return $this->db->get('rmn_asset_master asst')->num_rows();
			}elseif($result_type == '2'){
				if(isset($params) && !empty($params))
				{
					$this->db->limit($params['limit'], $params['offset']);
				}
				return $this->db->get('rmn_asset_master asst')->result_array();
				 
		  }
		}else{
			return array();
		}
	}

	// get all asset
	public function getallasset(){
		$this->db->select('DISTINCT(asset_id)');
		return $this->db->get('rmn_asset_master')->result_array();
	}
		
	// get schedule_reports - Vignesh - 10-11-2018
	public function schedule_reports(){
		$data=array();
		$result=array();
		$this->db->from('rmn_scheduler');
		$result['total_schdules']=$this->db->count_all_results();
		 if($this->regionID!=''){  //To check is it a regional based access.
			$this->db->where('region_id',$this->regionID);
		} 
		$this->db->select("COUNT(*) AS schedule_cnt,
			CASE sch_status
                WHEN '0' THEN 'inactive'
				WHEN '1' THEN 'active'
		        WHEN '2' THEN 'expired'
		       END AS sch_status"
				);
		$this->db->group_by('sch_status');
		$result['schedule_report']=$this->db->get('rmn_scheduler')->result_array();
		$data['sch']=$result['schedule_report'];
		$data['count']=$result['total_schdules'];
		return $data;
	}
	
	//get scheduler details
	public function getscheduledetail($sch_status ='',$result_type ='',$params =''){
		$this->db->select('sch_id,sch_name');
		if($sch_status == 'all'){
		}elseif($sch_status == 'active'){
			$this->db->where('sch_status',1);
		}elseif($sch_status == 'inactive'){
			$this->db->where('sch_status',0);
		}elseif($sch_status == 'expired'){
			$this->db->where('sch_status',-1);
		}
		if($result_type == '1'){
			return $this->db->get('rmn_scheduler')->num_rows();
		}elseif($result_type == '2'){
			return $this->db->get('rmn_scheduler')->result_array();
		}
	}
	
	//get region report ---Praveen 13-10-2018
	public function get_region(){
		$data=array();
		$result = array();
		$this->db->select('region_id,region_name');
		if($this->regionID!=''){
			$this->db->where_in('region_id',$this->regionID);
		}
		$region = $this->db->get('rmn_region_master')->result_array();
		foreach($region as $region_id){
			$asset_list=array();
			$total_asset=0;
			$active_asset=0;
			$expired_asset=0;
			$res = $this->get_assetregion_based($region_id['region_id']);
			if(count($res)>0){
				foreach($res as $asset){
					$asset_list[]=$asset['asset_id'];
				}
			}
			$total_asset = count($asset_list);
			if($total_asset > 0){
				$active_asset = $this->active_asset_list($asset_list);
				$expired_asset = $this->expired_asset_list($region_id['region_id']);
			}
			$result['region_id'] =$region_id['region_id'];
			$result['region_name'] =$region_id['region_name'];
			$result['total'] = $total_asset;
			$result['active'] = $active_asset;
			$result['inactive'] =$total_asset- $active_asset -$expired_asset;
			$result['expired'] = $expired_asset;
			$data[]=$result;
		}
		return $data;
	}
	// get asset details based on region
	public function getassetbased_region($status,$result_type ='',$params='',$region_id){
		$asset=array();
		//get all assets based on region id
		$asset_all = $this->get_assetregion_based($region_id);
		// convert object array to normal array
		$asset_all_array = $this->convertassetarray($asset_all);
		// get active asset based on region id
		$asset_active =$this->getactiveasset_based_region($asset_all_array);
		//convert object array to normal array
		$asset_active_array = $this->convertassetarray($asset_active);
		// get expired asset based on region id
		$expired_asset = $this->get_expired_asset();
		//convert object array to normal array
		$asset_expired_array = $this->convertassetarray($expired_asset);
		// get inactive asset based on region id
		$asset_inactive_array = array_diff($asset_all_array,(array_merge($asset_active_array,$asset_expired_array)));
		if($status == 'all'){
			$asset = $asset_all_array;
		}else if($status == 'active'){
			$asset = $asset_active_array;
		}else if($status == 'inactive'){
			$asset = $asset_inactive_array;
		}else if($status == 'expired'){
			$asset = $asset_expired_array;
		}
		return $this->get_asset_list($asset,$result_type,$params);//print_r($r);exit;
	}
	// convert object array to normal array
	public function convertassetarray($asset_list = ''){
		$asset = array();
		if(count($asset_list) != 0){
			foreach($asset_list as $list){
				$asset[] = $list['asset_id'];
			}
		}
		return $asset;
	}
	
	// get expired asset based on region
	public function get_expired_asset($region_id =''){
			$this->db->select('distinct(asset_id)');
			$this->db->where('asset_expiry_date <',date("Y-m-d H:i:s"));
			$this->db->from('rmn_asset_master');
			return $this->db->get()->result_array();
	}
	
	// get active asset based on region id  --Praveen 16-10-2018
	public function getactiveasset_based_region($asset=null){
		$this->db->select('DISTINCT(h.asset_id) as asset_id');
		$this->db->where('DATE(h.pingdatetime)',date("Y-m-d"));
		$this->db->where_in('h.asset_id',$asset);
		$this->db->join('rmn_asset_hearbeat as h','h.asset_id=a.asset_id');
		if($this->regionID!=''){
			$this->db->join('rmn_store_master s','s.store_id=a.asset_store_id');
			$this->db->where('s.region_id',$this->regionID);
		}
		return $this->db->get('rmn_asset_master a')->result_array();
		 
	}
	
	// Get asset based on region ---Praveen 13-10-2018
	public function get_assetregion_based($region_id=null){
		$this->db->select('distinct (a.asset_id)');
		$this->db->where('r.region_id',$region_id);
		if($this->regionID!=''){
			$this->db->where('r.region_id',$this->regionID);
		}
		$this->db->join('rmn_store_master s','r.region_id=s.region_id');
		$this->db->join('rmn_asset_master a','s.store_id=a.asset_store_id');
		return $this->db->get('rmn_region_master r')->result_array();
	}
	// get store report ---Praveen 13-10-2018
	public function get_store_report($store =''){
		$result = array();
		$this->db->select('store_id,store_name');
		if($this->regionID!=''){
			$this->db->where('region_id',$this->regionID);
		}
		$store= $this->db->get('rmn_store_master')->result_array();
		foreach($store as $store){
			$output = array();
			$this->db->select('a.asset_id');
			$this->db->where('s.store_id',$store['store_id']);
			$this->db->join('rmn_asset_master a','s.store_id = a.asset_store_id','left');
			$this->db->where('a.asset_id is not null');
			$count = $this->db->get('rmn_store_master s')->num_rows();
				$output['store_id'] = $store['store_id'];
				$output['store_name'] = $store['store_name'];
			$output['count'] = $count;
			$result[] = $output;
		}
		return $result;
	}
	//get all playlist ---Praveen 13-10-2018
	public function getplaylistdetail($type ='',$params=''){
		if($type == '2'){
			$this->db->select('pl.playlist_id,pl.playlist_name');
			if(isset($params) && !empty($params))
			{
				$this->db->limit($params['limit'], $params['offset']);
			}
			if($this->regionID!=''){
				$this->db->join('rmn_scheduler_playlist_mapping spm','spm.playlist_id=pl.playlist_id');
				$this->db->join('rmn_scheduler sch','sch.sch_id=spm.sch_id');
				$this->db->where('sch.region_id',$this->regionID);
			}
			return $this->db->get('rmn_video_playlist pl')->result_array();
		}else{
			$this->db->select('count(pl.playlist_id) AS count');
			if($this->regionID!=''){
				$this->db->join('rmn_scheduler_playlist_mapping spm','spm.playlist_id=pl.playlist_id');
				$this->db->join('rmn_scheduler sch','sch.sch_id=spm.sch_id');
				$this->db->where('sch.region_id',$this->regionID);
			}
			return $this->db->get('rmn_video_playlist pl')->row()->count;
		}
	}
	// get all model-Praveen 13-10-2018
	public function get_all_model($type = '',$params=''){
		if($type == '2'){
			$this->db->select('DISTINCT(m.model_id),m.model_name');
			if(isset($params) && !empty($params))
			{
				$this->db->limit($params['limit'], $params['offset']);
			}
			if($this->regionID!=''){
				$this->db->join('rmn_asset_master a','a.model_id=m.model_id');
				$this->db->join('rmn_store_master s','a.asset_store_id=s.store_id');
				$this->db->where('s.region_id',$this->regionID);
				//$this->db->from('rmn_asset_master a');
			}
			return $this->db->get('rmn_model_master m')->result_array();
		}else{
			$this->db->select('count(DISTINCT(m.model_id)) AS count');
		if($this->regionID!=''){
				$this->db->join('rmn_asset_master a','a.model_id=m.model_id');
				$this->db->join('rmn_store_master s','a.asset_store_id=s.store_id');
				$this->db->where('s.region_id',$this->regionID);
				//$this->db->from('rmn_asset_master a');
			}
			return $this->db->get('rmn_model_master m')->row()->count;
		}
	}
	//get active asset who has been  expired ---Praveen 13-10-2018
	public function get_active_expired_asset($export =''){
		$asset=array();
		$result=array();
		$expired = $this->expired_asset_list();
		$count_active_expired = count($expired);
		if(count($expired)>0){
			foreach($expired as $expire){
				$asset[]=$expire['asset_id'];
			}
			$this->db->select('DISTINCT(h.asset_id),h.asset_service_tag,datediff(curdate(),date(a.asset_expiry_date))as days');
			$this->db->where_in('h.asset_id',$asset);
			$this->db->join('rmn_asset_master a','a.asset_id = h.asset_id','left');
			$result = $this->db->get('rmn_asset_hearbeat h')->result_array();
			if($export ==''){
				$result['total']=$count_active_expired;
			}
		}
		return $result;
	}
	// get  inactive asset more than  3 days ---Praveen 13-10-2018
	public function get_inactive_asset(){
		$result=array();
		$this->db->select('a.asset_id');
		$this->db->where('a.asset_status',1);
		if ($this->regionID!=''){
			$this->db->join('rmn_store_master s','s.store_id=a.asset_store_id');
			$this->db->where('s.region_id',$this->regionID);
		}
		$active_asset = $this->db->get('rmn_asset_master a')->result_array();
		foreach($active_asset as $asset){
			$detail=array();
			$this->db->select('datediff(curdate(),date(max(h.pingdatetime))) AS diff,a.asset_service_tag');
			$this->db->where('h.asset_id',$asset['asset_id']);
			$this->db->join('rmn_asset_master a','h.asset_id=a.asset_id','left');
			$res=$this->db->get('rmn_asset_hearbeat h')->row();
			if($res->diff >3){
				$detail['asset_id']=$asset['asset_id'];
				$detail['days']=$res->diff;
				$detail['service_tag']=$res->asset_service_tag;
				$result[] = $detail;
			}
		}
		return $result;
	}
}
