<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('dashboard_model');
	}
	public function index(){
		$data = array();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$data['asset_report']=$this->dashboard_model->current_asset_report();
		$schedule_report=$this->dashboard_model->schedule_reports();
		$data['schedule_report']=$schedule_report['sch'];
		$data['total']=$schedule_report['count'];
		$region_report =$this->dashboard_model->get_region();
		$data['region_report']=$region_report;
		$data['store_report']=$this->dashboard_model->get_store_report();
		$data['total_playlists']=$this->dashboard_model->getplaylistdetail();
		$data['total_models']=$this->dashboard_model->get_all_model();
		$data['active_expired_assets']=$this->dashboard_model->get_active_expired_asset();
		$data['inactive_asset']=$this->dashboard_model->get_inactive_asset();
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'user-dashboard',$data);
	}
	// get asset details   Praveen---15/10/18
	public function getassetdetail($type,$ast_status = ''){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->getassetdetail($ast_status,'',1);
		$config['total_rows'] = $total_row;
		if($type =='asset'){
			$segment = 5;  // get the segment from the url for page count based on asset report.
			$config["base_url"]=base_url(). "dashboard/getassetdetail/".$type.'/'.$ast_status;
		}
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$result['asset_detail'] = $this->dashboard_model->getassetdetail($ast_status,'',2,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'asset_detail',$result);
	}
	// get schedule details 
	public function getscheduledetail($sch_status = ''){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->getscheduledetail($sch_status,1);
		$config['total_rows'] = $total_row;
		$segment = 4;  // get the segment from the url for page count based on asset report.
		$config["base_url"]= base_url().'dashboard/getscheduledetail/'.$sch_status;
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$result['scheduler'] = $this->dashboard_model->getscheduledetail($sch_status,2,$params);
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'scheduler_detail',$result);
	}
	
	// get asset  details based on region
	public function getasset_based_region($type,$region_id,$status){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->getassetbased_region($status,1,'',$region_id);
		$config['total_rows'] = $total_row;
		if($type =='region'){
			$segment = 6;  // get the segment from the url for page count based on asset report.
			$config["base_url"]= base_url().'dashboard/getasset_based_region/'.$type.'/'.$region_id.'/'.''.'/'.$status;
		}
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$result['region_asset'] = $this->dashboard_model->getassetbased_region($status,2,$params,$region_id);
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'asset_detail',$result);
	}
	//get playlist details --Praveen 15/10/18
	public function getplaylistdetail(){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->getplaylistdetail();
		$config['total_rows'] = $total_row;
		$segment = 3;  // get the segment from the url for page count based on asset report.
		$config["base_url"]= base_url().'dashboard/getplaylistdetail';
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$result['playlist'] = $this->dashboard_model->getplaylistdetail('2',$params);
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'playlist_detail',$result);
	}
	//get model details --Praveen 15/10/18
	public function getmodeldetail(){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->get_all_model();
		$config['total_rows'] = $total_row;
		$segment = 3;  // get the segment from the url for page count based on asset report.
		$config["base_url"]= base_url().'dashboard/getmodeldetail';
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$result['model'] = $this->dashboard_model->get_all_model('2',$params);
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'model_detail',$result);
	}
	//get asset details based store --Praveen 15/10/18
	public function getasset_based_store($type ,$store_id = ''){
		$result = array();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$total_row = $this->dashboard_model->getassetdetail('','',1);
		$config['total_rows'] = $total_row;
		$segment = 5;  // get the segment from the url for page count based on asset report.
		$config["base_url"]= base_url().'dashboard/getasset_based_store/'.$type;
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$result['sno'] = $page;
		}else{
			$page=0;
			$result['sno'] = 0;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$result['store_asset'] = $this->dashboard_model->getassetdetail('',$store_id,2);
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'asset_detail',$result);
	}
	
	//Export the report Praveen 13-10-2018
	public function export($action=''){
        //echo $action;exit;
		if($action=='store'){
			$filename = 'storeassetreport_'.date('Ymd').'.csv';
		}elseif($action=='inactiveasset'){
			$filename = 'storeassetreport_'.date('Ymd').'.csv';
		}elseif($action =='activeexpired'){
			$filename = 'activeexpiredassetreport_'.date('Ymd').'.csv';
		}
		else if($action=='getplaylistdetail'){
			$filename = 'playlistdetail_'.date('Ymd').'.csv';
			
		}
		else if($action=='getmodeldetail'){
			$filename = 'modeldetail_'.date('Ymd').'.csv';
		}
		else if($action=='getasset_based_store'){//echo 'hii';
			$filename = 'assetbasedstore_'.date('Ymd').'.csv';
		}
		else if($action=='getasset_based_region'){
			$filename = 'assetbasedregion_'.date('Ymd').'.csv';
		}
		
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-type: text/csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		// get data
		$sn=1;
		if($action=='store'){
			$usersData = $this->dashboard_model->get_store_report();
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Store Name","No Of Asset");
			fputcsv($file, $header);
			foreach($usersData as $line){
				$item['s_no']=$sn;
				$item['store_name']=$line['store_name'];
				$item['total_asset']=$line['count'];
				fputcsv($file,$item);
				$sn++;
			}
		}elseif($action=='inactiveasset'){
			$usersData = $this->dashboard_model->get_inactive_asset();
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Service Tag Name","No Of Asset");
			fputcsv($file, $header);
			foreach($usersData as $line){
				$item['s_no']=$sn;
				$item['service_tag_name']=$line['service_tag'];
				$item['days'] = $line['days'];
				fputcsv($file,$item);
				$sn++;
			}
		}
		elseif($action=='activeexpired'){
			$usersData = $this->dashboard_model->get_active_expired_asset(1);
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Service Tag Name","No Of Asset");
			fputcsv($file, $header);
			foreach($usersData as $line){
				$item['s_no']=$sn;
				$item['service_tag_name']=$line['asset_service_tag'];
				$item['days'] = $line['days'];
				fputcsv($file,$item);
				$sn++;
			}
		}
		else if($action=='getplaylistdetail'){
			$usersData = $this->dashboard_model->getplaylistdetail(2);
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Playlist ID","Playlist Name");
			fputcsv($file, $header);
			foreach($usersData as $line){
				$item['s_no']=$sn;
				$item['play_list_id']=$line['playlist_id'];
				$item['play_list_name'] = $line['playlist_name'];
				fputcsv($file,$item);
				$sn++;
			}
		}
		else if($action=='getmodeldetail'){
				$usersData = $this->dashboard_model->get_all_model(2);
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","Model ID","Model Name");
				fputcsv($file, $header);
				foreach($usersData as $line){//print_r($usersData);exit;
					$item['s_no']=$sn;
					$item['play_list_id']=$line['model_id'];
					$item['play_list_name'] = $line['model_name'];
					fputcsv($file,$item);
					$sn++;
				}
			}
			else if($action=='getasset_based_store'){//echo 'helo';echo $filename;
				$usersData = $this->dashboard_model->getassetdetail('',$this->uri->segment(4),2);
				//print_r($usersData);exit;
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","Asset Code","Service Tag","Location","Store code","Store name","Store Contact Number");
				fputcsv($file, $header);		
				foreach($usersData as $line){//print_r($line);exit;
					$item['s_no']=$sn;
					$item['Asset_code']=$line['asset_id'];
					$item['service_tag'] = $line['asset_service_tag'];
					$item['Location'] = $line['region_name'];
					$item['Store_code'] = $line['store_code'];
					$item['Store_name'] = $line['store_name'];
					$item['Store_contact_number'] = $line['store_contact_number'];//print_r($item);exit;
					fputcsv($file,$item);
					$sn++;
				}
			}
			else if($action=='getasset_based_region'){
				$result = array();
				$params['limit'] = RECORDS_PER_PAGE;
				$segment = 3;
				$config = $this->config->item('pagination');
				if($this->uri->segment($segment)){
					$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
					$result['sno'] = $page;
				}else{
					$page=0;
					$result['sno'] = 0;
				}
				$params['offset'] = $page;
				$usersData = $this->dashboard_model->getassetbased_region($this->uri->segment(4),$this->uri->segment(5),2,$params);
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","Asset Code","Service Tag","Location","Store code","Store name","Store Contact Number");
				fputcsv($file, $header);
				foreach($usersData as $line){
					$item['s_no']=$sn;
					$item['Asset_code']=$line['asset_id'];
					$item['service_tag'] = $line['service_tag'];
					$item['Location'] = $line['location'];
					$item['Store_code'] = $line['asset_store_id'];
					$item['Store_name'] = $line['store_name'];
					$item['Store_contact_number'] = $line['Store_contact_number'];
					fputcsv($file,$item);
					$sn++;
				}
			}
	
		fclose($file);
		exit;
	}
	
	
	
	/*
	 * To get the region wise export Details
	 */
	public function exportforregion($region_id,$status=null){
		$filename="region_detail.csv";
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-type: text/csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		$usersData = $this->dashboard_model->getassetbased_region($status,2,'',$region_id);
		//print_r($usersData);exit;
		$file = fopen('php://output', 'w');
		$item=array();
		
		$title=($status=="all"?array("Region Based Asset Report(Active/Inactive)"):($status=="active"?array("Region Based Active Asset Report"):($status=="inactive"?array("Region Based Inactive Asset Report"):array("Region Based Expired Asset Report")))); //To provide heading to the report
		fputcsv($file,$title);		
		$header = array("S.No","Asset Code","Service Tag","Location","Store code","Store name","Store Contact Number");
		fputcsv($file,$header);
		$sn=1;
		foreach($usersData as $line){
			$item['s.no']=$sn;
			$item['Asset_code']=$line['asset_code'];
			$item['asset_service_tag']=$line['asset_service_tag'];
			$item['Region']=$line['region_name'];
			$item['Store_code']=$line['store_code'];
			$item['Store_name']=$line['store_name'];
			$item['Store_contact']=$line['store_contact_number'];
			fputcsv($file,$item);
			$sn++;
		}
		fclose($file);
		exit;
	}
}
