
<div class="bg_white col-md-12">
	<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow p_top">
	 	<div class="box-body">	
	 		<div class="pull-right">
	 		
		 		<a href="<?php if(isset($count_active_asset['sch_name'])){
									echo base_url('report/getschedulereport');
							  	}elseif (isset($count_active_asset['brand_name'])){
									echo base_url().'report/getbrandreport';
								}elseif(isset($count_active_asset['region_name'])){
									echo base_url('report/getregionreport');
								}elseif(isset($count_active_asset['city_name'])){
									echo base_url('report/getcityreport');
								}elseif(isset($count_active_asset['store_name'])){
									echo base_url('report/getstorereport');
								}elseif(isset($count_active_asset['store_based_name'])){
						 			echo base_url('report/getstorebasedassetreport');
								}else{
						 			echo base_url('report/getassetreport');
								}
								?>"	class="btn btn-success btn-xs ">Go back
				</a>
				<a href='<?php echo base_url().'report/exportforactiveorinactive/'.$this->uri->segment (3).'/'.$this->uri->segment (4).'/'.$this->uri->segment (5).'/'.$this->uri->segment (6).'/'.$this->uri->segment (7) ?>'
					class="btn btn-success btn-xs m_left_10">Export<span
					class="glyphicon glyphicon-export"></span>
				</a>
			</div>
			<h3 class="cmn_tit_main activ_asset"><?php
		        if ($this->uri->segment ( 3 ) == 'scheduler') {
					echo $count_active_asset ['sch_name'].' '.ucfirst($this->uri->segment(5)).' Asset Report';
					echo'</br>'.''.	date_from_to ( $this->uri->segment ( 6 ), $this->uri->segment ( 7 ) );
				} elseif ($this->uri->segment ( 3 ) == 'brand') {
					echo  $count_active_asset ['brand_name'].' '.ucfirst($this->uri->segment(5)). ' Asset Report';
				} elseif ($this->uri->segment ( 3 ) == 'region') {
					echo $count_active_asset ['region_name'].' '.ucfirst($this->uri->segment(5)). ' Asset Report';
				} elseif ($this->uri->segment ( 3 ) == 'asset') {
					echo ucfirst($this->uri->segment(5)). ' Asset Report At ' . time_am_pm ( $this->uri->segment ( 4 ) );
					echo '</br><span class="from_date"><strong>Date :</strong>'.''.date('d-m-Y',strtotime($this->uri->segment ( 6 ))).'</span>';
				} elseif ($this->uri->segment ( 3 ) == 'city') {
					echo $count_active_asset ['city_name'].' '.ucfirst($this->uri->segment(5)). ' Asset Report';
				} elseif(($this->uri->segment ( 3 ) == 'store')){
					echo $count_active_asset ['store_name'].' '.ucfirst($this->uri->segment(5)). ' Asset Report';
				} ?> 
				
			</h3>
		    <table id="master_datatables" class="table table-striped">
				 <thead>
					<tr>
						<th>S.No</th>
						<th>Asset Code</th>
						<th>Service tag</th>
						<th>Location</th>
						<th>Store code</th>
						<th>Store name</th>
						<th>Store Contact Number</th>
					</tr>
				  </thead>
				  <tbody>
                    <?php $inc = $sno + 1;foreach ( $count_active_asset ['data'] as $active_asset ) {?>
	                    <tr>
							<td><?php echo $inc; ?></td>
							<td><?php echo $active_asset['asset_code']; ?></td>
							<td><?php echo $active_asset['asset_service_tag']; ?></td>
							<td><?php echo $active_asset['region_name']; ?></td>
							<td><?php echo $active_asset['store_code']; ?></td>
							<td><?php echo $active_asset['store_name']; ?></td>
							<td><?php echo $active_asset['store_contact_number']?>
						</tr>
                    <?php $inc ++;}?>
                </tbody>
		    </table>
			<div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
            </div>
	</div>
  </div>
</div>