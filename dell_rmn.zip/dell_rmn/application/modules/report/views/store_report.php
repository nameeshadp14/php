 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
	    <h3 class="cmn_tit_main activ_asset">Store Report
	    <a href='<?php echo base_url().'report/exportformodule'.'/store/'.$fr_date.'/'.$to_date ?>' class="btn btn-success btn-xs pull-right">Export<span class="glyphicon glyphicon-export"></span></a>
	    </h3>
	    <form action="<?php echo base_url('report/getstorereport');?>" method="get">
			<div class="form-group col-xs-4 p_left">
				 <input data-toggle="tooltip" class="form-control" type="text" name="store_st_date" id="store_st_date"  title="" readonly value="<?php echo $this->input->get('store_st_date')==''? '':$this->input->get('store_st_date');?>" placeholder="Filter by From Date" data-original-title="Filter by from Date">
			 </div>
			 <div class="form-group col-xs-4 ">
				   <input data-toggle="tooltip" class="form-control" type="text" name="store_ed_date" id="store_ed_date" title="" readonly value="<?php echo $this->input->get('store_ed_date')==''? '':$this->input->get('store_ed_date');?>" placeholder="Filter by End Date" data-original-title="Filter by End Date">
			 </div>
		   	<div class="form-group col-xs-4 text-right p_right">
				<input type="submit" name="Search_btn" class="btn btn-primary" value="Search">
			    <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('report/getstorereport')?>'" value="Reset">
			</div>
		 </form>
		  <?php if(count($count_store_report)== 0) { ?>
	   		<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		  <?php }else{ ?>
				<h3>Total Number of Assets Registered - <?php echo $total ?></h3>
				<h3 >Total Number of Stores Registered - <?php echo $total_store?></h3>
				<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow align_height">
				   <div class="box-body">
	                	<table id="master_datatables" class="table table-striped"  >
		               		<thead>
		                   		 <tr>
									<th>Store Name</th>
									<th>Active</th>
									<th>Inactive</th>
		                   		 </tr>
		                    </thead>
		                    <tbody>
			                    <?php foreach($count_store_report as $store){?>
			                    <tr>
			                    <td><?php echo $store['store_name']?></td>
			                    <?php if($store['active']>0) {?>
			                    <td><a href="<?php echo  base_url().'report/get_status_report/'.'store/'.$store['store_id'].'/active/'.$store['fr_date'].'/'.$store['to_date'].'/'?>"><?php echo $store['active']?></a></td>
			                    <?php }else{?>
			                    <td><?php echo $store['active']?></td>
			                    <?php }?>
			                    <?php if($store['inactive']>0){?>
			                    <td><a href="<?php echo base_url().'report/get_status_report/'.'store/'.$store['store_id'].'/inactive/'.$store['fr_date'].'/'.$store['to_date'].'/'?>"><?php echo $store['inactive']?></a></td>
			                    <?php }else{?>
			                    <td><?php echo $store['inactive']?></td>
			                    <?php }?>
			                    </tr>
			                    <?php }?>
		                    </tbody>
		                </table>
	                	<div class="pull-right">
	                   		 <?php echo $this->pagination->create_links(); ?>                    
	                	</div>                
	           	 </div>
				</div>
			<?php }?>
	
	</div>
</div>





