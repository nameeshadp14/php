 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h3 class="cmn_tit_main activ_asset">City Report
		<a href='<?php echo base_url().'report/exportformodule'.'/city/'.$fr_date.'/'.$to_date?>' class="btn btn-success btn-xs pull-right">Export<span class="glyphicon glyphicon-export"></span></a>
		</h3>
		<form action="<?php echo base_url('report/getcityreport');?>" method="get">
			<div class="form-group col-xs-4 p_left">
			    <input data-toggle="tooltip" class="form-control" type="text" name="city_st_date" id="city_st_date"  title="" readonly value="<?php echo $this->input->get('city_st_date')==''? date("d-m-Y"):$this->input->get('city_st_date');?>" placeholder="Filter by From Date" data-original-title="Filter by from Date">
			</div>
		    <div class="form-group col-xs-4 ">
			   	<input data-toggle="tooltip" class="form-control" type="text" name="city_ed_date" id="city_ed_date" title="" readonly value="<?php echo $this->input->get('city_ed_date')==''? date("d-m-Y"):$this->input->get('city_ed_date');?>" placeholder="Filter by End Date" data-original-title="Filter by End Date">
			</div>
			<div class="form-group col-xs-4 text-right p_right" >
			    <input type="submit" name="Search_btn" class="btn btn-primary" value="Search">
			    <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('report/getcityreport')?>'" value="Reset">
			</div>
		 </form>
		
		<?php if(count($city_list)== 0) { ?>
			<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		<?php }else{ ?>
					<h3>Total Number of Assets Registered - <?php echo $total ?></h3>
					<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow align_height">
			   			<div class="box-body">
		               		 <table id="master_datatables" class="table table-striped"  >
		               		 		<thead>
			                    		<tr>
											<th>City Name</th>
											<th>Active</th>
											<th>Inactive</th>
			                  			</tr>
		                   			 </thead>
			                    	 <tbody>
					                    <?php foreach($city_list as $city){?>
					                    
					                    <tr>
					                    <td><?php echo $city['city_name']?></td>
					                    <?php if($city['active']>0) {?>
					                    <td><a href="<?php echo base_url().'report/get_status_report/'.'city/'.$city['city_id'].'/active/'.$city['fr_date'].'/'.$city['to_date']?>"><?php echo $city['active']?></a></td>
					                    <?php }else{?>
					                    <td><?php echo $city['active']?></td>
					                    <?php }?>
					                    <?php if($city['inactive']>0){?>
					                    <td><a href="<?php echo base_url().'report/get_status_report/'.'city/'.$city['city_id'].'/inactive/'.$city['fr_date'].'/'.$city['to_date']?>"><?php echo $city['inactive']?></a></td>
					                    <?php }else{?>
					                    <td><?php echo $city['inactive']?></td>
					                    <?php }?>
					                    </tr>
					                    <?php }?>
					                 </tbody>
		                		</table>
               					 <div class="pull-right">
                    				<?php echo $this->pagination->create_links(); ?>                    
                				</div>                
           				 </div>
					</div>
		<?php }?>
	
	</div>
</div>





