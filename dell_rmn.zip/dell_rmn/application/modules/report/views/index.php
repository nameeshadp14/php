 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">Brand Report
			<a href='<?php echo base_url() ?>report/exportCSV' class="btn btn-success btn-xs pull-right">Export<span class="glyphicon glyphicon-export"></span></a>
		</h2>
		<form action="<?php echo base_url('report')?>" method="get">
			<?php if(count($brand_list)== 0) { ?>
			<h3 class="text-center">No result found</h3>
			<?php }else{ ?>
				<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
				   <div class="box-body">
	                	<table id="master_datatables" class="table table-striped"  >
	               			<thead>
	                   			 <tr>
									<th>S.No</th>
									<th>Brand Name</th>
									<th>Active</th>
									<th>Inactive</th>
			                    </tr>
	                    	</thead>
	                    	<tbody>
			                    <?php
				                     $cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				                     $inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
				                     foreach($brand_list as $brand){ ?>
					                    <tr>
											<td><?php echo $inc++; ?></td>
											<td><?php echo $brand['brand_name']; ?></td>
											<td><?php if ($brand['brand_status']==1){?><span class="glyphicon glyphicon-ok"></span><?php }?> </td>
											<td><?php if ($brand['brand_status']==0){?><span class="glyphicon glyphicon-remove"></span><?php }?> </td>
					                    </tr>
			                    <?php } ?>
	                       </tbody>
	                  </table>
	                  <div class="pull-right">
	                     <?php echo $this->pagination->create_links(); ?>                    
	                  </div>                
	              </div>
			  </div>
		  <?php } ?>
	</form>
  </div>
</div>





