<?php
defined('BASEPATH') OR exit('No direct script access  allowed');
class Report extends BSS_Controller{
	
	public function __construct(){
	      parent::__construct();
	     $this->isAdmin || $this->isEditor ||$this->isUser  || $this->isRegion? true :redirect("unauthorize");
		 $this->load->model('report_model');
		
	}
	/*
	 * Store Based Asset Report
	 */
	
	public function getstorebasedassetreport(){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$config=$this->config->item('pagination');
		$params['limit']=RECORDS_PER_PAGE;
		$config['base_url']=base_url(). "report/getstorebasedassetreport";//print_r($_GET);exit;
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		//echo $config['first_url'];exit;
		$total_row=$this->report_model->get_store_based_asset_report('',$params,1,$filter_data,'','');
		$config['total_rows']=$total_row;
		if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
			$data['sno'] = $page;
		}else{
			$page=0;
			$data['sno'] =0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$store=$this->report_model->get_store_based_asset_report('',$params,2,$filter_data);
		$data['store_report']=$store['data'];
		//$data['count']=$store['count'];//echo $data['count'];exit;
	    $data['fr_date']=$store['fr_date'];
	    $data['to_date']=$store['to_date'];//echo $data['fr_date'];exit;
	    $data['total']=$store['total'];
	   // $data['count']=$store['count'];
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title',' Store based Assets Report');
		$this->template->set('page_breadcrumb',' Store based Assets Report');
		$this->template->load('template','contents','store_based_asset',$data);
	}
	
   /*
    * Asset Report
    */	
	
	public function getassetreport(){
		$data=array();
		$filter_data=$this->input->get();
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title','Asset Report');
		$this->template->set('page_breadcrumb','Asset Report');
		$result=$this->report_model->get_all_asset_report($filter_data);
		$data['count_asset_report']=$result['data'];
		$data['fr_date']=$result['fr_date'];
		$data['total']=$result['count'];
		$this->template->load('template','contents','asset_report',$data);
	}
	
	/*
	 * common report for all module
	 */
	
	public function get_status_report($report_type,$id,$action,$fr_date=null,$to_date=null){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit']=RECORDS_PER_PAGE;
		$config=$this->config->item('pagination');
		$total_row=$this->report_model->heartbeat_assest($report_type,$id,$action,$fr_date,$to_date,1);
		if($report_type=='asset'){
			$segment=7;  // get the segment from the url for page count based on asset report. 
			$config["base_url"]=base_url(). "report/get_status_report/".$report_type.'/'.$id.'/'.$action.'/'.$fr_date;
		}else{
			$segment=8;  // get the segment from the url for page count based on report(like scheduler,city,brandand region). 
			$config["base_url"]=base_url(). "report/get_status_report/".$report_type.'/'.$id.'/'.$action.'/'.$fr_date.'/'.$to_date;
		}
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$config['total_rows']=$total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment($segment)){
			$page=(($this->uri->segment($segment)-1)*$config["per_page"]);
			$data['sno']=$page;
		}else{
			$page=0;
			$data['sno']=0;
		}
		$params['offset']=$page;
		$data['count_active_asset']=$this->report_model->heartbeat_assest($report_type,$id,$action,$fr_date,$to_date,2,$params);
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title','Report');
		$this->template->set('page_breadcrumb','Report');
		$this->template->load('template','contents','common_report',$data);
	}
	
	/*
	 * Scheduler Report
	 */
	
	public function getschedulereport(){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit']=RECORDS_PER_PAGE;
		$config=$this->config->item('pagination');
		$config["base_url"]=base_url(). "report/getschedulereport";
		$total_row=$this->report_model->getallschedulereport($filter_data,$params,1);
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$config['total_rows']=$total_row;
		if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
		}else{
			$page=0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$result=$this->report_model->getallschedulereport($filter_data,$params,2);
		$data['count_active_asset_schedule']=$result['data'];
		$data['total']=$result['count'];
		$data['fr_date']=$result['fr_date'];
		$data['to_date']=$result['to_date'];
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title',' Schedule Report');
		$this->template->set('page_breadcrumb',' Schedule Report');
		$this->template->load('template','contents','schedule_report',$data);
	}
		
	/*
	 * Brand Report
	 */
	public function getbrandreport(){
		$data=array();
		$params=array();
		$params['limit']=RECORDS_PER_PAGE;
		$filter_data=$this->input->get();
		$config=$this->config->item('pagination');
		$config["base_url"]=base_url(). "report/getbrandreport";
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$total_row=$this->report_model->get_brand_report($filter_data,$params,1);
		$config['total_rows']=$total_row;
			if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
		}else{
			$page=0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$result=$this->report_model->get_brand_report($filter_data,$params,2);
		$data['brand_list']=$result['data'];
		$data['total']=$result['count'];
		$data['fr_date']=$result['fr_date'];
		$data['to_date']=$result['to_date'];
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title',' Brand Report');
		$this->template->set('page_breadcrumb','Brand Report');
		$this->template->load('template','contents','brand_report',$data);
	}
	/*
	 * Region wise report
	 */
	public function getregionreport(){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$config=$this->config->item('pagination');
		$params['limit']=RECORDS_PER_PAGE;
		$config['base_url']=base_url()."report/getregionreport";
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$total_row=$this->report_model->get_all_region_report($filter_data,$params,1);
		$config['total_rows']=$total_row;
		if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
		}else{
			$page=0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$result=$this->report_model->get_all_region_report($filter_data,$params,2);
		$data['region_list']=$result['data'];
		$data['total']=$result['count'];
		$data['fr_date']=$result['fr_date'];
		$data['to_date']=$result['to_date'];
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title',' Region Report');
		$this->template->set('page_breadcrumb','Region Report');
		$this->template->load('template','contents','region_report',$data);
	}
		
	/*
	 * City wise report
	 */
	
	public function getcityreport(){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$config=$this->config->item('pagination');
		$params['limit']=RECORDS_PER_PAGE;
		$config['base_url']=base_url()."report/getcityreport";
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$total_row=$this->report_model->get_all_city_report($filter_data,$params,1);
		$config['total_rows']=$total_row;
		if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
		}else{
			$page=0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$result=$this->report_model->get_all_city_report($filter_data,$params,2);
		$data['city_list']=$result['data'];
		$data['total']= $result['count'];
		$data['fr_date']=$result['fr_date'];
		$data['to_date']=$result['to_date'];
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title','City Report');
		$this->template->set('page_breadcrumb','City Report');
		$this->template->load('template','contents','city_report',$data);
	}
	
	//Store wise report ---- praveen 10/10/2018
	public function getstorereport(){
		$data=array();
		$params=array();
		$filter_data=$this->input->get();
		$config=$this->config->item('pagination');
		$params['limit']=RECORDS_PER_PAGE;
		$config['base_url']=base_url()."report/getstorereport";
		$config['first_url']=$config['base_url'].'?'.http_build_query($_GET);
		$filter_data=$this->input->get();
		$this->template->set('title',$this->config->item('app_name'));
		$this->template->set('page_title','Store Report');
		$this->template->set('page_breadcrumb','Store Report');
		$total_row=$this->report_model->get_all_store_report($filter_data,$params,1);
		$config['total_rows']=$total_row;
		if($this->uri->segment(3)){
			$page=(($this->uri->segment(3)-1)*$config["per_page"]);
		}else{
			$page=0;
		}
		$params['offset']=$page;
		$this->pagination->initialize($config);
		$result=$this->report_model->get_all_store_report($filter_data,$params,2);
		$data['count_store_report']=$result['data'];
		$data['fr_date']=$result['fr_date'];
		$data['to_date']=$result['to_date'];
		$data['total']=$result['count'];
		$data['total_store']=$result['total_store'];
		//print($data['total_store']);exit;
		$this->template->load('template','contents','store_report',$data);
		
	}
	
	/*
	 * 
	 * Export for No of active or inactive assets
	 */	
	
	public function exportformodule($report_type,$fr_date=null,$to_date=null){
		// file name
		if($report_type=='scheduler'){
			$filename = 'ScheduleReports_'.date('Ymd').'.csv';
    	}else if($report_type=='asset'){
			$filename = 'AssetReports_'.date('Ymd').'.csv';
		}elseif($report_type=='brand'){
			$filename='BrandReports_'.date('Ymd').'.csv';
		}elseif($report_type=='region'){
			$filename = 'RegionReports_'.date('Ymd').'.csv';
		}elseif($report_type=='city'){
			$filename='CityReports_'.date('Ymd').'.csv';
		}elseif($report_type == 'store'){
			$filename='StoreReports_'.date('Ymd').'.xlsx';
		}elseif($report_type=='storebasedassets'){
			$filename='StoreBasedAssetsReport_'.date('Ymd').'.xlsx';
		}
		
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-type: text/csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		// get data
		if($report_type=='scheduler'){
			$usersData = $this->report_model->getallschedulereport($filter=array(),$params=array(),2,$fr_date,$to_date);
	        // file creation
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Scheduler Name","Active","Inactive");
			fputcsv($file, $header);
			$sn=1;
			foreach($usersData['data'] as $line){
				$item['s.no']=$sn;
				$item['Scheduler Name']=$line['sch_name'];
				$item['Active']=$line['active'];
				$item['Inactive']=$line['inactive'];
				fputcsv($file,$item);
				$sn++;
			}
		}elseif($report_type=='asset'){
			$usersData = $this->report_model->get_all_asset_report($filter=array(),$params=array(),2,$fr_date);
			// file creation
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Timming","Active","Inactive");
			fputcsv($file, $header);
			$sn=1;
			foreach($usersData['data'] as $line){
				$item['s.no']=$sn;
				$item['Timming']=$line['time'];
				$item['Active']=$line['active'];
				$item['Inactive']=$line['inactive'];
				fputcsv($file,$item);
				$sn++;
			}
		}elseif($report_type=='brand'){
			$usersData = $this->report_model->get_brand_report($filter=array(),$params=array(),2,$fr_date,$to_date);
			// file creation
			$file = fopen('php://output', 'w');
			$item=array();
			$header = array("S.No","Brand Name","Active","Inactive");
			fputcsv($file, $header);
			$sn=1;
			foreach($usersData['data'] as $line){
				$item['s.no']=$sn;
				$item['Brand Name']=$line['brand_name'];
				$item['Active']=$line['active'];
				$item['InActive']=$line['inactive'];
				fputcsv($file,$item);
				$sn++;
			}
		}elseif($report_type=='region'){
				$usersData = $this->report_model->get_all_region_report($filter=array(),$params=array(),2,$fr_date,$to_date);
				// file creation
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","Region Name","Active","Inactive");
				fputcsv($file, $header);
				$sn=1;
				foreach($usersData['data'] as $line){
					$item['s.no']=$sn;
					$item['Region Name']=$line['region_name'];
					$item['Active']=$line['active'];
					$item['Inactive']=$line['inactive'];
					fputcsv($file,$item);
					$sn++;
				}
		}elseif($report_type=='city'){
				$usersData = $this->report_model->get_all_city_report($filter=array(),$params=array(),2,$fr_date,$to_date);
				// file creation
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","City Name","Active","Inactive");
				fputcsv($file, $header);
				$sn=1;
				foreach($usersData['data'] as $line){
					$item['s.no']=$sn;
					$item['City Name']=$line['city_name'];
					$item['Active']=$line['active'];
					$item['Inactive']=$line['inactive'];
					fputcsv($file,$item);
					$sn++;
				}
			}elseif($report_type == 'store'){
				$usersData = $this->report_model->get_all_store_report($filter =array(),$params =array(),2,$fr_date,$to_date);
				$file = fopen('php://output','w');
				$item =array();
				$header=array("S.No","Store Name","Active","Inactive");
				fputcsv($file,$header);
				$sn=1;
				foreach($usersData['data'] as $line){
					$item['s.no'] = $sn;
					$item['Store Name'] = $line['store_name'];
					$item['Active'] = $line['active'];
					$item['Inactive'] = $line['inactive'];
					fputcsv($file,$item);
					$sn++;
				}
			}elseif($report_type == 'storebasedassets'){
			
				$data= $this->report_model->get_store_based_asset_report('','',2);
				$storeData=$data['data'];
				//print_r($storeData);exit;
				$file = fopen('php://output', 'w');
				$item=array();
				$header = array("S.No","Store Code","Store Name","No Of Asset");
				fputcsv($file, $header);
				$sn=1;
				foreach($storeData as $line){
					$item['s_no']=$sn;
					$item['store_code']=$line['store_code'];//echo $line['store_code'];exit;
					$item['store_name']=$line['store_name'];
					$item['total_asset']=$line['count'];
					fputcsv($file,$item);
					$sn++;
				}

			}
			
	
		fclose($file);
		exit;
	}
		
	/*
	 * Export List of all Asset active or inactive report for all module
	 */
	
	public function exportforactiveorinactive($report_type,$id,$action,$fr_date=null,$to_date=null){
		// file name
		if($report_type=='scheduler'){
			$filename = $action.'_ScheduleReports_'.date('Ymd').'.csv';
		}else if($report_type=='asset'){
			$filename = $action.'_AssetReports_'.date('Ymd').'.csv';
		}elseif($report_type=='brand'){
			$filename=$action.'_BrandReports_'.date('Ymd').'.csv';
		}elseif($report_type=='region'){
			$filename = $action.'_RegionReports_'.date('Ymd').'.csv';
		}elseif($report_type=='city'){
			$filename=$action.'_CityReports_'.date('Ymd').'.csv';
		}elseif($report_type=='store'){
			$filename=$action.'_StoreReports_'.date('Ymd').'.csv';
		}elseif($report_type=='storebasedassets'){
			$filename=$action.'_StoreBasedAssetsReport_'.date('Ymd').'.csv';
		}
		
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-type: text/csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		// get data
		$usersData = $this->report_model->heartbeat_assest($report_type,$id,$action,$fr_date,$to_date,2);
		$file = fopen('php://output', 'w');
		$item=array();
		$header = array("S.No","Asset Code","Service Tag","Location","Store code","Store name","Store Contact Number");
		fputcsv($file, $header);
		$sn=1;
		foreach($usersData['data'] as $line){
			$item['s.no']=$sn;
			$item['Asset_code']=$line['asset_code'];
			$item['asset_service_tag']=$line['asset_service_tag'];
			$item['Region']=$line['region_name'];
			$item['Store_code']=$line['store_code'];
			$item['Store_name']=$line['store_name'];
			$item['Store_contact']=$line['store_contact_number'];
			fputcsv($file,$item);
			$sn++;
		}
		fclose($file);
		exit;
	}
	
	
}
