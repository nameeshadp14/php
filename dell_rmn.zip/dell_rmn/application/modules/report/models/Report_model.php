<?php
class Report_model extends CI_Model{
	public function __construct(){
		parent::__construct();
		
	}
	
	/*
	 * get store based assets report
	 */
	
	
	public function get_store_based_asset_report($store ='',$params=null,$val=null,$filter_data=null,$fr_date=null,$to_date=null){
		$result = array();
		$data =array();
		$cur_date=date('Y-m-d');
			if(isset($filter_data['reg_st_date']) && isset($filter_data['reg_ed_date']) && $filter_data['reg_st_date']!='' && $filter_data['reg_ed_date']!=''){
				$first_date=date("Y-m-d",strtotime($filter_data['reg_st_date']));//echo 'hii';	
				$second_date=date("Y-m-d",strtotime($filter_data['reg_ed_date']));
			}elseif($fr_date!=null && $to_date!=null){
				$first_date=urldecode($fr_date);//echo $fr_date;echo '<br>';echo $first_date;exit;
				$second_date=urldecode($to_date);
			}else{
				$first_date=date("Y-m-d",strtotime($cur_date));//echo $cur_date;echo '<br>';echo $first_date;exit;
				$second_date=date("Y-m-d",strtotime($cur_date));
			}
			$this->db->select("COUNT(a.asset_id) AS asset_count");
			$this->db->where('a.asset_status !=',2);
			$this->db->where('a.asset_expiry_date >=',$second_date);
			if($this->regionID!=''){
				$this->db->join('rmn_store_master s','s.store_id=a.asset_store_id');
				$this->db->where('s.region_id',$this->regionID);
			}
			$count_assest=$this->db->get('rmn_asset_master a')->row()->asset_count;
			$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
			$count_assest1=$this->total_count_asset($where_assets);
			$this->db->select('store_id,store_name,store_code');
			if($this->regionID!=''){
				$this->db->where('region_id',$this->regionID);
			}
			if ($val==1){
				$store_count= $this->db->get('rmn_store_master')->num_rows();
				$result=$store_count;
			}
			elseif($val==2){
				if(isset($params) && !empty($params))
				{
					$this->db->limit($params['limit'], $params['offset']);
				}
			$store= $this->db->get('rmn_store_master')->result_array();
			foreach($store as $store){
				$asset_set=0;
				$output = array();
				$this->db->select('a.asset_id');
				$this->db->where('s.store_id',$store['store_id']);
				$this->db->join('rmn_asset_master a','s.store_id = a.asset_store_id','left');
				$this->db->where('a.asset_id is not null');
				$res = $this->db->get('rmn_store_master s')->result_array();
				$result1=array();
				//print_r($res);exit;
				foreach ($res AS $asset){
					$result1[]=$asset['asset_id'];
					//print_r($result1);exit;
				}//echo count($result1);exit;
				if(count($result1)>0){//echo count($result1);exit;
					$result_set=array_unique($result1);//exit('helo');
					$this->db->select('COUNT(DISTINCT asset_id) AS asset');
					$this->db->where_in('asset_id',$result_set);
					$this->db->where('DATE(pingdatetime) >=', $first_date);//echo $second_date;exit;
					$this->db->where('DATE(pingdatetime) <=', $second_date);
					$asset_set=$this->db->get('rmn_asset_hearbeat')->row()->asset;//echo $asset_set;exit;
				}
				//echo $asset_set;exit;
				$output['store_id'] = $store['store_id'];
				$output['store_name'] = $store['store_name'];
				$output['store_code'] = $store['store_code'];
				$output['count'] = $asset_set;//echo $output['count'];exit;
				$output['count1']=$count_assest1;//echo $output['count1'];exit;
				$data[] = $output;
			}
			$result['data']=$data;
			$result['total']=$count_assest;
			$result['fr_date']=$first_date;//echo $first_date;exit;
			$result['to_date']=$second_date;
			//$result['count']=$count_assest1;//echo $result['count'];exit;
			
	     }
		return $result;
		
	}
	
	
	/*
	 * get the active asset_info_list
	 */
	public function active_asset_list($asset,$fm_date=null,$to_date=null){
		//print_r($asset);exit;
		$this->db->select("DISTINCT(ah.asset_id)");
		$this->db->where_in('ah.asset_id', $asset);
		$this->db->where('DATE(ah.pingdatetime) >=', $fm_date);
		$this->db->where('DATE(ah.pingdatetime) <=', $to_date);
		if($this->regionID!=''){
	        $this->db->join('rmn_store_master s','s.store_code=ah.store_code');
			$this->db->where('region_id',$this->regionID);
		}
		$R= $this->db->get('rmn_asset_hearbeat ah')->result_array();
		//print_r($R);exit;
		return $R;
	}
	/*
	 * get the Inactive asset_info_list
	 */
	public function inactive_asset_list($result_asset,$total_asset){
		$active_asset=array();
		if(count($result_asset)>0){
			foreach ($result_asset as $asset_id){
				$active_asset[]=$asset_id['asset_id'];
			}
		}
		if(count($active_asset)>0){
			$inactive_asset=array_diff($total_asset,$active_asset);
		}else{
			$inactive_asset=$total_asset;
		}
		$this->db->select("a.asset_id");
		$this->db->where_in('a.asset_id', $inactive_asset);
		if($this->regionID!=''){
			$this->db->join('rmn_store_master s','s.store_id=a.asset_store_id');
			$this->db->where('s.region_id', $this->regionID);
		}
		return $this->db->get('rmn_asset_master a')->result_array();
	}
	/*
	 * Get all Brand wise report
	 */
	function get_brand_report($filter_data=null,$params=null,$val=null,$fr_date=null,$to_date=null){
		$result1=[];
		$data=[];
		$result=array();
		$cur_date=date('Y-m-d');
		if((isset($filter_data['brd_st_date'] )&& isset($filter_data['brd_ed_date']) && $filter_data['brd_st_date']!='' && $filter_data['brd_ed_date']!='')){
			$first_date=date("Y-m-d",strtotime($filter_data['brd_st_date']));
			$second_date=date("Y-m-d",strtotime($filter_data['brd_ed_date']));
		}
		elseif($fr_date!=null && $to_date!=null){
			$first_date=urldecode($fr_date);
			$second_date=urldecode($to_date);
		}
		else{
			$first_date=date("Y-m-d",strtotime($cur_date));
			$second_date=date("Y-m-d",strtotime($cur_date));
		}
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$count_assest=$this->total_count_asset($where_assets);
		$this->db->where('brand_status!=',-1);
		if($val==1){
			$brand=$this->db->get('rmn_brand_master')->num_rows();
			$result1=$brand;
		}elseif($val==2){
			if(isset($params) && !empty($params))
			{
				$this->db->limit($params['limit'], $params['offset']);
			}
			$brand=$this->db->get('rmn_brand_master')->result_array();
			foreach($brand as $brd){
				$result=array();
				$total_asset=0;
				$active_asset=0;
				$this->db->where('a.asset_status!=',2);
				$this->db->where('b.brand_id',$brd['brand_id']);
				$this->db->select("DISTINCT(asset_id)");
				$this->db->where($where_assets);
				$this->db->join('rmn_model_master as m','m.brand_id=b.brand_id');
				$this->db->join('rmn_asset_master as a','a.model_id=m.model_id');
				$data_brand=$this->db->get('rmn_brand_master as b')->result_array();
				if(count($data_brand)>0){
					foreach ($data_brand AS $val){
						$result[]=$val['asset_id'];
					}
					$total_asset=count($result);
				}
				if(count($result)>0){
					$this->db->select('COUNT(DISTINCT asset_id) AS asset');
					$this->db->where('DATE(pingdatetime) >=', $first_date);
					$this->db->where('DATE(pingdatetime) <=', $second_date);
					$this->db->where_in('asset_id',$result);
					$active_asset=$this->db->get('rmn_asset_hearbeat')->row()->asset;
				}
				$brd_asst['brand_id']=$brd['brand_id'];
				$brd_asst['brand_name']=$brd['brand_name'];
				$brd_asst['active']=$active_asset;
				$brd_asst['inactive']=$total_asset-$active_asset;
				$brd_asst['fr_date']=$first_date;
				$brd_asst['to_date']=$second_date;
				$data[]=$brd_asst;
	  	    }
			$result1['data']=$data;
			$result1['count']=$count_assest;
			$result1['fr_date']=$first_date;
			$result1['to_date']=$second_date;
		}
		return $result1;
	}
	
	
	/*
	 * Get all Asset wise report
	 */
	function get_all_asset_report($data,$params=null,$chk=null,$fr_date=null,$to_date=null){
		$result=array();
		if(isset($data['date']) && $data['date']!=''){
			$cur_date = $data['date'];
		}elseif($fr_date!=null){
			$cur_date=urldecode($fr_date);
		}
		else
		{
			$cur_date=date('Y-m-d');
		}
		$fm_date=date("Y-m-d 00:00:00",strtotime($cur_date));
		$last_date=date("Y-m-d 23:59:59",strtotime($cur_date));
		$this->db->select("COUNT(asset_id) AS asset_count");
		$this->db->where('asset_status!=',2);
		$this->db->where('asset_expiry_date >=',$last_date);
		if($this->regionID!=''){
			$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
			$this->db->where('s.region_id',$this->regionID);
		    
		}
			$count_assest=$this->db->get('rmn_asset_master a')->row()->asset_count;
		$data=[];
		for($i=10;$i<20;$i++){
			$j=$i+1;
			$first_date=date("Y-m-d ".$i.":00:00",strtotime($cur_date));
			$second_date=date("Y-m-d ".$j.":00:00",strtotime($cur_date));
			$this->db->select("COUNT(DISTINCT rmn_asset_hearbeat.asset_id) AS asset");
			$this->db->where('rmn_asset_hearbeat.pingdatetime >=', $first_date);
			$this->db->where('rmn_asset_hearbeat.pingdatetime <=', $second_date);
			if($this->regionID!=''){
				$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
				$this->db->join('rmn_asset_hearbeat as ah', 'ah.asset_id=a.asset_id', 'left');
				$this->db->from('rmn_asset_master a');
				$this->db->where('s.region_id',$this->regionID);
			
			}
			$query=$this->db->get('rmn_asset_hearbeat')->row()->asset;
			//print_r($query);exit;
			$iam=$i>=12?($i-12)<10?$i==12?($i).':00 PM':'0'.($i-12).':00 PM':($i-12).':00 PM':$i.':00 AM';
			$jam=$j>=12?($j-12)<10?$j==12?($j).':00 PM':'0'.($j-12).':00 PM':($j-12).':00 PM':$j.':00 AM';
			
			$count['time']=$iam.' - '.$jam;
			$count['active']=$query;
			$count['inactive']=$count_assest-$query;
			$count['list']=$i;
			$count['total']=$count_assest;
			$count['date']=$cur_date;
			$data[]=$count;
	   }
		$result['data']=$data;
		$result['count']=$count_assest;
		$result['fr_date']=$cur_date;
		return $result;
	}
	/*
	 * Asset for perticuler scheduler id
	 * */
	public function getassets($id,$first_date,$second_date){
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->select('a.asset_id');
		$this->db->where('rs.sch_status !=', -1);
		if($this->regionID!=''){
			$this->db->where('rs.region_id', $this->regionID);
		}
		$this->db->where('rs.sch_id', $id);
		$this->db->where($where_assets);
		$this->db->join('rmn_store_master as s', 'a.asset_store_id=s.store_id', 'left');
		$this->db->join('rmn_region_master as r', 's.region_id=r.region_id', 'left');
		$this->db->join('rmn_scheduler as rs', 'r.region_id=s.region_id', 'left');
		$this->db->where('rs.region_id IS NOT NULL');
		
		$array1 = $this->db->get('rmn_asset_master as a')->result_array();
		//print_r($array1);exit;
	
		$this->db->select('a.asset_id');
		$this->db->where('rs.sch_status !=', -1);
		$this->db->where('rs.sch_id', $id);
		if($this->regionID!=''){
			$this->db->where('rs.region_id', $this->regionID);
		}
		$this->db->where($where_assets);
		$this->db->join('rmn_model_master as m', 'a.model_id=m.model_id', 'left');
		$this->db->join('rmn_model_group_mapping as mg', 'm.model_id=mg.model_id', 'left');
		$this->db->join('rmn_group_master as g', 'mg.group_id=g.group_id', 'left');
		$this->db->join('rmn_scheduler as rs', 'g.group_id=rs.group_id');
		$this->db->where('rs.group_id IS NOT NULL');
		
		$array2 = $this->db->get('rmn_asset_master as a')->result_array();
	
		$this->db->select('a.asset_id');
		$this->db->where('rs.sch_status !=', -1);
		$this->db->where('rs.sch_id', $id);
		if($this->regionID!=''){
			$this->db->where('rs.region_id', $this->regionID);
		}
		$this->db->where($where_assets);
		$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
		$this->db->join('rmn_scheduler as rs', 'rs.store_id=s.store_id');
		$this->db->where('rs.store_id IS NOT NULL');
		
		$array3     = $this->db->get('rmn_asset_master as a')->result_array();
		$merged_arr = array_merge($array1, $array2, $array3);
	
		$result = array();
		foreach ($merged_arr AS $val) {
			$result[] = $val['asset_id'];
		}
		$result_set     = array_unique($result);
		//print_r($result_set);exit;
		return $result_set;
	}
	/*
	 * Scheduler report
	 * */
	
	public function get_scheduler($action_type,$id,$fm_date,$to_date){
		$this->db->select('sch_name');
		$this->db->where('sch_id',$id);
		if($this->regionID!=''){
			$this->db->where('region_id',$this->regionID);
		}
		$schedule_name=$this->db->get('rmn_scheduler')->row()->sch_name;
		$result['sch_name']=$schedule_name;
		$asset=$this->getassets($id,$fm_date,$to_date);
		if(count($asset)>0){//print_r($asset);exit;
			$result_asset=$this->active_asset_list($asset,$fm_date,$to_date);
			//print($result_asset);exit('hii');
			if($action_type == 'active'){
				return $result_asset;
			}else{
				return $this->inactive_asset_list($result_asset,$asset);
			}
		}
	}
	
	/*
	 * Asset report
	 * */
	public function get_asset($action_type,$i,$fm_date){
		//print($region_id);exit;
		$j=$i+1;
		$fr_date=date("Y-m-d ".$i.":00:00",strtotime($fm_date));
		$last_date=date("Y-m-d ".$j.":00:00",strtotime($fm_date));
		$this->db->select("DISTINCT(rmn_asset_hearbeat.asset_id)" );
		$this->db->where('rmn_asset_hearbeat.pingdatetime >=', $fr_date);
		$this->db->where('rmn_asset_hearbeat.pingdatetime <=', $last_date);
		if($this->regionID!=''){
			$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
			$this->db->join('rmn_asset_hearbeat as ah', 'ah.asset_id=a.asset_id', 'left');
			$this->db->where('s.region_id',$this->regionID);
			$this->db->from('rmn_asset_master a');
				
		}
		$result_asset=$this->db->get('rmn_asset_hearbeat')->result_array();
		//print_r($result_asset);exit;
		//$this->db->from('rmn_asset_hearbeat as ah');
		if($action_type == 'active'){
			return $result_asset;
		}else{
			$active_asset=array();
			if(count($result_asset)>0){
				foreach ($result_asset as $asset_id){
					$active_asset[]=$asset_id['asset_id'];
				}
			}
			$this->db->select("asset_id");
			if(count($active_asset)>0){
				$this->db->where_not_in('a.asset_id', $active_asset);
			}
			if($this->regionID!=''){
				$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
				$this->db->where('s.region_id',$this->regionID);
			
			}
			return $this->db->get('rmn_asset_master a')->result_array();
		}
	}
	/*
	 * Brand report
	 * */
	public function get_brand($action_type,$i,$first_date,$second_date){
		$result1=array();
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->where('b.brand_id',$i);
		$this->db->select('DISTINCT(a.asset_id)');
		$this->db->where($where_assets);
		$this->db->join('rmn_model_master as m','m.brand_id=b.brand_id');
		$this->db->join('rmn_asset_master as a','a.model_id=m.model_id');
		$data_brand=$this->db->get('rmn_brand_master as b')->result_array();
		if(count($data_brand)>0){
			foreach ($data_brand AS $brand){
				$result1[]=$brand['asset_id'];
			}
		}
		$result_asset=$this->active_asset_list($result1,$first_date,$second_date);
		if($action_type == 'active'){
			return $result_asset;
		}else{
			return $this->inactive_asset_list($result_asset,$result1);
		}
	}
	/*
	 * Region report
	 * */
	
	public function get_region($action_type,$i,$first_date,$second_date){
		$result=array();
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->where('r.region_id',$i);
		$this->db->select('DISTINCT(a.asset_id)');
		$this->db->where($where_assets);
		$this->db->join('rmn_store_master s','s.region_id=r.region_id');
		$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
		$data_asst=$this->db->get('rmn_region_master r')->result_array();
		if(COUNT($data_asst)>0){
			foreach ($data_asst AS $asset){
				$result[]=$asset['asset_id'];
			}
		}
		$result_asset=$this->active_asset_list($result,$first_date,$second_date);
		if($action_type == 'active'){
			return $result_asset;
		}else{
			return $this->inactive_asset_list($result_asset,$result);
		}
	}
	
	/*
	 * Store Based Assets Report
	 */
	public function get_storebasedassets($action_type,$i,$first_date,$second_date){
		//print($first_date);exit;
		$result=array();
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->where('s.store_id',$i);
		$this->db->select('DISTINCT(a.asset_id)');
		$this->db->where($where_assets);
		//$this->db->join('rmn_store_master s','s.region_id=r.region_id');
		$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
		$data_asst=$this->db->get('rmn_store_master s')->result_array();
		//print_r($data_asst);exit;
		if(COUNT($data_asst)>0){
			foreach ($data_asst AS $asset){
				$result[]=$asset['asset_id'];
			}
		}
		$result_asset=$this->active_asset_list($result,$first_date,$second_date);
		if($action_type == 'active'){
			return $result_asset;
		}else{
			return $this->inactive_asset_list($result_asset,$result);
		}
	}
	
	/*
	 * City report
	 * */
	public function get_city($action_type,$i,$first_date,$second_date){
		$result1=array();
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->select('DISTINCT(asset_id)');
		$this->db->where('c.city_id',$i);
		$this->db->where($where_assets);
		$this->db->join('rmn_region_master r','r.region_id=c.reg_id','left');
		$this->db->join('rmn_store_master s','s.region_id=r.region_id','left');
		$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
		$asset_id=$this->db->get('rmn_city_master c')->result_array();
		if(count($asset_id)){
			foreach($asset_id as $city){
				$result1[]=$city['asset_id'];
			}
		}
		$result_asset=$this->active_asset_list($result1,$first_date,$second_date);
		if($action_type == 'active'){
			return $result_asset;
		}else{
			return $this->inactive_asset_list($result_asset,$result1);
		}
	}
	/*
	 * Get all active inactive report
	 */
	public function heartbeat_assest($report_type,$i,$action,$fm_date=null,$to_date=null,$val=null,$params=null){
		$result=array();
		$data=[];	
		$res=[];
		$result1=array();
		$cur_date=date('Y-m-d');
		$first_date=date("Y-m-d",strtotime($fm_date));
		$second_date=date("Y-m-d",strtotime($to_date));
		switch($report_type){
		 	//for Scheduler Report
			case "scheduler":
				$this->db->select('sch_name');
				$this->db->where('sch_id',$i);
				if($this->regionID!=''){
					$this->db->where('region_id',$this->regionID);
				}
				$schedule_name=$this->db->get('rmn_scheduler')->row()->sch_name;
				$result['sch_name']=$schedule_name;
				$query_he=$this->get_scheduler($action,$i,$first_date,$second_date);
				//print_r($query_he);exit;
				break;
			// for Asset Report	
			case "asset":
				$query_he=$this->get_asset($action,$i,$fm_date);
				break;
			// for Brand Report	
			case "brand":
				$this->db->select('brand_name');
				$this->db->where('brand_id',$i);
				$brand_name=$this->db->get('rmn_brand_master')->row()->brand_name;
				$result['brand_name']=$brand_name;
				$query_he=$this->get_brand($action,$i,$first_date,$second_date);
				break;
			// for Region Report	
			case "region":
				$this->db->select('region_name');
				$this->db->where('region_id',$i);
				$region_name=$this->db->get('rmn_region_master')->row()->region_name;
				$result['region_name']=$region_name;
				$query_he=$this->get_region($action,$i,$first_date,$second_date);
				break;
			// for City Report	
			case "city":
				$this->db->select('city_name');
				$this->db->where('city_id',$i);
				$city_name=$this->db->get('rmn_city_master')->row()->city_name;
	            $result['city_name']=$city_name;
	            $query_he=$this->get_city($action,$i,$first_date,$second_date);
	            break;
			case "store":
				$this->db->select('store_name'); 
				$this->db->where('store_id',$i);
				$store_name =$this->db->get('rmn_store_master')->row()->store_name;
				$result['store_name']=$store_name;
				$query_he=$this->get_store($action,$i,$first_date,$second_date);
				break;
			case "storebasedassets":
				$this->db->select('store_name');
				$this->db->where('store_id',$i);
				$store_name =$this->db->get('rmn_store_master')->row()->store_name;
				$result['store_based_name']=$store_name;//echo $first_date;exit;
				$query_he=$this->get_storebasedassets($action,$i,$first_date,$second_date);
				//print_r($query_he);exit;
				break;
	        // for default    
			default :
				break;
		}
		$this->db->select("asst.asset_id,asst.asset_service_tag,asst.asset_code,sm.store_code,sm.store_name,reg.region_name,sm.store_contact_number");
		$this->db->join('rmn_store_master sm','sm.store_id=asst.asset_store_id','left');
		$this->db->join('rmn_region_master reg','reg.region_id=sm.region_id','left');
		if($to_date != null){
			$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
			$this->db->where($where_assets);
		}
		$asset_list=array();
		foreach ($query_he as $asset_info){
			$asset_list[]=$asset_info['asset_id'];//echo $asset_list;exit;
		}
		$this->db->where_in('asst.asset_id', $asset_list);
		$this->db->where('asst.asset_status !=',2);
		if($val==1){
			$query=$this->db->get('rmn_asset_master asst')->num_rows();
			$result=$query;
		}elseif($val==2) {
			if(isset($params) && !empty($params)){
				$this->db->limit($params['limit'], $params['offset']);
			}
			$query=$this->db->get('rmn_asset_master asst')->result_array();
			$result['data']=$query;
		}
	return $result;
}
// get no of Active and Incative assets store wise report   ---praveen 10/10/2018
	public function get_all_store_report($filter_data=null,$params=null,$val=null,$fr_date=null,$to_date=null){
		$result=array();
		$data=[];
		$cur_date=date("Y-m-d");
		if(isset($filter_data['store_st_date']) && isset($filter_data['store_ed_date']) && $filter_data['store_st_date']!='' && $filter_data['store_ed_date']!=''){
			$first_date=date("Y-m-d",strtotime($filter_data['store_st_date']));
			$second_date=date("Y-m-d",strtotime($filter_data['store_ed_date']));
		}elseif($fr_date!=null && $to_date!=null){
			$first_date=urldecode($fr_date);
			$second_date=urldecode($to_date);
		}else{
			$first_date=date("Y-m-d",strtotime($cur_date));
			$second_date=date("Y-m-d",strtotime($cur_date));
		}
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$count_asset=$this->total_count_asset($where_assets);
		$count_store=$this->total_count_store();
		$this->db->select('store_id,store_name,region_id');
		if($this->regionID!=''){
			$this->db->where('region_id',$this->regionID);
		}
		$this->db->where('status !=',2);
		if($val == 1){
			$count_rows=$this->db->get('rmn_store_master')->num_rows();
			$result=$count_rows;
		}elseif($val==2){
			
			if(isset($params) && !empty($params))
			{
				$this->db->limit($params['limit'], $params['offset']);
			}
			$res = $this->db->get('rmn_store_master')->result_array();
			
			foreach($res as $store){
				$total_asset=0;
				$active_asset=0;
				$result1=array();
				$this->db->select('a.asset_id');
				$this->db->where('a.asset_store_id',$store['store_id']);
				$this->db->where($where_assets);
				$this->db->join('rmn_store_master s','s.store_id = a.asset_store_id','left');
				$asset = $this->db->get('rmn_asset_master a')->result_array();
				if(count($asset)>0){
	
					foreach($asset as $value){
						$result1[]=$value['asset_id'];
					}
					$result1=array_unique($result1);
					$total_asset=count($result1);
				}
				if($total_asset >0){
					$this->db->select("COUNT(DISTINCT asset_id) AS asset");
					$this->db->where_in('asset_id',$result1);
					$this->db->where('DATE(pingdatetime) >=',$first_date);
					$this->db->where('DATE(pingdatetime) <=',$second_date);
					$active_asset=$this->db->get('rmn_asset_hearbeat')->row()->asset;
				}
				$store_asst['store_id']=$store['store_id'];
				$store_asst['store_name']=$store['store_name'];
				$store_asst['active']=$active_asset;
				$store_asst['fr_date']=$first_date;
				$store_asst['to_date']=$second_date;
				$store_asst['inactive']=$total_asset - $active_asset;
				$store_asst['region_id']=$store['region_id'];
				$data[]=$store_asst;
			}
			$result['data']=$data;
			$result['count']=$count_asset;
			$result['total_store']=$count_store;
			$result['fr_date']=$first_date;
			$result['to_date']=$second_date;
		}
		return $result;
	
	}
//count total asset ---Praveen 10/10/2018
	public function total_count_asset($where_assets){
		$this->db->select('COUNT(asset_id) AS count_asset');
		
		if($this->regionID!=''){
			$this->db->join('rmn_store_master s','a.asset_store_id=s.store_id');//To count on region basis
			$this->db->where('region_id',$this->regionID);
		}
		$this->db->where('asset_status !=',2);
		$this->db->where($where_assets);
		$count_asset=$this->db->get('rmn_asset_master a')->row()->count_asset;//print($count_asset);exit;
		return $count_asset;
	}
	
// count total store -----Nameesha 06/12/2018
	public function total_count_store(){
		$this->db->select('COUNT(store_id) AS count_store');
	
		if($this->regionID!=''){
			
			$this->db->where('region_id',$this->regionID);
		}
		$this->db->where('status !=',2);
		//$this->db->where($where_assets);
		$count_store=$this->db->get('rmn_store_master')->row()->count_store;
		return $count_store;
	}
	
// Storewise Get Active and Inactive Asset List ---Praveen 10/10/2018 
	public function get_store($action,$i,$first_date,$second_date){
		$result1=array();
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$this->db->select('DISTINCT(a.asset_id)');
		$this->db->where('s.store_id',$i);
		$this->db->where($where_assets);
		$this->db->join('rmn_asset_master a','s.store_id=a.asset_store_id');
		$asset_id=$this->db->get('rmn_store_master s')->result_array();
		if(count($asset_id)>0){
			foreach($asset_id as $store){
				$result1[]=$store['asset_id'];
			}
		}
		$result_asset=$this->active_asset_list($result1,$first_date,$second_date);
		if($action == 'active'){
			return $result_asset;
		}else{
			return $this->inactive_asset_list($result_asset,$result1);
		}
	}



	/*
	 * Get all Scheduler wise report
	 */
	
	public function getallschedulereport($data_filter,$params=null,$val=null,$fr_date=null,$to_date=null){
		$result=array();
		$data=[];
		$cur_date=date('Y-m-d');
		if(isset($data_filter['sch_st_date']) && $data_filter['sch_ed_date']!='' && isset($data_filter['sch_st_date']) && $data_filter['sch_ed_date']!=''){
			$first_date=date("Y-m-d",strtotime($data_filter['sch_st_date']));
			$second_date=date("Y-m-d",strtotime($data_filter['sch_ed_date']));
		}elseif($fr_date!=null && $to_date!=null){
			$first_date=urldecode($fr_date);
			$second_date=urldecode($to_date);
		}else{
			$first_date=date("Y-m-d",strtotime($cur_date));
			$second_date=date("Y-m-d",strtotime($cur_date));
		}
		$this->db->select("COUNT(a.asset_id) AS asset_count");
		$this->db->where('a.asset_status !=',2);
		$this->db->where('a.asset_expiry_date >=',$second_date);
		if($this->regionID!=''){
			$this->db->join('rmn_store_master s','s.store_id=a.asset_store_id');
			$this->db->where('s.region_id',$this->regionID);
		}
		$count_assest=$this->db->get('rmn_asset_master a')->row()->asset_count;
		$this->db->select('sch_id,sch_name');
		if($this->regionID!=''){//print('hii');exit;
			$this->db->where('region_id',$this->regionID);
		}
		$this->db->where('sch_status !=',-1);
		$this->db->where('ed_date >=',$second_date);
		if($val==1){
			$query = $this->db->get('rmn_scheduler')->num_rows();
		$result=$query;
		}elseif($val==2){
			if(isset($params) && !empty($params)){
				$this->db->limit($params['limit'], $params['offset']);
			}
			$query = $this->db->get('rmn_scheduler')->result_array();
			//print_r($query);exit;
			foreach ($query as $sch){
			    $asset=$this->getassets($sch['sch_id'],$first_date,$second_date);
			    //$count_assest=count($asset);
			    $query_he=0;
			    if(count($asset) >0){
					$this->db->select("count(DISTINCT ah.asset_id) as count");
					$this->db->where_in('ah.asset_id', $asset);
					$this->db->where('DATE(ah.pingdatetime) >=', $first_date);
					$this->db->where('DATE(ah.pingdatetime) <=', $second_date);
					if($this->regionID!=''){
						$this->db->join('rmn_store_master s','s.store_code=ah.store_code');
						//$this->db->join('rmn_asset_master a','s.store_id=a.asset_store_id');
						$this->db->where('s.region_id',$this->regionID);
					}
					$query_he=$this->db->get('rmn_asset_hearbeat ah')->row()->count;
					//print($query_he);exit;
			    }
				$sch_asst['sch_id']=$sch['sch_id'];
				$sch_asst['sch_name']=$sch['sch_name'];
				//print($sch_asst['sch_name']);exit;
				$sch_asst['active']=$query_he;
				//print($sch_asst['active']);
				$sch_asst['inactive']=$count_assest-$query_he;
				//print($sch_asst['inactive']);exit;
				
				$sch_asst['frm_date']=$first_date;
				$sch_asst['to_date']=$second_date;
				//$sch_asst['region_id']=$sch['region_id'];
				$data[]=$sch_asst;
		    }
		   
			$result['data']=$data;
			$result['count']=$count_assest;
			$result['fr_date']=$first_date;
			$result['to_date']=$second_date;
		}	
		return $result;
  }
   
  public function check_asset_lockperiod($start_date,$end_date){
  	$where_con=" (DATE('".$start_date."') BETWEEN  DATE(asset_reg_date) AND 	COALESCE (DATE(asset_expiry_date),(DATE('".$end_date."')))
			OR (DATE(asset_reg_date) BETWEEN DATE('".$start_date."') AND DATE('".$end_date."'))
			OR (DATE(asset_expiry_date) BETWEEN DATE('".$start_date."') AND DATE('".$end_date."')))  ";
  	return $where_con;
  }
	/*
	 * Get all Region wise report
	 */
       public function get_all_region_report($filter_data=null,$params=null,$val=null,$fr_date=null,$to_date=null){
		    $result=[];
		    $data=[];
		    $cur_date=date('Y-m-d');
		    if(isset($filter_data['reg_st_date']) && isset($filter_data['reg_ed_date']) && $filter_data['reg_st_date']!='' && $filter_data['reg_ed_date']!=''){
		    	$first_date=date("Y-m-d",strtotime($filter_data['reg_st_date']));
		    	$second_date=date("Y-m-d",strtotime($filter_data['reg_ed_date']));
		    }elseif($fr_date!=null && $to_date!=null){
		    	$first_date=urldecode($fr_date);
		    	$second_date=urldecode($to_date);
		    }else{
		    	$first_date=date("Y-m-d",strtotime($cur_date));
		    	$second_date=date("Y-m-d",strtotime($cur_date));
		    }
		    
		    $where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		    $count_assest=$this->total_count_asset($where_assets);
			$this->db->select('region_id,region_name');
		    $this->db->where('status !=',-1);
		    if($this->regionID!=''){
		    	$this->db->where('region_id',$this->regionID);
		    }
			if($val==1){
				$region=$this->db->get('rmn_region_master')->num_rows();
				$result=$region;
			}elseif($val==2){
				if(isset($params) && !empty($params))
				{
				$this->db->limit($params['limit'], $params['offset']);
				}
				$region=$this->db->get('rmn_region_master')->result_array();
				foreach($region as $region_id){
					$result1=array();
					$asset_set=0;
					$this->db->select('a.asset_id');
					$this->db->where($where_assets);
					$this->db->where('r.region_id',$region_id['region_id']);
					$this->db->join('rmn_store_master s','s.region_id=r.region_id');
					$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
					$res=$this->db->get('rmn_region_master r')->result_array();
					foreach ($res AS $asset){
						$result1[]=$asset['asset_id'];
					}
					if(count($result1)>0){
						$result_set=array_unique($result1);
						$this->db->select('COUNT(DISTINCT asset_id) AS asset');
						$this->db->where_in('asset_id',$result_set);
						$this->db->where('DATE(pingdatetime) >=', $first_date);
						$this->db->where('DATE(pingdatetime) <=', $second_date);
						$asset_set=$this->db->get('rmn_asset_hearbeat')->row()->asset;
					}
					$reg_asst['region_name']=$region_id['region_name'];
					$reg_asst['active']=$asset_set;
				    $reg_asst['inactive']=$this->get_assetcountBy_region($region_id['region_id'],$where_assets)- $asset_set;
				    $reg_asst['region_id']=$region_id['region_id'];
				    $reg_asst['fr_date']=$first_date;
				    $reg_asst['to_date']=$second_date;
					$data[]=$reg_asst;
			     }	// print( $data['region_id']);exit;
				$result['data']=$data;
				$result['count']=$count_assest;
				$result['fr_date']=$first_date;
				$result['to_date']=$second_date;
		     }
		return $result;
     }
     
     // GET ASSET COUNT BASED ON REGION
     public function get_assetcountBy_region($region_id,$where_assets){
     	$this->db->select('COUNT(a.asset_id) as asset_count');
     	$this->db->where($where_assets);
     	$this->db->where('r.region_id',$region_id);
     	$this->db->join('rmn_store_master s','s.region_id=r.region_id');
     	$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
     	return $this->db->get('rmn_region_master r')->row()->asset_count;
     }
     
	/*
	 * Get all city wise report 
	 */    
		
   public function get_all_city_report($filter_data=null,$params=null,$val=null,$fr_date=null,$to_date=null){
   //	print($region_id);exit;
		$result=array();
		$data=[];
		$cur_date=date("Y-m-d");
		if(isset($filter_data['city_st_date']) && isset($filter_data['city_ed_date']) && $filter_data['city_st_date']!='' && $filter_data['city_ed_date']!=''){
			$first_date=date("Y-m-d",strtotime($filter_data['city_st_date']));
			$second_date=date("Y-m-d",strtotime($filter_data['city_ed_date']));
		}elseif($fr_date!=null && $to_date!=null){
			$first_date=urldecode($fr_date);
			$second_date=urldecode($to_date);
		}else{
			$first_date=date("Y-m-d",strtotime($cur_date));
			$second_date=date("Y-m-d",strtotime($cur_date));
		}
		$where_assets=$this->check_asset_lockperiod($first_date,$second_date);
		$count_assest=$this->total_count_asset($where_assets);
		$this->db->select('city_id,city_name');
		if($this->regionID!=''){
			$this->db->where('reg_id',$this->regionID);
		}
		$this->db->where('status !=',-1);
		if($val==1){
			$count_rows=$this->db->get('rmn_city_master')->num_rows();
			$result=$count_rows;
		}elseif($val==2){
			if(isset($params) && !empty($params))
			{
				$this->db->limit($params['limit'], $params['offset']);
			}
			$res=$this->db->get('rmn_city_master')->result_array();
			foreach($res as $city){
				$total_asset=0;
				$active_asset=0;
				$result1=array();
				$this->db->select("a.asset_id");
				$this->db->where('c.city_id',$city['city_id']);
				$this->db->where($where_assets);
				$this->db->join('rmn_region_master r','r.region_id=c.reg_id','left');
				$this->db->join('rmn_store_master s','s.region_id=r.region_id','left');
				$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id');
				$asset=$this->db->get('rmn_city_master c')->result_array();
				if(count($asset)>0){
					foreach($asset as $value){
						$result1[]=$value['asset_id'];
					}
					$result1=array_unique($result1);
					$total_asset=count($result1);
				}
				if(count($result1)>0){
					$this->db->select("COUNT(DISTINCT asset_id) AS asset");
					$this->db->where_in('asset_id',$result1);
					$this->db->where('DATE(pingdatetime) >=',$first_date);
					$this->db->where('DATE(pingdatetime) <=',$second_date);
					$active_asset=$this->db->get('rmn_asset_hearbeat')->row()->asset;
				}
				$city_asst['city_id']=$city['city_id'];
				$city_asst['city_name']=$city['city_name']; 
				$city_asst['active']=$active_asset;
				$city_asst['fr_date']=$first_date;
				$city_asst['to_date']=$second_date;
				$city_asst['inactive']=$total_asset - $active_asset;//echo $city_asst['inactive'];exit;
				$data[]=$city_asst;
		    }
			$result['data']=$data;
			$result['count']=$count_assest;	
			$result['fr_date']=$first_date;
			$result['to_date']=$second_date;
			
		}
	  return $result;
	}

}
