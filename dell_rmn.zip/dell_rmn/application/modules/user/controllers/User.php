<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class User extends BSS_Controller {
	public function __construct() {
		parent::__construct ();
		$this->isAdmin ||$this->isEditor|| $this->isUser ? true : redirect ( "unauthorize" ); // User Logged in or not Check
		$this->load->model ( 'user_model' );
		$this->load->model ( 'region/region_model' );
	}
	/*
	 * List of the users
	 */
	public function index() {
		$data = array ();
		$params = array ();
		$filter_data = $this->input->get ();
		$params ['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item ( 'pagination' );
		$config ["base_url"] = base_url () . "user/index";
		$total_row = $this->user_model->get_all_users_count ($filter_data);
		$config ['first_url'] = $config ['base_url'] . '?' . http_build_query ( $_GET );
		$config ["total_rows"] = $total_row;
		$this->pagination->initialize ( $config );
		if ($this->uri->segment ( 3 )) {
			$page = (($this->uri->segment ( 3 ) - 1) * $config ["per_page"]);
		} else {
			$page = 0;
		}
		$data ['role_list'] = $this->user_model->get_all_roles ();
		$params ['offset'] = $page;
		$data ["list_of_users"] = $this->user_model->get_all_users ( $filter_data, $params );
		$this->template->set ( 'title', $this->config->item ( 'app_name' ) );
		$this->template->set ( 'page_title', 'List of User' );
		$this->template->set ( 'page_breadcrumb', 'List of User' );
		$this->template->load ( 'template', 'contents', 'index', $data );
	}
	public function add() {
		$data = array ();
		$data ['csrf_name'] = $this->security->get_csrf_token_name ();
		$data ['csrf_hash'] = $this->security->get_csrf_hash ();
		$data ['role_list'] = $this->user_model->get_all_roles ();
		$data['region_list']= $this->region_model->get_all_regions();
		$this->template->set ( 'title', $this->config->item ( 'app_name' ) );
		$this->template->set ( 'page_title', 'Add - User' );
		$this->template->set ( 'page_breadcrumb', 'Add - User' );
		
		if ($this->input->server ( 'REQUEST_METHOD' ) == 'POST') {
			$this->form_validation->set_rules ( 'email_id', 'Email Id', 'trim|required|valid_email' );
			$this->form_validation->set_rules ( 'user_password', 'Password', 'trim|required|max_length[50]|min_length[6]' );
			$this->form_validation->set_rules ( 'cuser_password', 'Confirm Password', 'required|matches[user_password]' );
			$this->form_validation->set_rules ( 'user_name', 'Name', 'max_length[50]' );
			$this->form_validation->set_rules ( 'region_select', 'Role Id', 'trim|required' );

			
			if ($this->form_validation->run ()) {
				$check_status=$this->user_model->isEmailExist($this->input->post('email_id'));
				if($check_status == -1){
					$this->session->set_flashdata('error_msg', 'User already exist.');
					redirect('user/add');
				}
				$param = array (
						'name' => $this->input->post ( 'user_name' ),
						'email_id' => $this->input->post ( 'email_id' ),
						'password' => md5($this->input->post ( 'user_password' )),
						'role_id' => $this->input->post ( 'region_type' ),
						'region_id'=>$this->input->post ('region_select'),
						'is_active' => $this->input->post ( 'user_status' ) 
				);
				$this->user_model->add ( $param );
				$this->session->set_flashdata ( 'success_msg', 'New User added successfully.' );
				redirect ( 'user' );
			}
		}
			
			$this->template->load ('template', 'contents', 'add_user', $data );
		

	}

	public function edit($id) {
		$data = array ();
		$data ['user_info'] = $this->user_model->get_user_details( $id );
		if ($data ['user_info'] ['user_id']) {
			$data ['csrf_name'] = $this->security->get_csrf_token_name ();
			$data ['csrf_hash'] = $this->security->get_csrf_hash ();
			$this->template->set ( 'title', $this->config->item ( 'app_name' ) );
			$this->template->set ( 'page_title', 'Edit - User' );
			$this->template->set ( 'page_breadcrumb', 'Edit - User' );
			$data ['role_list'] = $this->user_model->get_all_roles ();
			$data['region_list']= $this->region_model->get_all_regions();
			$current_password=$data ['user_info']['password'];
			//print($current_password);
			if ($this->input->server ( 'REQUEST_METHOD' ) == 'POST') {
				$this->form_validation->set_rules ( 'email_id', 'Email Id', 'trim|required' );
				//$this->form_validation->set_rules ( 'old_password', ' Old Password', 'trim|required|callback_password_matches[$current_password]' );
				$this->form_validation->set_rules ( 'cuser_password', ' New Password', 'trim|max_length[50]|min_length[6]' );
				$this->form_validation->set_rules ( 'edit_password', ' Confirm Password', 'required|matches[edit_password]' );
				$this->form_validation->set_rules ( 'user_name', 'Name', 'max_length[50]' );
				$this->form_validation->set_rules ( 'region_select', 'Role Id', 'trim|required' );
				if ($this->form_validation->run ()) {
					$check_status=$this->user_model->isEmailExist($this->input->post('email_id'),$id);
					if($check_status == -1){
						$this->session->set_flashdata('error_msg', 'User already exist.');
						redirect('user/edit/'.$id);
					}
				
					$param = array (
							
							'name' => $this->input->post ( 'user_name' ),
							'email_id' => $this->input->post ( 'email_id' ),
							'role_id'=>$this->input->post ( 'region_type' ),
							'region_id'=>$this->input->post ('region_select'),
							'is_active' => $this->input->post ( 'user_status')
					);
					if($this->input->post('edit_password')!=null){
						$param['password']=md5($this->input->post('edit_password'));
					}
					$this->user_model->edit_user($param, $id );
					$this->session->set_flashdata ( 'success_msg', 'User details updated successfully.' );
					redirect ( 'user' );
				}
			}
			$this->template->load ( 'template', 'contents', 'edit_user', $data );
		}
		 else {
			redirect ( 'unauthorize' );
		}
	}
	
	public function remove($id){
		$data = array();
		$data['user_info']=$this->user_model->get_user_details($id);
		if($data['user_info']['user_id']){
			if($this->user_model->remove_user($id) == 1){
				$this->session->set_flashdata('success_msg', 'The User has been deleted successfully.');
			}
			redirect('user');
		}else{
			redirect('unauthorize');
		}
	}
	
	public function change() {
		$data = array ();
		$param = array ();
		$data ['csrf_name'] = $this->security->get_csrf_token_name ();
		$data ['csrf_hash'] = $this->security->get_csrf_hash ();
		$this->template->set ( 'title', $this->config->item ( 'app_name' ) );
		$this->template->set ( 'page_title', 'Change Password');
		$this->template->set ( 'page_breadcrumb', 'Change Password' );
		if ($this->input->server ( 'REQUEST_METHOD' )=='POST') {
			$this->form_validation->set_rules('old_password','Old Password','required');
			$this->form_validation->set_rules('new_password','New Password','required');
			$this->form_validation->set_rules('conf_password','Confirm Password','required|matches[new_password]');
			if ($this->form_validation->run ()) {
			    $param = array (
					'old_password' => md5($this->input->post ('old_password' )),
					'new_password'=>md5($this->input->post('new_password')),
			    	'conf_password'=>md5($this->input->post('conf_password')),	
				);
				$check=$this->user_model->varify_password( $param );
				if($check==1)
				{
					$this->session->set_flashdata ( 'success_msg', 'Password updated successfully.' );
						redirect ( 'dashboard' );
				}else{
					$this->session->set_flashdata( 'error_msg', 'Enter valid old Password.');
				}
			}
		}
		$this->template->load ( 'template', 'contents', 'change_password',$data );
	}
	
	//To check for the old password
	public function password_matches($submitted_value, $existing_value)
	{
		echo $submitted_value;
		echo $password_wrong=(md5($submitted_value)!=$existing_value)?1:0;exit;
		//echo(md5($submitted_value));
		if ($password_wrong)
		{
			$this->form_validation->set_message('password_matches', 'The password you supplied does not match your existing password.');
			return FALSE;
		}
		return TRUE;
	}
}
