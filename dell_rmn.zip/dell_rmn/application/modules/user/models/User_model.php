<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
    public function get_all_users_count($filter_data){
		if(count($filter_data)>0){
			$this->db->like('email_id',$filter_data['email'],'both');
			$this->db->like('name',$filter_data['name']);
			$this->db->like('role_id',$filter_data['user_role']);
		}
		$this->db->where('role_id !=',1);
		$this->db->from('rmn_user');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all users
	 */
	public function get_all_users($filter_data=null,$params = array()){
		$this->db->order_by('u.name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		if(count($filter_data)>0){
			$this->db->like('u.email_id',$filter_data['email'],'both');
			$this->db->like('u.name',$filter_data['name']);
			$this->db->like('r.role_id',$filter_data['user_role']);
		}
		$this->db->where('u.role_id !=',1);
		$this->db->join('rmn_user_role as r','r.role_id=u.role_id','left');
		
		$this->db->select('*');
		return $this->db->get('rmn_user u')->result_array();
	}
	
	
   public function get_all_roles(){
		$this->db->order_by('ur.role_name','ASC');
		$this->db->where('ur.role_id !=',1);
		$this->db->select('*');
		return $this->db->get('rmn_user_role ur')->result_array();
	}
	
	/*
	 * Add New user
	 */
	public function add($param){
		$this->db->insert('rmn_user',$param);
		return true;
	}
	
	/*
	 * Get the get user details by id
	 */
	public function  get_user_details($id){
		$this->db->where('user_id',$id);
		$this->db->join('rmn_user_role as ur','ur.role_id=u.role_id','left');
		$this->db->select('*');
		return $this->db->get('rmn_user as u ')->row_array();
	}
	/*
	 * Update the user info on ID
	 */
	public function edit_user($param,$id){
		$this->db->where('user_id',$id);
		return $this->db->update('rmn_user',$param);
	}
	/*
	 * Delete the user on ID
	 */
	public function remove_user($id){
		$this->db->where('user_id',$id);
		return $this->db->delete('rmn_user');
	}
	
	public function isEmailExist($email,$id=null){
		$this->db->select('email_id');
		$this->db->from('rmn_user');
		$this->db->where('email_id',$email);
		if($id!=null)
		{
			$this->db->where('user_id!=',$id);
		}
		$query=$this->db->get();
		$result=$query->row_array();
		$cnt_data=$query->num_rows();
		if($cnt_data > 0){
				return -1;
		}
		return 1;
	}
	
    public function varify_password($params){
		$user_id = $this->session->user_id;
		$this->db->select('COUNT(*) AS count');
		$this->db->where('password',$params['old_password']);
		$this->db->where('user_id',$user_id);
		$result=$this->db->get('rmn_user')->row()->count;
		if($result==1){
			$password=array(
				'password'=>$params['new_password'],					
			  );
			$this->db->where('user_id',$user_id);
			$this->db->update('rmn_user',$password);
			return 1;
		}else{
			return -1;
		}
		
	}

}
