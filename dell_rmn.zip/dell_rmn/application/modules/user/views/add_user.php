<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add User
		<a href="<?php echo base_url('user');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
        	<form name="user" id="user_management" class="frm_inner cmn_form" method="post" autocomplete="off">
        	<div class="col-md-6">
				<label for="name" class="control-label">Name <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="text" name="user_name" autocomplete="off" value="<?php echo set_value("name");?>" class="form-control" id="name" placeholder="Enter  the user Name"/>
					<span class="text-danger"><?php echo form_error('user_name');?></span>
				</div>
			</div>
			<div class="col-md-6">
				<label for="Email Id" class="control-label">Email Id <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="text" name="email_id" autocomplete="off" value="<?php echo $this->input->post('email_id'); ?>" class="form-control" id="email_id" placeholder="Enter valid email id"/>
					<span class="text-danger"><?php echo form_error('email_id');?></span>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="Password" class="control-label">Password <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="password" name="user_password"  autocomplete="off" value="<?php echo set_value("user_password"); ?>" class="form-control" id="password" placeholder="Enter the valid password"/>
				    <span class="text-danger"><?php echo form_error('user_password');?></span>
				 </div>
			</div>
			<div class="col-md-6">
				<label for="Confirm Password" class="control-label">Confirm Password <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="password" name="cuser_password"  autocomplete="off" value="" class="form-control" id="cpassword" placeholder="Re-enter the password"/>
				    <span class="text-danger"><?php echo form_error('cuser_password');?></span>
				 </div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
		            <label for="region_type" class="control-label">Role Name<span class="text-danger">*</span></label>
		            <select name="region_type" id="region_type" class="form-control" data-toggle="tooltip" title="" data-original-title="*Viewer - only Can be able to view *Editor - Can be able to edit the entire information ">
		                <option value="">--Select Role--</option>
		                <?php foreach($role_list as $role) :?>
                    		<option value="<?php echo $role['role_id']?>" <?php echo $this->input->get('role_id')==$role['role_id'] ?'selected=selected':'';?>><?php echo $role['role_name']?></option>
                   		 <?php endforeach;?>
		            </select>
		        </div>
		 <!--                To select user regionwise -->       
		     
                 <div class="col-md-6 form-group" id="region" style="display:none">
					<label for="region_select" class="control-label">Region Name <span class="text-danger">*</span></label>
					<div class="">
						<select name="region_select" id="region_select"class="form-control">
							<option value="">--Select Type--</option>
							<?php foreach($region_list as $region) :?>
	                    		<option value="<?php echo $region['region_id'];?>"> <?php echo $region['region_name'];?> </option>
                   		 <?php endforeach;?>
						</select>
						<span class="text-danger"><?php echo form_error('region_select');?></span>
					</div>
				</div>
			 <!--                To select user regionwise --> 
			 
			 	
			<!--  <div class="clearfix"></div>-->
			<div class="col-md-6">
		            <label for="email" class="control-label">Status <span class="text-danger">*</span></label>
		             <select name="user_status" id="user_status" class="form-control">
                    	<option value="">--Select Status--</option>
                    	<?php 
                    		$status=$this->input->get('is_active');
                    	?>
                    		<option value="1"  <?php  if(isset($status)){ echo $status== '1' ? 'selected=selected':''; } ?>>Active</option>
                    		<option value="0" <?php  if(isset($status)){ echo $status== '0' ? 'selected=selected':''; } ?>>Inactive</option>
                    </select>
		        </div>
		        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
                <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />

            </div>
        </div>
			
    	</form>
	</div>
</div>