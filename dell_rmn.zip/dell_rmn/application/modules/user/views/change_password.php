<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">
		<a href="<?php echo base_url('dashboard');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
        	<form name="user" id="password_management" class="cmn_form" method="post">
                <div class="clearfix"></div>
			    <div class="col-md-6 form-group">
                    <label for="old_password" class="control-label">Old Password <span class="text-danger">*</span></label>
                     <div class="">
                    <input type="password" name="old_password" id="old_password" value="" class="form-control" id="old_password_id" placeholder="Old Password"/>
                    <span class="text-danger"><?php echo form_error('old_password');?></span>
                    </div>
               </div>
			<div class="clearfix"></div>
			<div class=" col-md-6 form-group"> 
				<label for="new_password" class="control-label">New Password<span class="text-danger">*</span></label>
				 <div class="">
	                 <input type="password" name="new_password" id="new_password" value="" class="form-control" placeholder="New Password"> 
	                 <span class="text-danger"><?php echo form_error('new_password');?></span>
	            </div> 
            </div>
            <div class="clearfix"></div>
				<div class="col-md-6 form-group">
                    <label for="conf_password" class="control-label">Confirm Password <span class="text-danger">*</span></label>
                    <div class="">
                        <input type="password" name="conf_password" id="conf_password" value=""  class="form-control" id="new_password_id" placeholder="Confirm Password"/>
                        <span class="text-danger"><?php echo form_error('new_password');?></span>
                    </div>
                </div>
			<div class="clearfix"></div>
		        <div class="text-right btn_ar">
                 <div class="col-md-12 p_right">
                <input type="submit" name="save_btn" class="btn btn-primary" value="Update">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />

            </div>
        </div>
			
    	</form>
	</div>
</div>