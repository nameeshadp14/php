<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit City
				<a href="<?php echo base_url('city');?>" class="btn btn-success btn-xs pull-right">Go back</a>
		</h2>
    <div class="box-body">
        <form class="frm_inner cmn_form" id="city_management" method="post" action="">
            <div class="row m_left m_right">
                <div class="col-md-6 form-group">
                    <label>City Name <span class="text-danger">*</span></label>
                    <input type="text" name="city_name" id=""city_name"" data-toggle="tooltip" title="Type the new City name" value="<?php echo set_value("city_name",$city_details['city_name']); ?>" class="form-control">
                	<span class="text-danger"><?php echo form_error("city_name");?></span>
                </div>
                 <div class="col-md-6 form-group">
                    <label>Region <span class="text-danger">*</span></label>
                    <select name="region" id="region" class="form-control">
                    	<option value="">--SELECT--</option>
                    	<?php foreach($list_of_region as $region) :?>
                    		<option value="<?php echo $region['region_id']?>" <?php echo $city_details['reg_id'] == $region['region_id'] ? 'selected=selected':'';?>><?php echo $region['region_name']?></option>
                   		 <?php endforeach;?>
                    </select>
                	<span class="text-danger"><?php echo form_error('region');?></span>
                </div>
                <div class="clearfix"></div>
                <div class="text-right btn_ar">
                    <div class="col-md-12 p_right">
                            <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                            <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
                    </div>
                </div>
        </form>
    </div>
</div>