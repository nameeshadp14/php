 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">List of User
				 <a href="<?php echo base_url('user/add');?>" class="btn btn-success btn-xs pull-right">Add User</a>
		</h2>
		
		<div class="row">
		    <form action="" method="get">
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="email" title="" value="<?php echo $this->input->get("email");?>" placeholder="Filter by Email" data-original-title="Filter by email">
		        </div>
		        
		        <div class="form-group col-xs-4 ">
		            <label for="name" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="name" title="" value="<?php echo $this->input->get("name");?>" placeholder="Filter by Name" data-original-title="Filter by name">
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="user_role" class="sr-only"></label>
		            <select name="user_role" id="user_role" class="form-control" data-toggle="tooltip" title="" data-original-title="*Viewer - only Can be able to view *Editor - Can be able to edit the entire information ">
		                <option value="">--Select Role--</option>
		                <?php foreach($role_list as $role) :?>
                    		<option value="<?php echo $role['role_id']?>" <?php echo $this->input->get('user_role')==$role['role_id'] ?'selected=selected':'';?>><?php echo $role['role_name']?></option>
                   		 <?php endforeach;?>
		            </select>
		        </div>
		        <div class="form-group col-xs-4">
		            <input type="submit" name="search_btn" class="btn btn-primary" value="Search">
		            <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('user')?>'" value="Reset">
		        </div>
		    </form>
		</div>
		
		
		<?php if(count($list_of_users)== 0) { ?>
			<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		<?php }else{ ?>
		<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
			   <div class="box-body">
                <table id="master_datatables" class="table table-striped"  >
               	 <thead>
                    <tr>
						<th>S.No</th>
						<th>Name</th>
						<th>Email ID</th>
						<th>Role</th>
						<th>Status</th>
						<th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    	 $cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				         $inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
                     	 foreach($list_of_users as $users){ ?>
                    <tr>
						<td><?php echo $inc; ?></td>
						<td><?php echo $users['name']; ?></td>
						<td><?php echo $users['email_id']; ?></td>
						<td><?php echo $users['role_name']; ?></td>
						<td><?php echo get_status($users['is_active']); ?></td>
						
						<td>
                            <a href="<?php echo site_url('user/edit/'.$users['user_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('user/remove/'.$users['user_id']); ?>" class="btn btn-danger remove_data btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php 
                    $inc++;
                     } ?>
                    </tbody>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
		</div>
		<?php } ?>
	</div>
</div>





