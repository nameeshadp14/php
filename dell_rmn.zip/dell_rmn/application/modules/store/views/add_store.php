<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Store
				<a href="<?php echo base_url('store');?>" class="btn btn-success btn-xs pull-right">Go back</a>
		</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="store_management" method="post" action="">
                <div class="col-md-6">
                    <label for="store_name" class="control-label">Store Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="store_name" value="<?php echo $this->input->post('store_name'); ?>" class="form-control" id="store_name" />
                        <span class="text-danger"><?php echo form_error('store_name');?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="store_code" class="control-label">Store Code <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="store_code" value="<?php echo $this->input->post('store_code'); ?>" class="form-control" id="store_code" />
                        <span class="text-danger"><?php echo form_error('store_code');?></span>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <label for="store_email" class="control-label">Store Email <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="store_email" value="<?php echo $this->input->post('store_email'); ?>" class="form-control" id="store_email" />
                        <span class="text-danger"><?php echo form_error('store_email');?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="store_contact_name" class="control-label">Contact Name</label>
                    <div class="form-group">
                        <input type="text" name="store_contact_name" value="<?php echo $this->input->post('store_contact_name'); ?>" class="form-control" id="store_contact_name" />
                        <span class="text-danger"><?php echo form_error('store_contact_name');?></span>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <label for="store_contact_email" class="control-label">Contact Email <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="store_contact_email" value="<?php echo $this->input->post('store_contact_email'); ?>" class="form-control" id="store_contact_email" />
                        <span class="text-danger"><?php echo form_error('store_contact_email');?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="store_contact_number" class="control-label">Contact Number <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="store_contact_number" value="<?php echo $this->input->post('store_contact_number'); ?>" class="form-control" id="store_contact_number" />
                        <span class="text-danger"><?php echo form_error('store_contact_number');?></span>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <label for="store_type" class="control-label">Store Type <span class="text-danger">*</span></label>
                    <div class="form-group">
                    	 <select name="store_type" class="form-control">
                            <option value="">--Select Type--</option>
                            <option value="1">DES</option>
                            <option value="2">LFR</option>
                            <option value="3">MBO</option>
                        </select>
                        <span class="text-danger"><?php echo form_error('store_type');?></span>
                    </div>
                </div>
 				<div class="col-md-6">
                    <label for="region_id" class="control-label">Region <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <select name="region_id" class="form-control">
                            <option value="">--Select Region--</option>
                            <?php foreach($list_of_region as $region) :?>
                                <option value="<?php echo $region['region_id']?>"> <?php echo $region['region_name']?> </option>
                            <?php endforeach;?>
                        </select>
                        <span class="text-danger"><?php echo form_error('region_id');?></span>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <label for="store_address" class="control-label">Address</label>
                    <div class="form-group">
                        <textarea name="store_address" class="form-control" id="store_address">
                            <?php echo $this->input->post('store_address'); ?>
                        </textarea>
                    </div>
                </div>
                
        </div>
        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
                <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />

            </div>
        </div>
    	</form>
	</div>
</div>