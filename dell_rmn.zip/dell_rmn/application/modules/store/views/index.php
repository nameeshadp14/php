 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">List of Store
				 <a href="<?php echo base_URL('store/add');?>" class="btn btn-success btn-xs pull-right">Add Store</a>
		</h2>
		<div class="row">
		    <form action="<?php echo base_url('store');?>" method="get">
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="sname" title="" value="<?php echo $this->input->get('sname');?>" placeholder="Filter by Store name" data-original-title="Filter by Store name">
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="scode" title="" value="<?php echo $this->input->get('scode');?>" placeholder="Filter by Store code" data-original-title="Filter by Store code">
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="stype" class="form-control">
                            <option value="">--Select Type--</option>
                            <option value="1" <?php echo $this->input->get('stype')==1 ? 'selected=selected':'';?>>DES</option>
                            <option value="2" <?php echo $this->input->get('stype')==2 ? 'selected=selected':'';?>>LFR</option>
                            <option value="3" <?php echo $this->input->get('stype')==3 ? 'selected=selected':'';?>>MBO</option>
                        </select>
		        </div>
		         <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="region" id="region" class="form-control">
                    	<option value="">-- Select Region --</option>
                    	<?php foreach($list_of_region as $region) :?>
                    		<option value="<?php echo $region['region_id']?>" <?php echo $this->input->get('region')==$region['region_id'] ?'selected=selected':'';?>><?php echo $region['region_name']?></option>
                   		 <?php endforeach;?>
                    </select>
		        </div>
		        <div class="form-group col-xs-4">
		            <input type="submit" name="search_btn" class="btn btn-primary" value="Search">
		            <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('store')?>'" value="Reset">
		        </div>
		    </form>
		</div>
		<?php if(count($list_of_city)== 0) { ?>
			<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		<?php }else{ ?>
		<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
			   <div class="box-body">
                <table id="master_datatables" class="table table-striped"  >
               	 <thead>
                    <tr>
						<th>S.No</th>
						<th>Store Name</th>
						<th>Store Code</th>
						<th>Store Type</th>
						<th>Region</th>
						<th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                     $cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                    $inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
                     foreach($list_of_city as $city){ ?>
                    <tr>
						<td><?php echo $inc++; ?></td>
						<td><?php echo $city['store_name']; ?></td>
						<td><?php echo $city['store_code']; ?></td>
						<td><?php echo get_store_type($city['store_type']); ?></td>
						<td><?php echo $city['region_name']; ?></td>
						<td>
                            <a href="<?php echo site_url('store/edit/'.$city['store_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                          	<a href="<?php echo site_url('store/remove/'.$city['store_id']); ?>" class="btn btn-danger remove_data btn-xs"><span class="fa fa-trash"></span> Delete</a> 
                        </td>
                    </tr>
                    <?php 
                     } ?>
                    </tbody>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
		</div>
		<?php } ?>
		
	</div>
</div>





