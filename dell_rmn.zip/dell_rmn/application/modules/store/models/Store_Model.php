<?php
class Store_Model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_stores_count($filter_data=null)
	{
		$this->db->where('s.status!=',-1);
		if(count($filter_data)>0){
			$this->db->like('s.store_name',$filter_data['sname'],'both');
			$this->db->like('s.store_code',$filter_data['scode'],'both');
			$this->db->like('s.store_type',$filter_data['stype'],'both');
			$this->db->like('r.region_id',$filter_data['region']);
		}
		$this->db->join('rmn_region_master as r','r.region_id=s.region_id','left');
		$this->db->from('rmn_store_master as s');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_stores($filter_data=null,$params = array())
	{
		if(count($filter_data)>0){
			$this->db->like('s.store_name',$filter_data['sname'],'both');
			$this->db->like('s.store_code',$filter_data['scode'],'both');
			$this->db->like('s.store_type',$filter_data['stype'],'both');
			$this->db->like('r.region_id',$filter_data['region']);
		}
		$this->db->where('s.status!=',-1);
		$this->db->order_by('s.store_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->join('rmn_region_master as r','r.region_id=s.region_id','left');
		$this->db->select('*');
		return $this->db->get('rmn_store_master s')->result_array();
	}
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_store_master',$param);
		return true;
	}
	
	/*
	 * Get the region details by id
	 */
	public function  get_store_details($id){
		$this->db->where('store_id',$id);
		$this->db->where('s.status!=',-1);
		$this->db->join('rmn_region_master as r','r.region_id=s.region_id','left');
		$this->db->select('*');
		return $this->db->get('rmn_store_master as s ')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_region($param,$id){
		$this->db->where('store_id',$id);
		return $this->db->update('rmn_store_master',$param);
	}
	/*
	 * Remove the Store
	 */
	public function remove_store($id){
		if($this->checkStorestatus($id)== 1 ){
			$this->db->where('store_id',$id);
			$param=array('status'=> -1,'updated_date' =>date("Y-m-d H:i:s"));
			$this->db->update('rmn_store_master',$param);
			return 1;
		}else{
			return -1;
		}
	}

	/*
	 * Check region relation table exist or not
	 */
	public function checkStorestatus($id){
		$flag=0;
		$this->db->select(" COUNT(`a`.`asset_store_id`) AS store");
		$this->db->where('s.store_id',$id);
		$this->db->join('rmn_asset_master a','a.asset_store_id=s.store_id','left');
		$this->db->from('rmn_store_master s');
		$query=$this->db->get()->row_array();
		if($query['city'] ==0 && $query['store']==0){
			return 1;
		}else{
			return -1;
		}
	}
}
