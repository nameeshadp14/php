<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('store_model');
		$this->load->model('region/region_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "store/index";
		$total_row = $this->store_model->get_all_stores_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_region"] = $this->region_model->get_all_regions();
		$data["list_of_city"] = $this->store_model->get_all_stores($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Store');
		$this->template->set('page_breadcrumb', 'List of Store');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Store');
		$this->template->set('page_breadcrumb', 'Add - Store');
		$data["list_of_region"] = $this->region_model->get_all_regions();
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('store_name','Store Name','required|max_length[50]');
			$this->form_validation->set_rules('store_code','Store Code','trim|required|max_length[50]|is_unique[rmn_store_master.store_code]');
			$this->form_validation->set_rules('store_email','Store Email','trim|required|max_length[50]|valid_email');
			$this->form_validation->set_rules('store_contact_name','Store Contact Name','max_length[50]');
			$this->form_validation->set_rules('store_contact_email','Store Contact Email','max_length[50]|valid_email');
			$this->form_validation->set_rules('store_contact_number','Store Contact Number','trim|required|integer');
			$this->form_validation->set_rules('store_type','Store Type','trim|required');
			$this->form_validation->set_rules('region_id','Region','trim|required|integer');
			if($this->form_validation->run())
			{
				 $params = array(
					'region_id' => $this->input->post('region_id'),
					'store_name' => $this->input->post('store_name'),
					'store_code' => $this->input->post('store_code'),
					'store_email' => $this->input->post('store_email'),
					'store_contact_name' => $this->input->post('store_contact_name'),
					'store_contact_email' => $this->input->post('store_contact_email'),
					'store_contact_number' => $this->input->post('store_contact_number'),
					'store_type' => $this->input->post('store_type'),
					'created_by' => $this->isUserID,
					'created_date' => date("Y-m-d H:i:s"),
					'updated_by' => $this->isUserID,
					'updated_date' =>date("Y-m-d H:i:s"),
					'store_address' => $this->input->post('store_address'),
	            );
				$this->store_model->add($params);
				$this->session->set_flashdata('success_msg', 'New Store added successfully.');
				redirect('store');
			}
		}
		$this->template->load('template', 'contents' , 'add_store',$data);
	}
	public function edit($id){
		$data = array();
		$data['store_info']=$this->store_model->get_store_details($id);
		if($data['store_info']['store_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Store');
			$this->template->set('page_breadcrumb', 'Edit - Store');
			$data["list_of_region"] = $this->region_model->get_all_regions();
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('store_name','Store Name','trim|required|max_length[50]');
				$this->form_validation->set_rules('store_code','Store Code','trim|required|max_length[50]|edit_unique[rmn_store_master.store_code.store_id.'.$id.']');
				$this->form_validation->set_rules('store_email','Store Email','trim|required|max_length[50]|valid_email');
				$this->form_validation->set_rules('store_contact_name','Store Contact Name','max_length[50]');
				$this->form_validation->set_rules('store_contact_email','Store Contact Email','max_length[50]|valid_email');
				$this->form_validation->set_rules('store_contact_number','Store Contact Number','trim|required|integer');
				$this->form_validation->set_rules('store_type','Store Type','trim|required');
				$this->form_validation->set_rules('region_id','Region','trim|required|integer');
				if($this->form_validation->run())
				{
				$params = array(
					'region_id' => $this->input->post('region_id'),
					'store_name' => $this->input->post('store_name'),
					'store_code' => $this->input->post('store_code'),
					'store_email' => $this->input->post('store_email'),
					'store_contact_name' => $this->input->post('store_contact_name'),
					'store_contact_email' => $this->input->post('store_contact_email'),
					'store_contact_number' => $this->input->post('store_contact_number'),
					'store_type' => $this->input->post('store_type'),
					'updated_by' => $this->isUserID,
					'updated_date' =>date("Y-m-d H:i:s"),
					'store_address' => $this->input->post('store_address'),
	            );
					$this->store_model->edit_region($params,$id);
					$this->session->set_flashdata('success_msg', 'Store details updated successfully.');
					redirect('store');
				}
			}
			$this->template->load('template', 'contents' , 'edit_store',$data);
		}else{
			redirect('unauthorize');
		}
	}
	/*
	 * Delete The Remoee - Vignesh -08062018
	 */
	public function remove($id){
		$data = array();
		$data['store_info']=$this->store_model->get_store_details($id);
		if($data['store_info']['store_id']){
			if($this->store_model->remove_store($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Store has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Store has been used in the application.');
			}
			redirect('store');
		}else{
			redirect('unauthorize');
		}
	}
}
