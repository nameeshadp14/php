<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Group_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	/*
	 * Get all groups count
	 */
	function get_all_groups_count($filter_data=null)
	{
		$this->db->where('g.group_status!=',-1);
		$this->db->order_by('g.group_name', 'ASC');
		if(count($filter_data)>0){
			$this->db->like('g.group_name',$filter_data['group_name'],'both');
		}
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->from('rmn_group_master as g');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all groups details
	 */
	function get_all_groups($filter_data=null,$params = array())
	{
		$this->db->where('g.group_status!=',-1);
		$this->db->order_by('g.group_name', 'ASC');
		$this->db->group_by('g.group_id');
		if(count($filter_data)>0){
			$this->db->like('g.group_name',$filter_data['group_name'],'both');
			$this->db->like('gm.model_id',$filter_data['model_id']);
		}
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->join('rmn_model_group_mapping as gm','gm.group_id=g.group_id','left');
		$this->db->select('g.*, COUNT(gm.`group_id`) AS model_cnt ');
		return $this->db->get('rmn_group_master g')->result_array();
	}
	/*
	 * Add New Group
	 */
	public function add($param,$model_id){
		$this->db->insert('rmn_group_master',$param);
		$this->db->select('max(group_id) as group_id');
		$this->db->from('rmn_group_master');
		$query=$this->db->get()->row_array();
		$group_id=$query['group_id'];
		foreach ($model_id as $model){
			$param1= array(
					'group_id'=>$group_id,
					'model_id'=>$model,
			);
			$this->db->insert('rmn_model_group_mapping',$param1);
		}
	}
	/*
	 * Get the Group details by id
	 */
	public function  get_group_details($id){
		$this->db->where('g.group_id',$id);
		$this->db->where('g.group_status!=',-1);
		$this->db->select('*');
		return $this->db->get('rmn_group_master as g ')->row_array();
	}
	
	/*
	 * Get the Group details by id
	 */
	public function  get_group_models($id){
		$this->db->where('gm.group_id',$id);
		$this->db->select('gm.model_id,m.model_name');
		$this->db->join('rmn_model_master as m','m.model_id=gm.model_id','left');
		return $this->db->get('rmn_model_group_mapping as gm ')->result_array();
	}
	/*
	 * Update the Group based on ID
	 */
	public function edit_groupinfo($param,$id){
		$this->db->where('group_id',$id);
		return $this->db->update('rmn_group_master',$param);
	}
	
	/*
	 * map the Group and model
	 */
	public function edit_groupmodel($model_list,$id){
		$this->db->where('group_id',$id);
		$this->db->delete('rmn_model_group_mapping');
		if(count($model_list)>0){
			foreach ($model_list as $model){
				$param = array(
						'model_id' =>$model,
						'group_id' =>$id,
				);
				$this->db->insert('rmn_model_group_mapping',$param);
			}
		}
		return true;
	}
	/*
	 * Remove the Group
	 */
	public function remove_group($id){
		if($this->checkGroupstatus($id)== 1 ){
			$this->db->where('group_id',$id);
			$param=array('group_status'=> -1,'updated_by' => $this->isUserID,'updated_date' => date("Y-m-d H:i:s"));
			$this->db->update('rmn_group_master',$param);
			return 1;
		}else{
			return -1;
		}
	}

	/*
	 * Check Group relation table exist or not
	 */
	public function checkGroupstatus($id){
		$this->db->select("COUNT(`s`.`group_id`) AS scheduler");
		$this->db->where('s.group_id',$id);
		$this->db->group_by('s.group_id');
		$this->db->join('rmn_scheduler as s','s.group_id=g.group_id','left');
		$this->db->from('rmn_group_master g');
		$query=$this->db->get()->row_array();
		if($query['scheduler'] ==0 ){
			return 1;
		}else{
			return -1;
		}
	}
	
	public function checkduplicategroupforadd($group){
		$this->db->select('group_id');
		$this->db->where('group_name',$group);
		$this->db->where('group_status !=',-1);
		$getgroup=$this->db->get('rmn_group_master')->result_array();
		if(count($getgroup)>0){
			return -1;
		}else{
			return 1;
		}
	}
	public function checkduplicategroupforedit($group,$id){
		$this->db->select('*');
		$this->db->where('group_name',$group);
		$this->db->where('group_id!=',$id);
		$getgroup=$this->db->get('rmn_group_master')->result_array();
		if(count($getgroup)>0){
			return -1;
		}else{
			return 1;
		}
	
	}
	
}
