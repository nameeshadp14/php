<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fSelect.css');?>">
<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add Group
		<a href="<?php echo base_url('group');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="group_management" method="post" action="">
                <div class="col-md-6">
                    <label for="store_name" class="control-label">Group Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="group_name" value="<?php echo $this->input->post('group_name'); ?>" class="form-control" id="group_name" />
                        <span class="text-danger"><?php echo form_error('group_name');?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="model_name" class="control-label">Model Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <select class="cus_multi_select form-control" multiple="multiple" name="model_id[]" id="model_id">
					        <?php foreach ($list_of_model as $model) {  ?>
							        <option value="<?php echo $model['model_id'];?>" <?php 	if($this->input->post('model_id')):echo in_array($model['model_id'],$this->input->post('model_id')) ? 'selected=selected':'';endif;
		                    		?>><?php echo $model['model_name'];?></option>
					        <?php } ?>
					    </select>
					     <span class="text-danger"><?php echo form_error('model_id');?></span>
                    </div>
                </div>
		        
		        <div class="clearfix"></div>
		        <div class="text-right btn_ar">
		            <div class="col-md-12 p_right">
		            	<input type="submit" name="save_add" id="save_add_btn"  class="btn btn-primary video_btn_type" value="SAVE">
		                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
		            </div>
		        </div>
    	   </form>
    	</div>
	</div>
</div>
<script type='text/javascript' src="<?php echo base_url('assets/js/fSelect.js');?>"></script>
<script>
(function($) {
    $(function() {
        $('.cus_multi_select').fSelect();
    });
})(jQuery);
</script>