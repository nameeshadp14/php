<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Group extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin || $this->isEditor ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('group_model');
		$this->load->model('model/model_model');
	}
	/*
	 * List the of groups with filter
	 */
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "group/index";
		$total_row = $this->group_model->get_all_groups_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_model"] = $this->model_model->get_all_models();
		$data["list_of_group"] = $this->group_model->get_all_groups($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Group');
		$this->template->set('page_breadcrumb', 'List of Group');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	/*
	 * Add a new group 
	 */
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Group');
		$this->template->set('page_breadcrumb', 'Add - Group');
		$data["list_of_model"] = $this->model_model->get_all_models();
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('group_name','Group Name','trim|required|max_length[50]');
			$this->form_validation->set_rules('model_id', 'Model Name', 'callback_model_check');
			if($this->form_validation->run())
			{
				 $params = array(
					'group_name' => $this->input->post('group_name'),
					'created_by' => $this->isUserID,
					'created_date' => date("Y-m-d H:i:s"),
					'updated_by' => $this->isUserID,
					'updated_date' =>date("Y-m-d H:i:s"),
	            );
				 $getstatus=$this->group_model->checkduplicategroupforadd($this->input->post('group_name'));
				 if($getstatus==1)
				 {
				$playlist_id=$this->group_model->add($params,$this->input->post('model_id'),$this->input->post('group_name'));
				if($this->input->post('btn_type')==1){
					$this->session->set_flashdata('success_msg', 'New Group Added successfully.you can edit details here');
					redirect('group/edit/'.$playlist_id);
				}else{
					$this->session->set_flashdata('success_msg', 'New Group added successfully.');
					redirect('group');
				}
				 }else {
				 	$this->session->set_flashdata('error_msg','Group Name already exist.');
				 }
			}
		}
		$this->template->load('template', 'contents' , 'add_group',$data);
	}
	/*
	 * Edit the Groups
	 */
	public function edit($id){
		$data = array();
		$data['group_info']=$this->group_model->get_group_details($id);
		if($data['group_info']['group_id']){
			$data["list_of_model"] = $this->model_model->get_all_models();
			$data['group_model']=$this->group_model->get_group_models($id);
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Playlist');
			$this->template->set('page_breadcrumb', 'Edit - Playlist');
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('group_name','Group Name','trim|required|max_length[50]');
				$this->form_validation->set_rules('model_id', 'Model Name', 'callback_model_check');
				if($this->form_validation->run())
				{
					 $params = array(
						'group_name' => $this->input->post('group_name'),
						'updated_by' => $this->isUserID,
						'updated_date' =>date("Y-m-d H:i:s"),
		            );
					 $getstatus=$this->group_model->checkduplicategroupforedit($this->input->post('group_name'),$id);
					 if($getstatus==1)
					 {
						$this->group_model->edit_groupinfo($params,$id);
						$this->group_model->edit_groupmodel($this->input->post('model_id'),$id);
						$this->session->set_flashdata('success_msg', 'Group details updated successfully.');
						redirect('group');
					}else{
						$this->session->set_flashdata('error_msg','Group Name already exist.');
						redirect('group/edit/'.$id);
					}
					}
			}
			$this->template->load('template', 'contents' , 'edit_group',$data);
		}else{
			redirect('unauthorize');
		}
	}
	
	/*
	 * Check the model value is there are not
	 */
	function model_check(){
		if(empty($this->input->post('model_id'))){
			$this->form_validation->set_message('model_check', 'Invalid Model selection');
			return false;
		}else{
			return true;
		}
	}
	/*
	 * Delete The Group - Vignesh -08062018
	 */
	public function remove($id){
		$data = array();
		$data['group_info']=$this->group_model->get_group_details($id);
		if($data['group_info']['group_id']){
			if($this->group_model->remove_group($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Group has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Group has been used in the application.');
			}
			redirect('group');
		}else{
			redirect('unauthorize');
		}
	}
}
