<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit Region
				<a href="<?php echo base_url('region');?>" class="btn btn-success btn-xs pull-right">Go back</a>
		</h2>
    <div class="box-body">
        <form class="frm_inner cmn_form" id="region_management" method="post" action="">
            <div class="row m_left m_right">
                <div class="col-md-6 form-group">
                    <label>Region Name <span class="text-danger">*</span></label>
                    <input type="text" name="region_name" id="region_name" data-toggle="tooltip" value="<?php echo set_value("region_name",$region_info['region_name']); ?>" class="form-control">
                	<span class="text-danger"><?php echo form_error('region_name');?></span>
                </div>
                <div class="clearfix"></div>
                <div class="text-right btn_ar">
                    <div class="col-md-12 p_right">
                            <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                            <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
                            
                    </div>
                </div>
        </form>
        </div>
    </div>