<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Region extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('region_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "region/index";

		$total_row = $this->region_model->get_all_regions_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_city"] = $this->region_model->get_all_regions($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Region');
		$this->template->set('page_breadcrumb', 'List of Region');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Region');
		$this->template->set('page_breadcrumb', 'Add - Region');
		
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('region_name','Region Name','trim|required|is_unique[rmn_region_master.region_name]');
			
			if($this->form_validation->run())
			{
				$params = array(
						'region_name' => $this->input->post('region_name'),
						);
				
				$check_status=$this->region_model->check_region_status($params);
				
// 				if($check_status==1){
				$this->region_model->add($params);
				$this->session->set_flashdata('success_msg', 'New Region added successfully.');
				redirect('region');
// 				}else{
// 					$this->session->set_flashdata('error_msg','Region name already exist.');
// 				}
			}
		}
		$this->template->load('template', 'contents' , 'add_region',$data);
	}
	public function edit($id){
		$data = array();
		$data['region_info']=$this->region_model->get_region_details($id);
		if($data['region_info']['region_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Region');
			$this->template->set('page_breadcrumb', 'Edit - Region');
		
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('region_name','Region Name','trim|required|edit_unique[rmn_region_master.region_name.region_id.'.$id.']');
				
				if($this->form_validation->run())
				{
					$params = array(
							'region_name' => $this->input->post('region_name'),
					);
					$this->region_model->edit_region($params,$id);
					$this->session->set_flashdata('success_msg', 'Region updated successfully.');
					redirect('region');
				}
			}
			$this->template->load('template', 'contents' , 'edit_region',$data);
		}else{
			redirect('unauthorize');
		}
	}
	
	/*
	 * Delete The region - Vignesh -06062018
	 */
	public function remove($id){
		$data = array();
		$data['region_info']=$this->region_model->get_region_details($id);
		if($data['region_info']['region_id']){
			if($this->region_model->remove_region($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Region has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Region has been used in the application.');
			}
			redirect('region');
		}else{
			redirect('unauthorize');
		}
	}
}
