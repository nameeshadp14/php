<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Region_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_regions_count($filter_data=null)
	{
		if(count($filter_data)>0){
				$this->db->like('region_name',$filter_data['region'],'both');
		}
		$this->db->where('status !=',-1);
		$this->db->from('rmn_region_master');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_regions($filter_data=null,$params = array())
	{
		$this->db->order_by('region_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->where('status !=',-1);
		if(count($filter_data)>0){
				$this->db->like('region_name',$filter_data['region'],'both');
		}
		return $this->db->get('rmn_region_master')->result_array();
	}
	
	/*
	 * Check the region are already exist
	 * */
	public function check_region_status($param=array()){
		$this->db->select('COUNT(region_name) AS count');
		$this->db->where('status !=',-1);
		$this->db->where('region_name',$param['region_name']);
		$query=$this->db->get('rmn_region_master')->row()->count;
		if($query==0){
			return 1;
		}else{
			return -1;
		}
		
	}
	
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_region_master',$param);
		return true;
	}
	
	/*
	 * Get the region details by id
	 */
	public function get_region_details($id){
		$this->db->where('status !=',-1);
		$this->db->where('region_id',$id);
		return $this->db->get('rmn_region_master')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_region($param,$id){
		$this->db->where('region_id',$id);
		return $this->db->update('rmn_region_master',$param);
	}
	/*
	 * Remove the region
	 */
	public function remove_region($id){
		if($this->checkRegionstatus($id)== 1 ){
			$this->db->where('region_id',$id);
			$param=array('status'=> -1);
			$this->db->update('rmn_region_master',$param);
			return 1;
		}else{
			return -1;
		}
	}
	/*
	 * Check region relation table exist or not
	 */
	public function checkRegionstatus($id){
		$this->db->select(" COUNT(`c`.`reg_id`) AS city,COUNT(s.`region_id`) AS store ,COUNT(`sdu`.`region_id`) AS scheduler");
		$this->db->where('m.region_id',$id);
		$this->db->where('m.status !=',-1);
		$this->db->where('sdu.sch_status !=',-1);
		$this->db->where('c.status !=',-1);
		$this->db->join('rmn_scheduler sdu','sdu.region_id=m.region_id','left');
		$this->db->join('rmn_store_master s','s.region_id=m.region_id','left');
		$this->db->join('rmn_city_master c','c.reg_id=m.region_id','left');
		$this->db->from('rmn_region_master m');
		$query=$this->db->get()->row_array();
		if($query['city'] ==0 && $query['store']==0 && $query['scheduler']==0){
			return 1;
		}else{
			return -1;
		}
	}
}
