 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">List of Assets
				 <!--<a href="<?php echo base_URL('asset/add');?>" class="btn btn-success btn-xs pull-right">Add Asset</a>-->
		</h2>
		<div class="row">
		    <form action="<?php echo base_url('asset');?>" method="get">
		     
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="asset_code"  value="<?php echo $this->input->get('asset_code');?>" placeholder="Filter by Asset code" data-original-title="Filter by Asset code">
		        </div>
		        
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="store_id" id="store_id" class="form-control">
                    	<option value="">--Select Store--</option>
                    	<?php foreach($store_info as $store) :?>
                    		<option value="<?php echo $store['store_id']?>" <?php echo $this->input->get('store_id')==$store['store_id'] ?'selected=selected':'';?>><?php echo $store['store_name']?></option>
                   		 <?php endforeach;?>
                    </select>
		        </div>
		         
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="model_id" id="model_id" class="form-control">
                    	<option value="">--Select Model--</option>
                    	  <?php foreach($model_info as $model) :?>
                                <option value="<?php echo $model['model_id'];?>" <?php echo $this->input->get('model_id')==$model['model_id'] ?'selected=selected':'';?>> <?php echo $model['model_name'];?> </option>
                          <?php endforeach;?>
                    </select>
		        </div>
		        
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="brand_id" id="brand_id" class="form-control">
                    	<option value="">--Select Brand--</option>
                    	  <?php foreach($brand_info as $brand) :?>
                                <option value="<?php echo $brand['brand_id'];?>" <?php echo $this->input->get('brand_id')==$brand['brand_id'] ?'selected=selected':'';?>> <?php echo $brand['brand_name'];?> </option>
                          <?php endforeach;?>
                    </select>
		        </div>
		          
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="asset_status" id="asset_status" class="form-control">
                    	<option value="">--Select Status--</option>
                    	<?php 
                    		$status=$this->input->get('asset_status');
                    	?>
                    		<option value="1"  <?php  if(isset($status)){ echo $status== '1' ? 'selected=selected':''; } ?>>Active</option>
                    		<option value="2"  <?php  if(isset($status)){ echo $status== '2' ? 'selected=selected':''; } ?>>Expired</option>
                    		<option value="0" <?php  if(isset($status)){ echo $status== '0' ? 'selected=selected':''; } ?>>Inactive</option>
                    </select>
		        </div>
		        <div class="form-group col-xs-4">
		            <input type="submit" name="search_btn" class="btn btn-primary" value="search">
		            <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('asset')?>'" value="Reset">
		        </div>
		    </form>
		</div>
		<?php if(count($list_of_asset)== 0) { ?>
			<h3 class="text-center">No result found</h3>
		<?php }else{ ?>
		<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
			   <div class="box-body">
                <table id="master_datatables" class="table table-striped"  >
               	 <thead>
                    <tr>
						<th>S.No</th>
						<th>Asset Code</th>
						<th>Store</th>
						<th>Model</th>
						<th>Brand</th>
						<th>Register Date</th>
						<th>Expiry Date</th>
						<th>Status</th>
						<th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				    $inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
                     foreach($list_of_asset as $p){ ?>
                    <tr>
						<td><?php echo $inc; ?></td>
						<td><?php echo $p['asset_code']; ?></td>
						<td><?php echo $p['store_name']; ?></td>
						<td><?php echo $p['model_name']; ?></td>
						<td><?php echo $p['brand_name']; ?></td>
						<td><?php echo date('d-m-Y' ,strtotime($p['asset_reg_date'])); ?></td>
						<td><?php echo date('d-m-Y',strtotime($p['asset_expiry_date'])); ?></td>
						
						<td><?php echo get_asset_status($p['asset_status']); ?></td>
						<td>
                            <a href="<?php echo site_url('asset/view/'.$p['asset_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-eye"></span> View</a> 
                        </td>
                    </tr>
                    <?php 
                    $inc++;
                     } ?>
                    </tbody>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
		</div>
		<?php } ?>
		
	</div>
</div>





