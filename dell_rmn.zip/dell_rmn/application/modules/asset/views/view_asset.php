<style>
form#asset_management .form-group span {
    font-weight: bold;
}
</style>
<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">View Asset
    <div class="pull-right">
    <a href="<?php echo base_url('asset');?>" class="btn btn-success btn-xs m_left_10">Go back</a>

				</a>    
		</div>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
        	<form name="asset" id="asset_management" class="cmn_form" method="post">
        	<div class="col-md-6">
				<label for="asset_code" class="control-label">Asset Code</label>
				<div class="form-group">
					<span><?php echo set_value('asset_code',$asset_info['asset_code']); ?></span>
				</div>
			</div>
			<div class="col-md-6">
				<label for="asset_service_tag" class="control-label">Service Tag</label>
				<div class="form-group">
					<span><?php echo set_value('asset_service_tag',$asset_info['asset_service_tag']); ?></span>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="asset_reg_date" class="control-label">Registred Date</label>
				<div class="form-group">
					<span><?php echo $asset_info['asset_reg_date']!=''? date("d/m/Y H:i",strtotime($asset_info['asset_reg_date'])):set_value('asset_reg_date'); ?></span>
				</div>
			</div>
			<div class="col-md-6">
				<label for="asset_expiry_date" class="control-label">Expiry Date</label>
				<div class="form-group">
					<span><?php echo $asset_info['asset_expiry_date']!=''? date("d/m/Y H:i",strtotime($asset_info['asset_expiry_date'])):set_value('asset_expiry_date'); ?></span>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="model_id" class="control-label">Model </label>
				<div class="form-group">
					<span> <?php echo $asset_info['model_name'];?> </span> 
                 </div>
			</div>
			<div class="col-md-6">
				<label for="asset_store_id" class="control-label">Store </label>
				<div class="form-group">
					<span> <?php echo $asset_info['store_name'];?> </span> 
                 </div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
                    <label>Status </label>
					<div class="form-group">
						<span> <?php echo get_asset_status($asset_info['asset_status']); ?></span> 
					</div>
			</div>
		</div>
        
    	</form>
	</div>
</div>
<?php 
?>
