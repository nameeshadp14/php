<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add Asset
		<a href="<?php echo base_url('asset');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
        	<form name="asset" id="asset_management" class="cmn_form" method="post">
        	<div class="col-md-6">
				<label for="asset_code" class="control-label">Asset Code <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="text" name="asset_code" value="<?php echo $this->input->post('asset_code'); ?>" class="form-control" id="asset_code" />
					<span class="text-danger"><?php echo form_error('asset_code');?></span>
				</div>
			</div>
			<div class="col-md-6">
				<label for="asset_service_tag" class="control-label">Service Tag</label>
				<div class="form-group">
					<input type="text" name="asset_service_tag"   value="<?php echo $this->input->post('asset_service_tag'); ?>" class="form-control" id="asset_service_tag" />
					<span class="text-danger"><?php echo form_error('asset_service_tag');?></span>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="asset_reg_date" class="control-label">Registred Date</label>
				<div class="form-group">
					<input type="text" name="asset_reg_date" onkeydown="return false;"autocomplete="off" value="<?php echo $this->input->post('asset_reg_date'); ?>" class="form-control" id="asset_reg_date" />
				</div>
			</div>
			<div class="col-md-6">
				<label for="asset_expiry_date" class="control-label">Expiry Date</label>
				<div class="form-group">
					<input type="text" name="asset_expiry_date" onkeydown="return false;" autocomplete="off" value="<?php echo $this->input->post('asset_expiry_date'); ?>" class=" form-control" id="asset_expiry_date" />
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="model_id" class="control-label">Model <span class="text-danger">*</span></label>
				<div class="form-group">
					<select name="model_id" class="form-control">
						<option value="">--Select Model--</option>
						  <?php foreach($model_info as $model) :?>
                                <option value="<?php echo $model['model_id'];?>"> <?php echo $model['model_name'];?> </option>
                          <?php endforeach;?>
					</select>
					<span class="text-danger"><?php echo form_error('model_id');?></span>
				</div>
			</div>
			<div class="col-md-6">
				<label for="asset_store_id" class="control-label">Store <span class="text-danger">*</span></label>
				<div class="form-group">
					    <select name="asset_store_id" class="form-control">
                            <option value="">--Select Store--</option>
                            <?php foreach($store_info as $store) :?>
                                <option value="<?php echo $store['store_id']?>"> <?php echo $store['store_name']?> </option>
                            <?php endforeach;?>
                        </select>
					<span class="text-danger"><?php echo form_error('asset_store_id');?></span>
				</div>
			</div>
			<div class="col-md-6 form-group">
                    <label>Status <span class="text-danger">*</span></label>
                    <select name="asset_status" id="asset_status" class="form-control">
                    	<option value="">--Select Status--</option>
                    		<option value="1">Active</option>
                    		<option value="2">Expired</option>
                    		<option value="0">Inactive</option>
                    </select>
                	<span class="text-danger"><?php echo form_error('asset_status');?></span>
             </div>
		</div>
        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
                <input type="submit" name="save_btn" class="btn btn-primary" value="SAVE">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />

            </div>
        </div>
    	</form>
	</div>
</div>