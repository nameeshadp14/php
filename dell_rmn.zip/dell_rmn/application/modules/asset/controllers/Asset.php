<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('asset_model');
		$this->load->model('store/store_model');
		$this->load->model('model/model_model');
		$this->load->model('brand/brand_model');
		$this->load->model('report/report_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$params['limit'] = RECORDS_PER_PAGE;
		$filter_data=$this->input->get();
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "asset/index";
		$total_row = $this->asset_model->get_all_assets_count($filter_data);
		$data['store_info']=$this->store_model->get_all_stores();
		$data['model_info']=$this->model_model->get_all_models();
		$data['brand_info']=$this->brand_model->get_all_brands();
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_asset"] = $this->asset_model->get_all_assets($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Assets');
		$this->template->set('page_breadcrumb', 'List of Assets');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	/*public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Asset');
		$this->template->set('page_breadcrumb', 'Add - Asset');
		$data['store_info']=$this->store_model->get_all_stores();
		$data['model_info']=$this->model_model->get_all_models();
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('asset_status','Asset Status','trim|required');
			$this->form_validation->set_rules('asset_code','Asset Code','trim|required|max_length[50]');
			$this->form_validation->set_rules('asset_service_tag','Asset Service Tag','max_length[50]');
			$this->form_validation->set_rules('model_id','Model Id','trim|required|integer');
			$this->form_validation->set_rules('asset_store_id','Asset Store Id','trim|required|integer');
			
			if($this->form_validation->run())
			{
				$check_status=$this->asset_model->check_asset_status($this->input->post('model_id'),$this->input->post('asset_store_id'),$this->input->post('asset_code'));
				if($check_status == -1){
					$this->session->set_flashdata('error_msg', 'Asset Code already mapped with this Model and Store.');
					redirect('asset/add');
				}
				$reg_date=null;$exp_date=null;
				if( $this->input->post('asset_reg_date') !=''){
					$reg_date=date('Y-m-d H:i:s',strtotime( convertdb_date_format($this->input->post('asset_reg_date'))));
				}
				if( $this->input->post('asset_expiry_date') !=''){
					$exp_date=date('Y-m-d H:i:s',strtotime(convertdb_date_format($this->input->post('asset_expiry_date'))));
				}
				$params = array(
					'asset_status' => $this->input->post('asset_status'),
					'model_id' => $this->input->post('model_id'),
					'asset_store_id' => $this->input->post('asset_store_id'),
					'asset_code' => $this->input->post('asset_code'),
					'asset_service_tag' => $this->input->post('asset_service_tag'),
					'asset_reg_date' => $reg_date,
					'asset_sessionguid'=>random_string('sha1', 25),
					'raw_asset_id'=>1,
					'asset_expiry_date' =>$exp_date,
					'created_by' => $this->isUserID,
					'created_date' => date("Y-m-d H:i:s"),
					'updated_by' => $this->isUserID,
					'updated_date' => date("Y-m-d H:i:s"),
	            );
				$this->asset_model->add($params);
				$this->session->set_flashdata('success_msg', 'New Asset added successfully.');
				redirect('asset');
			}
		}
		$this->template->load('template', 'contents' , 'add_asset',$data);
	}
*/
	/*public function edit($id){
		$data = array();
		$data['asset_info']=$this->asset_model->get_asset_detailby_id($id);
		if($data['asset_info']['asset_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Asset');
			$this->template->set('page_breadcrumb', 'Edit - Asset');
			$data['store_info']=$this->store_model->get_all_stores();
			$data['model_info']=$this->model_model->get_all_models();
			
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('asset_status','Asset Status','trim|required');
				$this->form_validation->set_rules('asset_code','Asset Code','trim|required|max_length[50]');
				$this->form_validation->set_rules('asset_service_tag','Asset Service Tag','trim|max_length[50]');
				$this->form_validation->set_rules('model_id','Model Id','trim|required|integer');
				$this->form_validation->set_rules('asset_store_id','Asset Store Id','trim|required|integer');
									
				if($this->form_validation->run())
				{
					$check_status=$this->asset_model->check_asset_status($this->input->post('model_id'),$this->input->post('asset_store_id'),$this->input->post('asset_code'),$id);
					if($check_status == -1){
						$this->session->set_flashdata('error_msg', 'Asset Code already mapped with this Model and Store.');
						redirect('asset/edit/'.$id);
					}
					$reg_date=null;$exp_date=null;
					if( $this->input->post('asset_reg_date') !=''){
						$reg_date=date('Y-m-d H:i:s',strtotime( convertdb_date_format($this->input->post('asset_reg_date'))));
					}
					if( $this->input->post('asset_expiry_date') !=''){
						$exp_date=date('Y-m-d H:i:s',strtotime(convertdb_date_format($this->input->post('asset_expiry_date'))));
					}
					$params = array(
							'asset_status' => $this->input->post('asset_status'),
							'model_id' => $this->input->post('model_id'),
							'asset_store_id' => $this->input->post('asset_store_id'),
							'asset_code' => $this->input->post('asset_code'),
							'asset_service_tag' => $this->input->post('asset_service_tag'),
							'asset_reg_date' => $reg_date,
							'asset_expiry_date' =>$exp_date,
							'updated_by' => $this->isUserID,
							'updated_date' => date("Y-m-d H:i:s"),
					);
					$this->asset_model->edit_asset($params,$id);
					$this->session->set_flashdata('success_msg', 'Asset details updated successfully.');
					redirect('asset');
				}
			}
			$this->template->load('template', 'contents' , 'edit_asset',$data);
		}else{
			redirect('unauthorize');
		}
	}
	*/
	public function view($id){
		$data = array();
		$data['asset_info']=$this->asset_model->get_asset_detailby_id($id);
		if($data['asset_info']['asset_id']){
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'View - Asset');
			$this->template->set('page_breadcrumb', 'View - Asset');
			$data['store_info']=$this->store_model->get_all_stores();
			$data['model_info']=$this->model_model->get_all_models();
			$this->template->load('template', 'contents' , 'view_asset',$data);
		}else{
			redirect('unauthorize');
		}
	}
	
	/*
	 * Export the asset report------------Nameesha-27/10/18
	 */
	public function exportforassets($id){
		// file name
		
		$filename="asset_detail.csv";
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-type: text/csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		// get data
		$usersData = $this->asset_model->get_asset_detailby_id($id);
		
		$file = fopen('php://output', 'w');
		$item=array();
		$title=array("Asset Details");
		fputcsv($file, $title);
		$header = array("Asset Code","Service Tag","Registred Date","Expiry Date","Model","Store","Status");
		fputcsv($file, $header);
		//$sn=1;
			//$item['s.no']=$sn;
			$item['Asset_code']=$usersData['asset_code'];
			$item['asset_service_tag']=$usersData['asset_service_tag'];
			$item['Registered_date']=date('d-m-Y',strtotime($usersData['asset_reg_date']));
			$item['Expiry_date']=date('d-m-y',strtotime($usersData['asset_expiry_date']));
			$item['model']=$usersData['model_name'];
			$item['Store']=$usersData['store_name'];
			$item['Status']=($usersData['asset_status']=='1'?"Active":($usersData['asset_status']=='0'?"Inactive":"Expired"));
			fputcsv($file,$item);
			
		fclose($file);
		exit;
	}
}
