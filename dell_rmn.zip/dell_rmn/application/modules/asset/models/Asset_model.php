<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_assets_count($filter_data=null)
	{
		if(count($filter_data)>0){
			$this->db->like('a.asset_code',$filter_data['asset_code'],'both');
			$this->db->like('s.store_id',$filter_data['store_id']);
			$this->db->like('m.model_id',$filter_data['model_id']);
			$this->db->like('b.brand_id',$filter_data['brand_id']);
			$this->db->like('a.asset_status',$filter_data['asset_status']);
		}
		$this->db->where('a.asset_status !=',-1);
		$this->db->select('a.*,m.model_name,s.store_name,b.brand_name');
		$this->db->join('rmn_store_master as s','s.store_id=a.asset_store_id','left');
		$this->db->join('rmn_model_master as m','m.model_id=a.model_id','left');
		$this->db->join('rmn_brand_master as b','b.brand_id=m.brand_id','left');
		$this->db->from('rmn_asset_master as a');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all pmo_status_master
	 */
	function get_all_assets($filter_data=null,$params = array())
	{
		$this->db->order_by('a.asset_code', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		if(count($filter_data)>0){
			$this->db->like('a.asset_code',$filter_data['asset_code'],'both');
			$this->db->like('s.store_id',$filter_data['store_id']);
			$this->db->like('m.model_id',$filter_data['model_id']);
			$this->db->like('b.brand_id',$filter_data['brand_id']);
			$this->db->like('a.asset_status',$filter_data['asset_status']);
		}
		$this->db->where('a.asset_status !=',-1);
		$this->db->select('a.*,m.model_name,s.store_name,b.brand_name');
		$this->db->join('rmn_store_master as s','s.store_id=a.asset_store_id','left');
		$this->db->join('rmn_model_master as m','m.model_id=a.model_id','left');
		$this->db->join('rmn_brand_master as b','b.brand_id=m.brand_id','left');
		return $this->db->get('rmn_asset_master as a')->result_array();
	}
	/*
	 * Get the asset details by ID
	 */
	public function get_asset_detailby_id($id){
		$this->db->select('a.*,m.model_name,s.store_name');
		$this->db->where('asset_id',$id);
		$this->db->where('asset_status !=',-1);
		$this->db->join('rmn_store_master as s','s.store_id=a.asset_store_id','left');
		$this->db->join('rmn_model_master as m','m.model_id=a.model_id','left');
		$this->db->join('rmn_brand_master as b','b.brand_id=m.brand_id','left');
		return $this->db->get('rmn_asset_master as a')->row_array();
	}
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_asset_master',$param);
		return true;
	}
	/*
	 * Check the Asset exist or not
	 */
	public function check_asset_status($model_name,$store_id,$asset_code,$asset_id=null){
		$this->db->select('*');
		$this->db->from('rmn_asset_master');
		$this->db->where('model_id',$model_name);
		$this->db->where('asset_store_id',$store_id);
		$this->db->where('asset_code',$asset_code);
		$query=$this->db->get();
		$result=$query->row_array();
		$cnt_data=$query->num_rows();
		if($cnt_data > 0){
			if($asset_id !=''){
				if($asset_id != $result['asset_id']):
					return -1;
				else:
					return 1;
				endif;
			}
			return -1;
		}
		return 1;
	}
	/*
	 * Get the brand details by id
	 */
	public function  get_brand_details($id){
		$this->db->where('brand_id',$id);
		return $this->db->get('rmn_asset_master')->row_array();
	}
	/*
	 * Update the edit asset on ID
	 */
	public function edit_asset($param,$id){
		$this->db->where('asset_id',$id);
		return $this->db->update('rmn_asset_master',$param);
	}
	/*
	 * Remove the Asset
	 */
	public function remove_asset($id){
		if($this->checkAssetstatus($id)== 1 ){
			$this->db->where('asset_id',$id);
			$param=array('asset_status'=> -1,
					'updated_by' => $this->isUserID,
					'updated_date' => date("Y-m-d H:i:s"));
			$this->db->update('rmn_asset_master',$param);
			return 1;
		}else{
			return -1;
		}
	}
	/*
	 * Check region relation table exist or not
	 */
	public function checkAssetstatus($id){
		$this->db->select(" COUNT(ah.asset_id) AS asset");
		$this->db->where('a.asset_id',$id);
		$this->db->join('rmn_asset_hearbeat ah','ah.asset_id=a.asset_id','left');
		$this->db->from('rmn_asset_master a');
		$query=$this->db->get()->row_array();
		if($query['asset'] ==0){
			return 1;
		}else{
			return -1;
		}
	}
}
