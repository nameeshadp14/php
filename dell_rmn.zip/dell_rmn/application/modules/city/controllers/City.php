<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class City extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('city_model');
		$this->load->model('region/region_model');
	}
	/*
	 * List the city list - Vignesh -05062018
	 */
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "city/index";
		$total_row = $this->city_model->get_all_city_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['limit'] = RECORDS_PER_PAGE;
		$params['offset'] = $page;
		$data["list_of_city"] = $this->city_model->get_all_city($filter_data,$params);
		$data["list_of_region"] = $this->region_model->get_all_regions();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of City');
		$this->template->set('page_breadcrumb', 'List of City');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	/*
	 * Add the new city - Vignesh -05062018
	 */
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$data["list_of_region"] = $this->region_model->get_all_regions();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add City');
		$this->template->set('page_breadcrumb', 'Add City');
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('city_name','City Name','trim|required|is_unique[rmn_city_master.city_name]');
			$this->form_validation->set_rules('region','Region','trim|required');
				if($this->form_validation->run()){
					$params = array(
							'city_name' => $this->input->post('city_name'),
							'reg_id' => $this->input->post('region'),
					);
					$check_statusforadd=$this->city_model->check_city_status($params);
					if($check_statusforadd==1){
					$this->city_model->add($params);
						$this->session->set_flashdata('success_msg', 'New City added successfully.');
						redirect('city');
					}else{
						$this->session->set_flashdata('error_msg', 'The City already exist in that Region.');				}
				    }	
		}
	    $this->template->load('template', 'contents' , 'add_city',$data);
	}
	/*
	 * Edit the new city - Vignesh -05062018
	 */
	public function edit($id){
		$data = array();
		$data['city_details']=$this->city_model->get_city_details($id);
		if($data['city_details']['city_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			
			$data["list_of_region"] = $this->region_model->get_all_regions();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit City');
			$this->template->set('page_breadcrumb', 'Edit City');
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('city_name','City Name','trim|required|edit_unique[rmn_city_master.city_name.city_id.'.$id.']');
				$this->form_validation->set_rules('region','Region','trim|required');
		
				if($this->form_validation->run())
				{
					$params = array(
							'city_name' => $this->input->post('city_name'),
							'reg_id' => $this->input->post('region'),
					);
					$checkstatusforedit=$this->city_model->check_city_statusforedit($params,$id);
					if($checkstatusforedit==1){
						$this->city_model->edit($params,$id);
						$this->session->set_flashdata('success_msg', 'City updated successfully.');
						redirect('city');
				     }else{
				     	
				     	$this->session->set_flashdata('error_msg', 'City already exist in that Region');
				     }
				}
			}
				$this->template->load('template', 'contents' , 'edit_city',$data);
			
		}else{
			redirect('unauthroize');
		}
	}
	/*
	 * Delete The region - Vignesh -06062018
	 */
	public function remove($id){
		$data = array();
		$data['city_details']=$this->city_model->get_city_details($id);
		if($data['city_details']['city_id']){
			$this->city_model->remove_city($id);
			$this->session->set_flashdata('success_msg', 'The City has been deleted successfully.');
			redirect('city');
		}else{
			redirect('unauthorize');
		}
	}
	
}
