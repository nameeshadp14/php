<?php
class City_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	/*
	 * Get the total city count
	 */
	function get_all_city_count($filter_data=null)
	{
		if(count($filter_data)>0){
			$this->db->like('c.city_name',$filter_data['city'],'both');
			$this->db->like('r.region_id',$filter_data['region']);
		}
		$this->db->where('c.status !=',-1);
		$this->db->select('*');
		$this->db->join('rmn_region_master as r','r.region_id=c.reg_id','LEFT');
		$this->db->from('rmn_city_master as c');
		return $this->db->count_all_results();
	}
	/*
	 * Get the city details based on ID
	 */
	public function get_city_details($id)
	{
		$this->db->where('city_id',$id);
		$this->db->where('status !=',-1);
		return $this->db->get('rmn_city_master as c')->row_array();
	}
	/*
	 * Get all pmo_status_master
	 */
	function get_all_city($filter_data=null,$params = array())
	{
	
		$this->db->order_by('c.city_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		if(count($filter_data)>0){
			$this->db->like('c.city_name',$filter_data['city'],'both');
			$this->db->like('r.region_id',$filter_data['region']);
		}
		$this->db->where('c.status !=',-1);
		$this->db->select('*');
		$this->db->join('rmn_region_master as r','r.region_id=c.reg_id','LEFT');
		return $this->db->get('rmn_city_master as c')->result_array();
	}
	/*
	 * Add a new city
	 */
	public function add($params){
		$this->db->insert('rmn_city_master',$params);
		return true;
	}
	/*
	 * Edit the city details
	 */
	public function edit($params,$id){
		$this->db->where('city_id',$id);
		$this->db->update('rmn_city_master',$params);
		return true;
	}
	
	/*
	 * Remove the city
	 */
	public function remove_city($id){
			$this->db->where('city_id',$id);
			$params=array('status'=> -1);
			$this->db->update('rmn_city_master',$params);
			return 1;
	}
	
}
