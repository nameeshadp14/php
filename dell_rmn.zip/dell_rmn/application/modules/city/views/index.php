 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">List of City
				 <a href="<?php echo base_URL('city/add');?>" class="btn btn-success btn-xs pull-right">Add City</a>
		</h2>
		<div class="row">
		    <form action="<?php echo base_url('city');?>" method="get">
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="city" title="" value="<?php echo $this->input->get('city');?>" placeholder="Filter by City" data-original-title="Filter by city">
		        </div>
		         <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="region" id="region" class="form-control">
                    	<option value="">-- Select Region --</option>
                    	<?php foreach($list_of_region as $region) :?>
                    		<option value="<?php echo $region['region_id']?>" <?php echo $this->input->get('region')==$region['region_id'] ?'selected=selected':'';?>><?php echo $region['region_name']?></option>
                   		 <?php endforeach;?>
                    </select>
		        </div>
		        <div class="form-group col-xs-4">
		            <input type="submit" name="search_btn" class="btn btn-primary" value="Search">
		            <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('city')?>'" value="Reset">
		        </div>
		    </form>
		</div>
		
		<?php if(count($list_of_city)== 0) { ?>
			<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		<?php }else{ ?>
		<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
			   <div class="box-body">
                <table id="master_datatables" class="table table-striped"  >
               	 <thead>
                    <tr>
						<th>S.No</th>
						<th>City Name</th>
						<th>Region</th>
						<th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                    $inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
                     foreach($list_of_city as $city){ ?>
                    <tr>
						<td><?php echo $inc++; ?></td>
						<td><?php echo $city['city_name']; ?></td>
						<td><?php echo $city['region_name']; ?></td>
						<td>
                            <a href="<?php echo site_url('city/edit/'.$city['city_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('city/remove/'.$city['city_id']); ?>" class="btn btn-danger remove_data btn-xs"><span class="fa fa-trash"></span> Delete</a> 
                        </td>
                    </tr>
                    <?php 
                     } ?>
                    </tbody>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
		</div>
		<?php } ?>
	</div>
</div>





