<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Scheduler extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin || $this->isEditor ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('scheduler_model');
		$this->load->model('region/region_model');
		$this->load->model('store/store_model');
		$this->load->model('group/group_model');
		$this->load->model('playlist/playlist_model');
	}
	/*
	 * List the of schduler  with filter
	 */
	public function index(){
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "scheduler/index";
		$total_row = $this->scheduler_model->get_all_scheduler_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$this->pagination->initialize($config);
		$params['offset'] = $page;
		$data["schedule_list"] = $this->scheduler_model->get_all_scheduler($filter_data,$params);
		$data["region_list"] = $this->region_model->get_all_regions();
		$data["store_list"] = $this->store_model->get_all_stores();
		$data["group_list"] = $this->group_model->get_all_groups();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Scheduler');
		$this->template->set('page_breadcrumb', 'List of Scheduler');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	/*
	 * Add a new scheduler 
	 */
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add -Scheduler	');
		$this->template->set('page_breadcrumb', 'Add - Scheduler');
		$data["region_list"] = $this->region_model->get_all_regions();
		$data["store_list"] = $this->store_model->get_all_stores();
		$data["group_list"] = $this->group_model->get_all_groups();
		$data["play_lists"] = $this->playlist_model->get_all_playlist();
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('sch_name', 'Sched Name', 'trim|required|max_length[50]');
			if($this->input->post('group_id')=='' && $this->input->post('region_id')==''){
				$this->form_validation->set_rules('store_id','Store Id','trim|required');
			}else if($this->input->post('region_id')==''&& $this->input->post('store_id')==''){
				$this->form_validation->set_rules('group_id','Group Id','trim|required');
			}else if($this->input->post('store_id')==''&& $this->input->post('group_id')==''){
				$this->form_validation->set_rules('region_id','Region Id','trim|required');
			}
			$this->form_validation->set_rules('sch_status','Sch Status','trim|required');
			$this->form_validation->set_rules('playlist_id', 'Playlist', 'callback_playlist_check');
			if($this->form_validation->run()){
				$st_date=null;$ed_date=null;
				if( $this->input->post('st_date') !=''){
					$st_date=date('Y-m-d H:i:s',strtotime( convertdb_date_format($this->input->post('st_date'))));
				}
				if( $this->input->post('ed_date') !=''){
					$ed_date=date('Y-m-d H:i:s',strtotime(convertdb_date_format($this->input->post('ed_date'))));
				}
				$params = array(
						'sch_status'=>$this->input->post('sch_status'),
						'sch_name' => $this->input->post('sch_name'),
						'st_date' =>$st_date,
						'ed_date' => $ed_date,
						'is_prority' => $this->input->post('is_prority'),
						'wk_monday' => $this->input->post('wk_monday'),
						'wk_tuesday' => $this->input->post('wk_tuesday'),
						'wk_wednesday' => $this->input->post('wk_wednesday'),
						'wk_thursday' => $this->input->post('wk_thursday'),
						'wk_friday' => $this->input->post('wk_friday'),
						'wk_saturday' => $this->input->post('wk_saturday'),
						'wk_sunday' => $this->input->post('wk_sunday'),
						'created_date' => date("Y-m-d H:i:s"),
						'is_sync_client'=>'0',
						'created_by' => $this->isUserID,
						'updated_by' => $this->isUserID,
						'updated_date' =>date("Y-m-d H:i:s"),
				);
			    $params['store_id']=$this->input->post('store_id')!=''?$this->input->post('store_id'):NULL;
			    $params['group_id']=$this->input->post('group_id')!=''?$this->input->post('group_id'):NULL;
			    $params['region_id']=$this->input->post('region_id')!=''?$this->input->post('region_id'):NULL;
			    $scheduler=$this->scheduler_model->checkduplicateschedulerforadd($this->input->post('sch_name'),$params['region_id'],$params['store_id'],$params['group_id']);
				if($scheduler==1){
					$this->scheduler_model->add($params,$this->input->post('playlist_id'));
					$this->session->set_flashdata('success_msg', 'New scheduler added successfully.');
					redirect('scheduler');
			   }else{
				
					$this->session->set_flashdata('error_msg', 'Schdeuler name already map with Region name,Store name and group name. ');
					redirect('scheduler/add');
				}
		    }
	   }
	$this->template->load('template', 'contents' , 'add_scheduler',$data);
}
	/*
	 * Edit the Scheduler
	 */
	public function edit($id){
		$data = array();
		$data['sch_info']=$this->scheduler_model->get_scheduler_details($id);
		if($data['sch_info']['sch_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit -Scheduler	');
			$this->template->set('page_breadcrumb', 'Edit - Scheduler');
			$data["region_list"] = $this->region_model->get_all_regions();
			$data["store_list"] = $this->store_model->get_all_stores();
			$data["group_list"] = $this->group_model->get_all_groups();
			$data["play_lists"] = $this->playlist_model->get_all_playlist();
			$data['schedule_playlist']=$this->scheduler_model->get_schedule_playlist($id);
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('sch_name', 'Sched Name', 'trim|required|max_length[50]');
				if($this->input->post('group_id')=='' && $this->input->post('region_id')==''){
					$this->form_validation->set_rules('store_id','Store Id','trim|required');
				}else if($this->input->post('region_id')==''&& $this->input->post('store_id')==''){
					$this->form_validation->set_rules('group_id','Group Id','trim|required');
				}else if($this->input->post('store_id')==''&& $this->input->post('group_id')==''){
					$this->form_validation->set_rules('region_id','Region Id','trim|required');
				}
				$this->form_validation->set_rules('sch_status','Sch Status','trim|required');
				$this->form_validation->set_rules('playlist_id', 'Playlist', 'callback_playlist_check');
				$st_date=null;$ed_date=null;
				if( $this->input->post('st_date') !=''){
					$st_date=date('Y-m-d H:i:s',strtotime( convertdb_date_format($this->input->post('st_date'))));
				}
				if($this->input->post('ed_date') !=''){
					$ed_date=date('Y-m-d H:i:s',strtotime(convertdb_date_format($this->input->post('ed_date'))));
				}
				if($this->form_validation->run()){
					$params = array(
						'sch_status'=>$this->input->post('sch_status'),
						'sch_name' => $this->input->post('sch_name'),
						'st_date' =>$st_date,
						'ed_date' =>$ed_date,
						'is_prority' => $this->input->post('is_prority'),
						'wk_monday' => $this->input->post('wk_monday'),
						'wk_tuesday' => $this->input->post('wk_tuesday'),
						'wk_wednesday' => $this->input->post('wk_wednesday'),
						'wk_thursday' => $this->input->post('wk_thursday'),
						'wk_friday' => $this->input->post('wk_friday'),
						'wk_saturday' => $this->input->post('wk_saturday'),
						'wk_sunday' => $this->input->post('wk_sunday'),
						'updated_by' => $this->isUserID,
						'is_sync_client'=>'0',
						'updated_date' =>date("Y-m-d H:i:s"),
					  );
				 	$params['store_id']=$this->input->post('sch_type')=='2'?$this->input->post('store_id'):NULL;
					$params['group_id']=$this->input->post('sch_type')=='3'?$this->input->post('group_id'):NULL;
					$params['region_id']=$this->input->post('sch_type')=='1'?$this->input->post('region_id'):NULL; 
					$scheduler=$this->scheduler_model->checkduplicateschedulerforedit($this->input->post('sch_name'),$params['region_id'],$params['store_id'],$params['group_id'],$id);
						
		 			/* if($this->input->post('sch_type')=='3'){
						$params['store_id']=null;
						$params['region_id']=null;
							
					}
					else if($this->input->post('sch_type')=='1'){
						$params['store_id']=null;
						$params['group_id']=null;
							
					}
					else if($this->input->post('sch_type')=='2'){
						$params['group_id']=null;
						$params['region_id']=null;
							
					} 
					 */
					
					$scheduler=$this->scheduler_model->checkduplicateschedulerforedit($this->input->post('sch_name'),$params['region_id'],$params['store_id'],$params['group_id'],$id);
					if($scheduler==1){
						$this->scheduler_model->edit_scheduler($params,$id);
						$this->scheduler_model->edit_scheduler_playlist($this->input->post('playlist_id'),$id);
						$this->session->set_flashdata('success_msg', 'Scheduler details updated successfully.');
						redirect('scheduler');
					}else{
						$this->session->set_flashdata('error_msg', 'Schdeuler name already map with Region name,Brand name and group name.');
						redirect('scheduler/edit/'.$id);
					}
			    }
				
			}
			$this->template->load('template', 'contents' , 'edit_scheduler',$data);
	}else{
		redirect('unauthorize');
	}
}
	
	/*
	 * Check the Playlist value is there are not
	 */
	public function playlist_check(){
		if(empty($this->input->post('playlist_id'))){
			$this->form_validation->set_message('playlist_id', 'Invalid Playlist selection');
			return false;
		}else{
			return true;
		}
	}
	
	/*
	 * Delete The Scheduler - Vignesh -08062018
	 */
	public function remove($id){
		$data = array();
		$data['sch_info']=$this->scheduler_model->get_scheduler_details($id);
		if($data['sch_info']['sch_id']){
			if($this->scheduler_model->remove_scheduler($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Scheduler has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Scheduler has been used in the application.');
			}
			redirect('scheduler');
		}else{
			redirect('unauthorize');
		}
	}
}
