<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Scheduler_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	/*
	 * Get all Scheduler count
	 */
	function get_all_scheduler_count($filter_data=null)
	{
		if(count($filter_data)>0){
			$this->db->like('s1.sch_name',$filter_data['sch_name'],'both');
			if($filter_data['region_id']!=null){
				$this->db->like('r.region_id',$filter_data['region_id']);
			}if($filter_data['store_id']!=null){
				$this->db->like('s.store_id',$filter_data['store_id']);
			}if($filter_data['group_id']!=null){
				$this->db->like('g.group_id',$filter_data['group_id']);
			}
			$this->db->like('s1.sch_status',$filter_data['sch_status']);
		}
		$this->db->where('s1.sch_status !=',-1);
		$this->db->select('s1.*,g.group_name,s.store_name,r.region_name');
		$this->db->join('rmn_group_master as g','g.group_id=s1.group_id','left');
		$this->db->join('rmn_store_master as s','s.store_id=s1.store_id','left');
		$this->db->join('rmn_region_master as r','r.region_id=s1.region_id','left');
		$this->db->from('rmn_scheduler as s1');
		return $this->db->count_all_results();
	}
		
	/*
	 * Check for expiry status
	 */	
	public function changestatus(){
		$data=array('sch_status'=>2);
		$cur_date=date("Y-m-d");
		$this->db->select('sch_id,ed_date');
		$this->db->where('ed_date <',$cur_date);
		$this->db->where('sch_status!=',-1);
		return $this->db->update('rmn_scheduler',$data);
	}
	
	/*
	 * Get all Scheduler details
	 */
	function get_all_scheduler($filter_data=array(),$params=null)
	{   
		$this->changestatus();
		$this->db->order_by('s1.sch_name', 'ASC');
		if(count($filter_data)>0){
			$this->db->like('s1.sch_name',$filter_data['sch_name'],'both');
			if($filter_data['region_id']!=null){
				$this->db->like('r.region_id',$filter_data['region_id']);
			}if($filter_data['store_id']!=null){
				$this->db->like('s.store_id',$filter_data['store_id']);
			}if($filter_data['group_id']!=null){
				$this->db->like('g.group_id',$filter_data['group_id']);
			}
			$this->db->like('s1.sch_status',$filter_data['sch_status']);
		}
		$this->db->where('s1.sch_status !=',-1);
		if($this->regionID!=''){
			$this->db->where('s1.region_id',$this->regionID);
		}
		$this->db->select('s1.*,g.group_name,s.store_name,r.region_name');
		$this->db->join('rmn_group_master as g','g.group_id=s1.group_id','left');
		$this->db->join('rmn_store_master as s','s.store_id=s1.store_id','left');
		$this->db->join('rmn_region_master as r','r.region_id=s1.region_id','left');
		
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		
		return $this->db->get('rmn_scheduler s1')->result_array();
		 

	}
	/*
	 * Add New Scheduler
	 */	
	public function add($param,$playlist_id){
		$this->db->insert('rmn_scheduler',$param);
		$this->db->select('max(sch_id) as sch_id');
		$this->db->from('rmn_scheduler');
		$query=$this->db->get()->row_array();
		$scheduler_id=$query['sch_id'];
		foreach ($playlist_id as $playlist){
			$param1= array(
					'sch_id'=>$scheduler_id,
					'playlist_id'=>$playlist['$playlist_id'],
			);
			$this->db->insert('rmn_scheduler_playlist_mapping',$param1);
		}
		return true;
	}
	
	/*
	 * Get the Scheduler details by id
	 */
	public function  get_scheduler_details($id){
		$this->db->where('sch_id',$id);
		$this->db->where('sch_status!=',-1);
		$this->db->select('*');
		return $this->db->get('rmn_scheduler')->row_array();
	}
	/*
	 * Get the Scheduler Playlist by id
	 */
	public function  get_schedule_playlist($id){
		$this->db->where('sch_id',$id);
		$this->db->select('*');
		return $this->db->get('rmn_scheduler_playlist_mapping ')->result_array();
	}
	/*
	/*
	 * Update the Scheduler based on ID
	 */
	public function edit_scheduler($param,$id){
		$this->db->where('sch_id',$id);
		return $this->db->update('rmn_scheduler',$param);
	}
	/*
	 * map the Scheduler and model
	 */
	public function edit_scheduler_playlist($scheduler_list,$id){
		$this->db->where('sch_id',$id);
		$this->db->delete('rmn_scheduler_playlist_mapping');
		if(count($scheduler_list)>0){
			foreach ($scheduler_list as $model){
				$param = array(
						'playlist_id' =>$model['video_list'],
						'sch_id' =>$id,
				);
				$this->db->insert('rmn_scheduler_playlist_mapping',$param);
			}
		}
		return true;
	}
	/*
	 * Remove the Scheduler
	 */
	public function remove_scheduler($id){
			$this->db->where('sch_id',$id);
			$param=array('sch_status'=> -1,'updated_by' => $this->isUserID,'updated_date' => date("Y-m-d H:i:s"));
			$this->db->update('rmn_scheduler',$param);
			return 1;
	}

	/*
	 * Check Group relation table exist or not
	 */
	public function checkschedulerstatus($id){
		$this->db->select("COUNT(`spm`.`sch_id`) AS scheduler");
		$this->db->where('s1.sch_id',$id);
		$this->db->group_by('s1.sch_id');
		$this->db->join('rmn_scheduler_playlist_mapping as spm','spm.sch_id=s1.sch_id','left');
		$this->db->from('rmn_scheduler s1');
		$query=$this->db->get()->row_array();
		if($query['scheduler'] ==0 ){
			return 1;
		}else{
			return -1;
		}
	}
	
	public function checkduplicateschedulerforadd($scheduler_name,$region_name,$store_name,$group_name){
		$this->db->select('*');
		$this->db->where('sch_name',$scheduler_name);
		$this->db->where('region_id',$region_name);
		$this->db->where('sch_status!=',-1);
		$this->db->where('store_id',$store_name);
		$this->db->where('group_id',$group_name);
		$scheduler=$this->db->get('rmn_scheduler')->result_array();
		if (count($scheduler)>0){
			return -1;
		}else{
			return 1;
		}
	}
	public function checkduplicateschedulerforedit($scheduler_name,$region_name,$store_name,$group_name,$id){
		$this->db->select('*');
		$this->db->where('sch_name',$scheduler_name);
		$this->db->where('sch_id !=',$id);
		$this->db->where('sch_status!=',-1);
		$this->db->where('region_id',$region_name);
		$this->db->where('store_id',$store_name);
		$this->db->where('group_id',$group_name);
		$scheduler=$this->db->get('rmn_scheduler')->result_array();
		if(count($scheduler)<1){
			return 1;
		}else{
			return -1;
		}
	}
	
}

 ?>