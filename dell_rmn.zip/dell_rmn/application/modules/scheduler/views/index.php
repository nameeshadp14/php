 <div class="col-md-12 p_left p_right">
	<div class="bg_white table-responsive strip_table p_bottom">
		<h2 class="cmn_tit_main">List of Scheduler
			<a href="<?php echo base_URL('scheduler/add');?>" class="btn btn-success btn-xs pull-right">Add Scheduler</a>
		</h2>
		<div class="row">
		    <form action="<?php echo base_url('scheduler');?>" method="get">
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <input data-toggle="tooltip" class="form-control" type="text" name="sch_name" title="" value="<?php echo $this->input->get("sch_name");?>" placeholder="Filter by Scheduler Name">
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="region_id" id="region_id" class="form-control">
                    	<option value="">--Select Region--</option>
                    	<?php foreach($region_list as $region) :?>
                    				<option value="<?php echo $region['region_id']?>" <?php echo $this->input->get('region_id')==$region['region_id'] ?'selected=selected':'';?>><?php echo $region['region_name']?></option>
                   		<?php endforeach;?>
                     </select>
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		             <select name="store_id" id="store_id" class="form-control">
                    	<option value="">--Select Store--</option>
                    	 	<?php foreach($store_list as $store) :?>
	                                <option value="<?php echo $store['store_id'];?>" <?php echo $this->input->get('store_id')==$store['store_id'] ?'selected=selected':'';?>> <?php echo $store['store_name'];?> </option>
	                          <?php endforeach;?>
                     </select>
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <select name="group_id" id="group_id" class="form-control">
                    	<option value="">--Select Group--</option>
                    	<?php foreach($group_list as $group) :?>
                      			<option value="<?php echo $group['group_id']?>" <?php echo $this->input->get('group_id')==$group['group_id'] ?'selected=selected':'';?>><?php echo $group['group_name']?></option>
                   		 <?php endforeach;?>
                    </select>
		        </div>
		        <div class="form-group col-xs-4 ">
		            <label for="email" class="sr-only"></label>
		            <select name="sch_status" id="sch_status" class="form-control">
                        	<option value="">--Select Status--</option>
                    	    <?php 
                    		  $status=$this->input->get('sch_status');
                         	?>
                    		<option value="1"  <?php  if(isset($status)){ echo $status== '1' ? 'selected=selected':''; } ?>>Active</option>
                    		<option value="2"  <?php  if(isset($status)){ echo $status== '2' ? 'selected=selected':''; } ?>>Expired</option>
                    		<option value="0" <?php  if(isset($status)){ echo $status== '0' ? 'selected=selected':''; } ?>>Inactive</option>
                    </select>
		        </div>
		        <div class="form-group col-xs-4">
		            <input type="submit" name="search_btn" class="btn btn-primary" value="Search">
		            <input type="button" name="save_btn" class="btn btn-primary" onclick="window.location.href = '<?php echo base_url('scheduler')?>'" value="Reset">
		        </div>
		    </form>
		</div>
		<?php if(count($schedule_list)== 0) { ?>
			<div class="no_result_div">
				<h3 class="text-center">No result found</h3>
			</div>
		<?php }else{ ?>
					<div class="bg_white cmn_table table-responsive strip_table p_bottom p_left p_right no_shadow">
						   <div class="box-body">
			                <table id="master_datatables" class="table table-striped"  >
				               	 <thead>
				                    <tr>
										<th>S.No</th>
										<th>Scheduler Name</th>
										<th>Region Name</th>
										<th>Store Name</th>
										<th>Group Name</th>
										<th>Start Date</th>
										<th>End Date</th>
										<th>Scheduler Status</th>
										<th>Actions</th>
				                    </tr>
				                 </thead>
				                 <tbody>
				          			 	<?php
				                     	$cur_page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				                    	$inc = ($cur_page == 0 ? 1 : (($cur_page - 1) * RECORDS_PER_PAGE + 1));
				                     	foreach($schedule_list as $scheduler){ ?>
				                    	<tr>
											<td><?php echo $inc++; ?></td>
											<td><?php echo $scheduler['sch_name']; ?></td>
											<td><?php echo $scheduler['region_name']; ?></td>
											<td><?php echo $scheduler['store_name']; ?></td>
											<td><?php echo $scheduler['group_name']; ?></td>
											<td><?php echo date('d-m-y',strtotime($scheduler['st_date'])); ?></td>
											<td><?php echo date('d-m-y',strtotime($scheduler['ed_date'])); ?></td>
											<td><?php echo get_asset_status($scheduler['sch_status']); ?></td>
											<td>
					                           	<a href="<?php echo site_url('scheduler/edit/'.$scheduler['sch_id']); ?>" class="btn btn-info btn-xs" id="editschedule"><span class="fa fa-pencil"></span> Edit</a> 
					                        	<a href="<?php echo site_url('scheduler/remove/'.$scheduler['sch_id']); ?>" class="btn btn-danger remove_data btn-xs"><span class="fa fa-trash"></span> Delete</a> 
				                        	</td>
				                   		</tr>
				                    	<?php } ?>
				                  </tbody>
			                </table>
			                <div class="pull-right">
			                    <?php echo $this->pagination->create_links();?>                    
			                </div>                
           				 </div>
					</div>
		<?php } ?>
	</div>
</div>





