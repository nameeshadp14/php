<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fSelect.css');?>">
<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit Scheduler
				<a href="<?php echo base_url('scheduler');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="schedular_management" method="post" action="">
                <div class="col-md-6">
                    <label for="store_name" class="control-label">Scheduler Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="sch_name" value="<?php echo set_value('sch_name',$sch_info['sch_name']); ?>" class="form-control" id="sch_name" />
                        <span class="text-danger"><?php echo form_error('sch_name');?></span>
                    </div>
                </div>
              
                <div class="col-md-6">
					<label for="sch_type" class="control-label">Scheduler Type<span class="text-danger">*</span></label>
					<div class="form-group">
	                    <select name="sch_type" id="sch_typeforedit" class="form-control">
	                    	    <option value="">--Select Type--</option>
	                    		<option value="1" <?php if(!empty($sch_info['region_id'])){ echo 'selected="selected"';} ?> >Region </option>
	                    		<option value="2"  <?php if(!empty($sch_info['store_id'])){ echo 'selected="selected"';} ?> >Store</option>
	                    		<option value="3" <?php if(!empty($sch_info['group_id'])){ echo 'selected="selected"';} ?> >Group</option>
	                    </select>
	                	<span class="text-danger"><?php echo form_error('sch_type');?></span>
	               </div>
			   </div>
				
                <div class="col-md-12" id="region" <?php if(empty($sch_info['region_id'])){ echo 'style="display:none"'; } ?>>
					<label for="region_id" class="control-label">Region Name <span class="text-danger">*</span></label>
					<div class="form-group">
						    <select name="region_id" class="form-control str_reg grp_reg" id="region_id">
	                            <option value="">--Select Region--</option>
	                            <?php foreach($region_list as $region) :?>
	                             <option value="<?php echo $region['region_id']?>" <?php echo $sch_info['region_id']== $region['region_id']?'selected=selected':'';?>> <?php echo $region['region_name']?> </option>
	                            <?php endforeach;?>
	                        </select>
						<span class="text-danger"><?php echo form_error('region_id');?></span>
					</div>
				</div>
			<div class="clearfix"></div>
			<div class="col-md-12" id="store" <?php if(empty($sch_info['store_id'])){ echo  'style="display:none"'; } ?>>
				<label for="store" class="control-label">Store Name <span class="text-danger">*</span></label>
				<div class="form-group">
					<select name="store_id" class="form-control str_reg grp_str" id="store_id">
                            <option value="">--Select Store--</option>
                           	<?php foreach($store_list as $store) :?>
                                <option value="<?php echo $store['store_id']?>" <?php echo $sch_info['store_id']== $store['store_id']?'selected=selected':'';?>> <?php echo $store['store_name']?> </option>
                            <?php endforeach;?>
                    </select>
					<span class="text-danger"><?php echo form_error('store_id');?></span>
				</div>
			</div>
			<div class="col-md-12" id="group" <?php if(empty($sch_info['group_id'])){ echo 'style="display:none"'; }?>>
				<label for="group_id" class="control-label">Group Name<span class="text-danger">*</span></label>
				<div class="form-group">
					<select name="group_id" class="form-control grp_reg grp_str" id="group_id">
                            <option value="">--Select Group--</option>
                            <?php foreach($group_list as $group) :?>
                                <option value="<?php echo $group['group_id']?>" <?php echo $sch_info['group_id']== $group['group_id']?'selected=selected':'';?>> <?php echo $group['group_name']?> </option>
                            <?php endforeach;?>
                    </select>
					<span class="text-danger"><?php echo form_error('group_id');?></span>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
                    <label for="Playlist" class="control-label">Playlist <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <select class="cus_multi_select form-control" multiple="multiple" name="playlist_id[]" id="playlist_id">
					       <?php $playlists=array();
						       foreach ($schedule_playlist as $playlist){
						       		array_push($playlists,$playlist['playlist_id']);
						       }
						       foreach ($play_lists as $play_list) {  ?>
						        <option value="<?php echo $play_list['playlist_id'];?>" <?php if($playlists):echo in_array($play_list['playlist_id'],$playlists) ? 'selected=selected':'';endif;
                             ?>>
                            <?php echo $play_list['playlist_name'];?></option>
				            <?php } ?>
				        </select>
				        <span class="text-danger"><?php echo form_error('playlist_id');?></span>
                    </div>
             </div>
	         <div class="col-md-6">
				<label for="st_date" class="control-label">Start Date <span class="text-danger">*</span></label>
				<div class="form-group">
					<input type="text" name="st_date" onkeydown="return false;" autocomplete="off"  value="<?php echo $sch_info['st_date']!=''? date("d/m/Y",strtotime($sch_info['st_date'])):set_value('st_date'); ?>" class=" form-control" id="st__date" />
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<label for="ed_date" class="control-label">End Date <span class="text-danger">*</span></label>
				<div class="form-group">
                    <input type="text" name="ed_date" onkeydown="return false;" autocomplete="off"  value="<?php echo $sch_info['ed_date']!=''? date("d/m/Y",strtotime($sch_info['ed_date'])):set_value('ed_date'); ?>" class=" form-control" id="ed__date" />
                </div>
			</div>
			<div class="col-md-6 form-group">
                 <label>Status <span class="text-danger">*</span></label>
                    <select name="sch_status" id="sch_status" class="form-control">
                         	<option value="">--Select Status--</option>
                    		<option value="1"  <?php echo $sch_info['sch_status']== 1 ?'selected=selected':'';?>>Active</option>
                    		<option value="2"  <?php echo $sch_info['sch_status']== 2 ?'selected=selected':'';?>>Expired</option>
                    		<option value="0"  <?php echo $sch_info['sch_status']== 0 ?'selected=selected':'';?>>Inactive</option>
                    </select>
                	<span class="text-danger"><?php echo form_error('sch_status');?></span>
            </div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<table class="table table-responsive">
					<tr>
						<td><label for="IS Pririty" class="control-label">IS Pririty</td>
						<td>
							<label class="radio-inline"><input type="radio" name="is_prority" value="1" <?php  if ($sch_info['is_prority']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="is_prority" value="0" <?php  if ($sch_info['is_prority']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Monday" class="control-label">Monday</td>
							<td>
					 		<label class="radio-inline"><input type="radio" name="wk_monday" value="1" <?php  if ($sch_info['wk_monday']=='1'){ echo "checked='checked'";}?>>Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_monday" value="0" <?php  if ($sch_info['wk_monday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Tuesday" class="control-label">Tuesday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_tuesday"  value="1" <?php  if ($sch_info['wk_tuesday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_tuesday" value="0" <?php  if ($sch_info['wk_tuesday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>	
					</tr>
					<tr>
						<td><label for="Wednesday" class="control-label">Wednesday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_wednesday" value="1" <?php  if ($sch_info['wk_wednesday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_wednesday" value="0" <?php  if ($sch_info['wk_wednesday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Thursday" class="control-label">Thursday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_thursday" value="1" <?php  if ($sch_info['wk_thursday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_thursday" value="0" <?php  if ($sch_info['wk_thursday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Friday" class="control-label">Friday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_friday" value="1" <?php  if ($sch_info['wk_friday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_friday" value="0" <?php  if ($sch_info['wk_friday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Saturday" class="control-label">Saturday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_saturday" value="1" <?php  if ($sch_info['wk_saturday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_saturday" value="0" <?php  if ($sch_info['wk_saturday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
					<tr>
						<td><label for="Sunday" class="control-label">Sunday</td>
						<td>
							<label class="radio-inline"><input type="radio" name="wk_sunday" value="1" <?php  if ($sch_info['wk_sunday']=='1'){ echo "checked='checked'";}?>>Yes</label>
							<label class="radio-inline"><input type="radio" name="wk_sunday" value="0" <?php  if ($sch_info['wk_sunday']=='0'){ echo "checked='checked'";}?>>No</label>
						</td>
					</tr>
			  </table>	
		   </div>			
       </div>
       <div class="clearfix"></div>
        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
	            <input type="hidden" id="reg_id_hdn" name="reg_id_hdn" value="<?php echo $sch_info['region_id']?>" />
	            <input type="hidden" id="grp_id_hdn" name="grp_id_hdn" value="<?php echo $sch_info['group_id']?>" />
	            <input type="hidden" id="brnd_id_hdn" name="brnd_id_hdn" value="<?php echo $sch_info['store_id']?>" />
            	<input type="submit" name="save_add" id="save_add_btn"  class="btn btn-primary video_btn_type" value="SAVE">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
            </div>
        </div>
    </form>
  </div>
</div>
<script type='text/javascript' src="<?php echo base_url('assets/js/fSelect.js');?>"></script>
<script>
(function($) {
    $(function() {
        $('.cus_multi_select').fSelect();
    });
})(jQuery);
</script>