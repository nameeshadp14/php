<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fSelect.css');?>">
<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add Scheduler
		<a href="<?php echo base_url('scheduler');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="schedular_management" method="post" action="">
                <div class="col-md-6 form-group">
                    <label for="store_name" class="control-label">Scheduler Name <span class="text-danger">*</span></label>
                    <div class="">
                        <input type="text" name="sch_name" value="<?php echo $this->input->post('sch_name'); ?>" class="form-control" id="sch_name" placeholder="Enter  the scheduler Name"/>
                        <span class="text-danger"><?php echo form_error('sch_name');?></span>
                    </div>
                </div>
                <div class="col-md-6 form-group">
					<label for="sch_type" class="control-label">Scheduler Type<span class="text-danger">*</span></label>
					<div class="">
	                    <select name="sch_type" id="sch_type" class="form-control">
	                    	<option value="">--Select Type--</option>
	                    		<option value="1">Region </option>
	                    		<option value="2">Store</option>
	                    		<option value="3">Group</option>
	                    </select>
	                	<span class="text-danger"><?php echo form_error('sch_type');?></span>
	                </div>
				</div>
				<div class="clearfix"></div>
                 <div class="col-md-12 form-group" id="region" style="display:none">
					<label for="Region_id" class="control-label">Region Name <span class="text-danger">*</span></label>
					<div class="">
						<select name="region_id" id="region_id"class="form-control">
							<option value="" selected="selected">--Select Region--</option>
							  <?php foreach($region_list as $region) :?>
	                                <option value="<?php echo $region['region_id'];?>"> <?php echo $region['region_name'];?> </option>
	                          <?php endforeach;?>
						</select>
						<span class="text-danger"><?php echo form_error('region_id');?></span>
					</div>
				</div>
				<div class="clearfix"></div>
                <div class="col-md-12 form-group" id="store" style="display:none">
					<label for="store_id" class="control-label">Store Name <span class="text-danger">*</span></label>
					<div class="">
						<select name="store_id" id="brand_id" class="form-control">
							<option value="" selected="selected">--Select Store--</option>
							  <?php foreach($store_list as $store) :?>
	                                <option value="<?php echo $store['store_id'];?>"> <?php echo $store['store_name'];?> </option>
	                          <?php endforeach;?>
						</select>
						<span class="text-danger"><?php echo form_error('brand_id');?></span>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-12 form-group" id="group" style="display:none"	>
					<label for="Group_id" class="control-label">Group Name<span class="text-danger">*</span></label>
					<div class="">
						<select name="group_id" id="group_id"class="form-control">
							<option value="" selected="selected">--Select Group--</option>
							  <?php foreach($group_list as $group) :?>
	                                <option value="<?php echo $group['group_id'];?>"> <?php echo $group['group_name'];?> </option>
	                          <?php endforeach;?>
						</select>
						<span class="text-danger"><?php echo form_error('group_id');?></span>
					</div>
				</div>
				<div class="col-md-6 form-group">
					<label for="plalist" class="control-label">Playlist<span class="text-danger">*</span></label>
					<div class="for-group">
						 <select class="cus_multi_select form-control" multiple="multiple" name="playlist_id[]" id="playlist_id"  >
					        <?php foreach ($play_lists as $play_list) {  ?>
					        <option value="<?php echo $play_list['playlist_id'];?>" <?php 	if($this->input->post('playlist_id')):echo in_array($play_list['playlist_id'],$this->input->post('playlist_id')) ? 'selected=selected':'';endif;
                   		 	?>><?php echo $play_list['playlist_name'];?></option>
					        <?php } ?>
					    </select>
					    <span class="text-danger"><?php echo form_error('playlist_id');?></span>
					</div>
					<span id="error_msg" ></span>
				</div>
	            <div class="col-md-6 form-group">
					<label for="st_date" class="control-label">Start Date <span class="text-danger">*</span></label>
					<div class="">
						<input type="text" name="st_date" onkeydown="return false;" autocomplete="off" value="<?php echo $this->input->post('st_date'); ?>" class="form-control" id="st__date" />
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-6 form-group">
					<label for="ed_date" class="control-label">End Date <span class="text-danger">*</span></label>
					<div class="">
						<input type="text" name="ed_date" onkeydown="return false;" autocomplete="off" value="<?php echo $this->input->post('ed_date'); ?>" class=" form-control" id="ed__date" />
					</div>
				</div>
				<div class="col-md-6 form-group">
					<label for="sch_status" class="control-label">Scheduler Status<span class="text-danger">*</span></label>
					<div class="">
	                    <select name="sch_status" id="sch_status" class="form-control">
	                    	    <option value="">--Select Status--</option>
	                    		<option value="1">Active</option>
	                    		<option value="2">Expired</option>
	                    		<option value="0">Inactive</option>
	                    </select>
	                	<span class="text-danger"><?php echo form_error('sch_status');?></span>
	               </div>
			    </div>
			    <div class="clearfix"></div>
				<div class="col-md-6">
					<table class="table table-responsive">
						<tr>
							<td><label for="is-priority" class="control-label">IS Priority</td>
							<td>
								<label class="radio-inline"><input type="radio" name="is_prority" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="is_prority" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="monday" class="control-label">Monday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_monday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_monday" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="tuesday" class="control-label">Tuesday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_tuesday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_tuesday" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="wednesday" class="control-label">Wednesday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_wednesday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_wednesday" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="thursday" class="control-label">Thursday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_thursday" checked="checked" value="1">Yes</label>
						<label class="radio-inline"><input type="radio" name="wk_thursday" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="friday" class="control-label">Friday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_friday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_friday" value="0">No</label>
							</td>
						</tr>
						
						<tr>
							<td><label for="saturday" class="control-label">Saturday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_saturday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_saturday" value="0">No</label>
							</td>
						</tr>
						<tr>
							<td><label for="sunday" class="control-label">Sunday</td>
							<td>
								<label class="radio-inline"><input type="radio" name="wk_sunday" checked="checked" value="1">Yes</label>
								<label class="radio-inline"><input type="radio" name="wk_sunday" value="0">No</label>
							</td>
						</tr>
						
				   </table>	
				</div>			
         </div>
        <div class="clearfix"></div>
        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
            	<input type="submit" name="save_add" id="save_add_btn"  class="btn btn-primary video_btn_type" value="SAVE">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
            </div>
        </div>
    </form>
  </div>
</div>
<script type='text/javascript' src="<?php echo base_url('assets/js/fSelect.js');?>"></script>
<script>
(function($) {
    $(function() {
        $('.cus_multi_select').fSelect();
    });
})(jQuery);
</script>