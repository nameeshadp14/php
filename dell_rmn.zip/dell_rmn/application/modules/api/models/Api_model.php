<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_model extends CI_model
{
    
    public function __construct()
    {
        parent::__construct();
    }
    //============ Asset registration============    
    public function getasset_info($store_code, $service_tag,$model_name)
    {
        $this->db->select('*');
        $this->db->where('r.store_code', $store_code);
        $this->db->where('r.service_tag', $service_tag);
        $result = $this->db->get('rmn_raw_asset_master as r')->row();
        if(count($result) == 0) {
        	$check_insert_raw_master=$this->insert_raw_master($store_code,$service_tag);
        	if($check_insert_raw_master == -1){
        		$result_array = array(
        				'msg' => 'Invalid asset_store_id/asset_id'
        		);
        		return $result_array;
        	}
        }
        // ENABLE THE SECOND LEVEL CHECK
        $check_unique_storecode=$this->unique_storecode($store_code);
        if($check_unique_storecode == -1){
        	$result_array = array(
        			'msg' => 'Invalid asset_store_id/asset_id'
        	);
        	return $result_array;
        }else{
			$ustore_id=$this->get_storeid($store_code);
        	$this->db->select('asset_code,asset_sessionguid');
        	$this->db->where('asset_service_tag',$service_tag);
        	$this->db->where('asset_store_id',$ustore_id);
        	$check_asset_status =$this->db->get('rmn_asset_master')->row_array();
        	if(count($check_asset_status)>0){
        		$sessionguid=$check_asset_status['asset_sessionguid'];
        		$asset_id=$check_asset_status['asset_code'];
        	}else{
				$reg_date=date("Y-m-d H:i:s");
        		$asset_id=$check_unique_storecode.".".$this->unique_assetid($ustore_id);
        		$sessionguid=random_string('sha1', 20);
        		$params = array(
        				'asset_status' => 1,
        				'model_id' => $this->check_create_model($model_name),
        				'asset_store_id' =>$ustore_id,
        				'asset_code' => $asset_id,
        				'asset_service_tag' =>$service_tag,
        				'asset_reg_date' => $reg_date,
        				'asset_sessionguid'=>$sessionguid,
        				'raw_asset_id'=>$asset_id,
        				'asset_expiry_date' =>date('Y-m-d H:i:s', strtotime($this->config->item("lockin_duration"), strtotime($reg_date))),
        				'created_by' => 1,
        				'created_date' => date("Y-m-d H:i:s"),
        				'updated_by' => 1,
        				'updated_date' => date("Y-m-d H:i:s"),
        		);
        		$this->db->insert('rmn_asset_master',$params);
       		}
        }
        $result_array = array(
        		'msg' => 'success',
        		'assetid' => $asset_id,
        		'sessionguid' => $sessionguid
        );
        return $result_array;
    }
    

    //Insert the data into insert_raw_master
   	public function insert_raw_master($store_code,$service_tag){
   		$this->db->where('service_tag', $service_tag);
   		$store_info = $this->db->get('rmn_raw_asset_master')->result_array();
   		if(count($store_info) == 0){
	    	$params = array(
	    			'store_code' => $store_code,
	    			'service_tag'=>$service_tag,
	    			'record_flag' => 1
	    	);
	    	$this->db->insert('rmn_raw_asset_master',$params);
	    	return 1;
   		}else{
   			return -1;
   		}
    }
    //Generate the store unique code
    public function unique_storecode($store_code){
    	$url = 'http://dev.desconnect.co.in/api/get-store-detail';
    	$data = array("store_id" => $store_code,"api_key" => "hkfhsldfewrlsdjlfkjlk566787ljhjhsd234" );
    	$data_string = json_encode($data);
    	$ch = curl_init($url);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	$result = curl_exec($ch);
    	curl_close($ch);
    	$result=json_decode($result,true);
	
    	if($result['success_code'] == 1){
    		$city=strtoupper(substr($result['data']['city'],0,2));
    		$state=strtoupper(substr($result['data']['state'],0,2));
    		$region=strtoupper(substr($result['data']['region'],0,2));
    		$country=strtoupper(substr($result['data']['country'],0,2));
    		$store_name=$result['data']['store_name'];
    		$store_address=$result['data']['address'];
    		$store_contactname=$result['data']['contact_person_name'];
    		$store_contactnum=$result['data']['store_contact_person_number'];
    		$store_email=$result['data']['store_email'];
    		$conact_email=$result['data']['store_contact_number'];
    		
    		$temp_store_code=$country.$region.$state.$city.$this->createAssetData(8);
    	}else{
			if( $store_code != '12345'){
				return -1;
			}
    	}
    	$this->db->where('store_code', $store_code);
    	$store_info = $this->db->get('rmn_store_master')->result_array();
    	if(count($store_info) == 0){
    		if( $this->config->item('second_level_check') == TRUE){
    			$params = array(
					'region_id' => $this->get_regionid($result['data']['region']),
					'store_name' => $store_name,
					'store_code' => $store_code,
					'store_email' => $store_email,
					'store_contact_name' =>$store_contactname,
					'store_contact_email' => $conact_email,
					'store_contact_number' => $store_contactnum,
					'store_type' => 1,
					'created_by' => 1,
					'created_date' => date("Y-m-d H:i:s"),
					'updated_by' =>1,
					'updated_date' =>date("Y-m-d H:i:s"),
					'store_address' => $store_address,
    				'store_unique_code'=>$temp_store_code
	            );
    			$this->db->insert('rmn_store_master',$params);
    		}else{
				return -1;
			}
    	}else{
			foreach($store_info as $store){
				 $store_unique_code=$store['store_unique_code'];
			}
			if($store_unique_code == ''){
				$params = array('store_unique_code' => $temp_store_code);
				$this->db->where('store_code', $store_code);
				$this->db->update('rmn_store_master',$params);
			}else{
				$temp_store_code=$store_unique_code;
			}
		}
    	return $temp_store_code;
    }
    //generate the unique_asset_id
    public function unique_assetid($ustore_id){
    
    	// GET THE COUNT OF ASSET BELONGS TO THE STORE
    	$this->db->select('count(*) as cnt');
    	$this->db->where('asset_store_id',$ustore_id);
    	$check_asset_cnt =$this->db->get('rmn_asset_master')->row_array();
    	$unique_asset_id=100+$check_asset_cnt['cnt'];
    	return $unique_asset_id;
    }
    //get the store code
   	public function get_storeid($store_code){
    	$this->db->where('store_code', $store_code);
    	$result = $this->db->get('rmn_store_master')->row();
   		return $result->store_id;
    }
    
    //get the Region ID
    public function get_regionid($region_name){
    	$this->db->where('region_name', $region_name);
    	$result = $this->db->get('rmn_region_master')->row();
    	return $result->region_id;
    }
    //============ Asset authenticate============    
    function authenticate($session_id, $asset_id)
    {
        $this->db->select('*');
        $this->db->where('asset_code', $asset_id);
        $this->db->where('asset_sessionguid', $session_id);
        $result = $this->db->get('rmn_asset_master')->row();
        if (count($result) > 0) {
            $result_array = array(
                'msg' => 'success',
                'sessionguid' => $result->asset_sessionguid
            );
        } else {
            $result_array = array(
                'msg' => 'Invalid asset_id/sessionguid'
            );
        }
        return $result_array;
    }
    //============ Asset heartbeat============
    function insertheatbeat($asset_id)
    {
        $asset_list = explode(",", $asset_id);
        $flag=0;
        foreach ($asset_list as $asset) {
            $this->db->select('s.store_code,as.asset_service_tag,as.asset_id');
            $this->db->where('as.asset_code', $asset);
            $this->db->join('rmn_store_master as s', 's.store_id=as.asset_store_id');
            $result = $this->db->get('rmn_asset_master as as')->row();
            if (count($result) > 0) {
            	$flag=1;
                $param       = array(
                    'asset_id' => $result->asset_id,
                    'pingdatetime' => date("Y-m-d H:i:s"),
                    'store_code' => $result->store_code,
                    'asset_service_tag' => $result->asset_service_tag
                );
                $insert_data = $this->db->insert('rmn_asset_hearbeat', $param);
            }
        }
        if($flag==1){
	        $result_array = array(
	            'msg' => 'success'
	        );
        }else{
        	$result_array = array(
        		'msg' => 'Invalid session/assetid'
        	);
        }
        return $result_array;
    }
    // GET THE LIST ON SCHEDULE ID
    function getSchedule($is_prority)
    {
		$cur_date=date("Y-m-d");
        $this->db->select('sch_id,store_id,group_id,region_id,st_date,ed_date,is_prority,wk_monday,wk_tuesday,wk_wednesday,wk_thursday,wk_friday,wk_saturday,wk_sunday ');
        $this->db->where('is_prority', $is_prority);
        $this->db->where('is_sync_client', '0');
		$this->db->where("'".$cur_date."' BETWEEN st_date AND ed_date");
        $this->db->where('sch_status', 1);
        $sch      = $this->db->get('rmn_scheduler')->result_array();
        $schduler = array();
		$asset_info='';
        if (count($sch) > 0) {
            foreach ($sch as $sid) {
				if($sid['group_id'] !=''){
					$asset_info= $this->getassets('group',$sid['sch_id']);
				}
				if($sid['region_id'] !=''){
					$asset_info= $this->getassets('region',$sid['sch_id']);
				}
				if($sid['store_id']!=''){
					$asset_info= $this->getassets('store',$sid['sch_id']);
				}
				
                $schduler[] = array(
                    'scheduler_id' => $sid['sch_id'],
                    'asset_id' => $asset_info,
					'st_date' =>date("Y-m-d h:i:s A",strtotime($sid['st_date']."01:00:00")),
                    'ed_date' => date("Y-m-d h:i:s A",strtotime($sid['ed_date']."23:59:00")),
                    'is_prority' => $sid['is_prority'],
                    'week_day' => array(
                        'wk_monday' => $sid['wk_monday'],
                        'wk_tuesday' => $sid['wk_tuesday'],
                        'wk_wednesday' => $sid['wk_wednesday'],
                        'wk_thursday' => $sid['wk_thursday'],
                        'wk_friday' => $sid['wk_friday'],
                        'wk_saturday' => $sid['wk_saturday'],
                        'wk_sunday' => $sid['wk_sunday']
                    ),
                    'videos' => $this->getvideos($sid['sch_id'])
                );
            }
            $result_array = array(
                'msg' => 'success',
                'schedule' => $schduler
            );
        } else {
            $result_array = array(
                'msg' => 'noschedulefound'
            );
        }
        return $result_array;
    }
    // GET THE ASSETS BASED ON SCHEDULE ID
    function getassets($category,$id)
    {
		$array1=array();
		$array2=array();
		$array3=array();
		if($category == 'region'){
			$this->db->select('a.asset_code');
			$this->db->where('rs.sch_status !=', -1);
			$this->db->where('rs.sch_id', $id);
			$this->db->where('r.region_id IS NOT NULL');
			$this->db->join('rmn_store_master as s', 'a.asset_store_id=s.store_id', 'left');
			$this->db->join('rmn_region_master as r', 's.region_id=r.region_id', 'left');
			$this->db->join('rmn_scheduler as rs', 'r.region_id=s.region_id', 'left');
			$array1 = $this->db->get('rmn_asset_master as a')->result_array();
        }
		if($category == 'group'){
			$this->db->select('a.asset_code');
			$this->db->where('rs.sch_status !=', -1);
			$this->db->where('rs.sch_id', $id);
			$this->db->where('g.group_id IS NOT NULL');
			$this->db->join('rmn_model_master as m', 'a.model_id=m.model_id', 'left');
			$this->db->join('rmn_model_group_mapping as mg', 'm.model_id=mg.model_id', 'left');
			$this->db->join('rmn_group_master as g', 'mg.group_id=g.group_id', 'left');
			$this->db->join('rmn_scheduler as rs', 'g.group_id=rs.group_id');
			$array2 = $this->db->get('rmn_asset_master as a')->result_array();
        }
		if($category == 'store'){
			$this->db->select('a.asset_code');
			$this->db->where('rs.sch_status !=', -1);
			$this->db->where('rs.sch_id', $id);
			$this->db->where('rs.store_id IS NOT NULL');
			$this->db->join('rmn_store_master as s', 's.store_id=a.asset_store_id', 'left');
			$this->db->join('rmn_scheduler as rs', 's.store_id=rs.store_id');
			$array3= $this->db->get('rmn_asset_master as a')->result_array();
        }
		$merged_arr = array_merge($array1, $array2, $array3);
        
        $result = array();
        foreach ($merged_arr AS $val) {
            $result[] = $val['asset_code'];
        }
        $result_set = '';
        $result     = array_unique($result);
        if (count($result) > 0) {
            $result_set = implode(",", $result);
        }
        return $result_set;
    }
    // GET THE VIDEOS BASED ON SCHEDULE ID
    function getvideos($id)
    {
        $this->db->select('rvm.video_file');
        $this->db->where('sch_id', $id);
        $this->db->where('rvm.video_status!=', -1);
        $this->db->join('rmn_video_playlist_mapping as rvpm', 'rvpm.playlist_id=rspm.playlist_id');
        $this->db->join('rmn_video_master as rvm', 'rvpm.video_id=rvm.video_id');
        $result    = $this->db->get('rmn_scheduler_playlist_mapping as rspm')->result_array();
        $videolist = array();
        if (count($result) > 0) {
            foreach ($result as $video) {
                $videolist[] = $video['video_file'];
            }
            return $videolist;
        }
        return $videolist;
    }
    
    //============ UPDATE SCHEDULE STATUS============
    function update_schedulestatus($schedule_id)
    {
    	$schedule_list = explode(",", $schedule_id);
    	$flag=0;
    	foreach ($schedule_list as $schedule) {
    		$this->db->select('sch_id');
    		$this->db->where('sch_id', $schedule);
    		$result = $this->db->get('rmn_scheduler as as')->row();
    		if (count($result) > 0) {
    			$flag=1;
    			 $param    = array(
		            'is_sync_client' => '1'
		        );
    			 //update the schedule as  sync
                $this->db->where('sch_id', $schedule);
                $this->db->update('rmn_scheduler', $param);
    		}
    	}
    	if($flag==1){
    		$result_array = array(
    				'msg' => 'success'
    		);
    	}else{
    		$result_array = array(
    				'msg' => 'Invalid schedule id'
    		);
    	}
    	return $result_array;
    }
    
    /*
     * Check or create model_id - vignesh - 21092018
     */
    function check_create_model($model_name){
    	$this->db->where('model_name', $model_name);
    	$result = $this->db->get('rmn_model_master')->row();
    	if(isset($result->model_id)){
    		return $result->model_id;
    	}else{
    		$param = array(
					'model_name' => $model_name,
					'model_status' => 1,
					'brand_id' => 1,
				);
    		$this->db->insert('rmn_model_master',$param);
    		
    		$this->db->where('model_name', $model_name);
    		$result = $this->db->get('rmn_model_master')->row();
    		return $result->model_id;
    	}
    }
    
    /*
     * Generate a Asset ID
     */
    function createAssetData($length)
    {
    	$token = "";
    	$codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    	$codeAlphabet.= "0123456789";
    	$max = strlen($codeAlphabet); // edited
    
    	for ($i=0; $i < $length; $i++) {
    		$token .= $codeAlphabet[$this->crypto_rand_secure(0, $max-1)];
    	}
    
    	return $token;
    }
    
    function crypto_rand_secure($min, $max)
    {
    	$range = $max - $min;
    	if ($range < 1) return $min; // not so random...
    	$log = ceil(log($range, 2));
    	$bytes = (int) ($log / 8) + 1; // length in bytes
    	$bits = (int) $log + 1; // length in bits
    	$filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    	do {
    		$rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
    		$rnd = $rnd & $filter; // discard irrelevant bits
    	} while ($rnd > $range);
    	return $min + $rnd;
    }
	
	//check the server is running or not
	
	public function check_server_status(){
		$this->db->select('count(*) as cnt');
		$start_time=date("Y-m-d 10:30:00");
		$end_time=date("Y-m-d 19:00:00");
		$this->db->where('pingdatetime >=', $start_time);
		$this->db->where('pingdatetime <=', $end_time);
		$this->db->where("pingdatetime > NOW() - INTERVAL 60 MINUTE");
		$check_asset_cnt =$this->db->get('rmn_asset_hearbeat')->row_array();
		return $check_asset_cnt['cnt'];exit;


	}
}
