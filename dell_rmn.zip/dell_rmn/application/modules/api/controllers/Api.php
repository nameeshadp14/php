<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Api extends BSS_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('api_model');
    }
    
    /**
     * Asset Registration
     */
    public function index()
    {
        $result_array = array(
            'msg' => 'Invalid Request method'
        );
        echo json_encode($result_array);
    }
    
    /**
     * Asset Registration
     */
    public function asset_registration()
    {
        $request = json_decode($this->input->raw_input_stream, true);
        if (isset($request['storeid']) && isset($request['service_tag']) && isset($request['model_name'])) {
            if ($request['storeid'] != "" && $request['service_tag'] != "" && $request['model_name'] != "") {
                $result_array = $this->api_model->getasset_info($request['storeid'], $request['service_tag'], $request['model_name']);
                echo json_encode($result_array);
            } else {
                $result_array = array(
                    'msg' => 'Invalid asset_store_id/assetid'
                );
                echo json_encode($result_array);
            }
        } else {
            $result_array = array(
                'msg' => 'Input Fields are required'
            );
            echo json_encode($result_array);
        }
    }
    
    /**
     * Asset Authenticate
     */
    public function authenticate()
    {
        $request = json_decode($this->input->raw_input_stream, true);
        if (isset($request['sessionguid']) && isset($request['assetid'])) {
            if ($request['sessionguid'] != "" && $request['assetid'] != "") {
                $result_array = $this->api_model->authenticate($request['sessionguid'], $request['assetid']);
                echo json_encode($result_array);
            } else {
                $result_array = array(
                    'msg' => 'Invalid asset_sessionguid/asset_id'
                );
                echo json_encode($result_array);
            }
        } else {
            $result_array = array(
                'msg' => 'Input Fields are required'
            );
            echo json_encode($result_array);
        }
    }
    
    /**
     *  get the heartbeat
     */
    public function heartbeat()
    {
        $request = json_decode($this->input->raw_input_stream, true);
        if (isset($request['asset_id'])) {
            if ($request['asset_id'] != "") {
                $result_array = $this->api_model->insertheatbeat($request['asset_id']);
                echo json_encode($result_array);
            } else {
                $result_array = array(
                    'msg' => 'Invalid asset_sessionguid/asset_id'
                );
                echo json_encode($result_array);
            }
        } else {
            $result_array = array(
                'msg' => 'Input Fields are required'
            );
            echo jason_encode($result_array);
        }
    }
    /**
     *  update the schdule status
     */
    public function schedulestatus()
    {
    	$request = json_decode($this->input->raw_input_stream, true);
    	if (isset($request['schedule_id'])) {
    		if ($request['schedule_id'] != "") {
    			$result_array = $this->api_model->update_schedulestatus($request['schedule_id']);
    			echo json_encode($result_array);
    		} else {
    			$result_array = array(
    					'msg' => 'Invalid asset_sessionguid/asset_id'
    			);
    			echo json_encode($result_array);
    		}
    	} else {
    		$result_array = array(
    				'msg' => 'Input Fields are required'
    		);
    		echo jason_encode($result_array);
    	}
    }
    /**
     * get video Scheduler
     */
    public function videoschedule()
    {
        $request = json_decode($this->input->raw_input_stream, true);
        if (isset($request['is_priority'])) {
            if ($request['is_priority'] != "") {
                $result_array = $this->api_model->getSchedule($request['is_priority']);
                echo json_encode($result_array);
            } else {
                $result_array = array(
                    'msg' => 'Invalid asset_sessionguid/is_sync_client'
                );
                echo json_encode($result_array);
            }
        } else {
            $result_array = array(
                'msg' => 'Input Fields are required'
            );
            echo json_encode($result_array);
        }
    }   
    /**
     * Check the server status
     */
 public function check_server()
    {
    $result_array = $this->api_model->check_server_status();
    	IF($result_array <= 0 ){
			$this->load->library('email');
			//SMTP & mail configuration
			$config = array(
			    'protocol'  => 'smtp',
			    'smtp_host' => 'ssl://sg3plcpnl0228.prod.sin3.secureserver.net',
			    'smtp_port' => 465,
			    'smtp_user' => 'smtp2@baryonssoftsolutions.com',
			    'smtp_pass' => 'Baryons@123456',
			    'mailtype'  => 'html',
			    'charset'   => 'utf-8'
			);
			$this->email->initialize($config);
			$this->email->set_mailtype("html");
			$this->email->set_newline("\r\n");
			//Email content
			$date=date("d F, Y H:i:s");
			$htmlContent = "<h1>DELL RMN SERVER ISSUE ON - $date</h1>";
			$htmlContent .= '<p>Kindly Restart the DELL RMN Server. No Heartbeat Pingged</p>';
			$this->email->to('vignesh.m@baryons.net');
			$this->email->from('smtp2@baryonssoftsolutions.com','DELL RMN');
			$this->email->subject("DELL RMN Server Issue - $date");
			$this->email->message($htmlContent);
			
			//Send email
			$this->email->send();
	    	$result_array = array(
	                'msg' => 'Server Not working'
	         );
	    }else{
	    	$result_array = array(
	    			'msg' => 'Server Working'
	    	);
	    }
	    echo json_encode($result_array);
    }
}

    