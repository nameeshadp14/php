<?php
class Video_Model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_videos_count($filter_data=null)
	{
		$this->db->where('s.video_status!=',-1);
		$this->db->from('rmn_video_master as s');
		return $this->db->count_all_results();
	}
	function get_videocnt()
	{
		$this->db->from('rmn_video_master');
		return $this->db->count_all_results();
	}
	/*
	 * Get all pmo_status_master
	 */
	function get_all_videos($filter_data=null,$params = array())
	{
		$this->db->where('s.video_status!=',-1);
		$this->db->order_by('s.video_name', 'ASC');
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->select('*');
		return $this->db->get('rmn_video_master s')->result_array();
	}
	
	/*
	 * Add New region
	 */
	public function add($param){
		$this->db->insert('rmn_video_master',$param);
		$this->db->select('max(video_id) as video_id');
		$this->db->from('rmn_video_master');
		$query=$this->db->get()->row_array();
		return $query['video_id'];
	}
	
	/*
	 * Get the region details by id
	 */
	public function  get_video_details($id){
		$this->db->where('video_id',$id);
		$this->db->where('s.video_status!=',-1);
		$this->db->select('*');
		return $this->db->get('rmn_video_master as s ')->row_array();
	}
	/*
	 * Update the region based on ID
	 */
	public function edit_video($param,$id){
		$this->db->where('video_id',$id);
		return $this->db->update('rmn_video_master',$param);
	}
	/*
	 * Remove the Store
	 */
	public function remove_video($id){
		if($this->checkVideostatus($id)== 1 ){
			//check file exists or not . IF yes delete the file
			$check_file = "./uploads/videos/".$id.'.mp4';
			if(file_exists($check_file)){
				if (is_readable($check_file)) {
					unlink($check_file);
				}
			}
			$this->db->where('video_id',$id);
			$param=array('video_status'=> -1);
			$this->db->update('rmn_video_master',$param);
			return 1;
		}else{
			return -1;
		}
	}

	/*
	 * Check region relation table exist or not
	 */
	public function checkVideostatus($id){
		$this->db->select(" COUNT(video_id) AS video");
		$this->db->where('video_id',$id);
		$this->db->from('rmn_video_playlist_mapping');
		$query=$this->db->get()->row_array();
		if($query['video'] ==0){
			return 1;
		}else{
			return -1;
		}
	}
}
