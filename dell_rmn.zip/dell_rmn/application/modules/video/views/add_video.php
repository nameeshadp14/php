<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add Video
		<a href="<?php echo base_url('video');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
       <form class="frm_inner cmn_form" id="video_management" >
	        <div class="row clearfix">
	         		<div class="col-md-12">
	       				<div class="msg"></div>
	       			</div>
	                <div class="col-md-4">
	                    <label for="video 	name" class="control-label">Video Name <span class="text-danger">*</span></label>
	                    <div class="form-group">
	                        <input type="text" name="video_name" value="<?php echo $this->input->post('video_name'); ?>" class="form-control video_name" id="video_name" />
	                        <span class="text-danger"><?php echo form_error('store_name');?></span>
	                    </div>
	                </div>
	                 <div class="col-md-4 form-group">
	                    <label>Status <span class="text-danger">*</span></label>
	                    <select name="status" id="status" class="form-control">
	                    		<option value="">--Select Status--</option>
	                    		<option value="1">Active</option>
	                    		<option value="0">Inactive</option>
	                    </select>
	                	<span class="text-danger"><?php echo form_error('status');?></span>
	                 </div>
	                 <div class="col-md-4 ">
	                    <label for="upload" class="control-label">Upload <span class="text-danger">*</span>  <span style="color:red">(Only Mp4)</span></label><div style="color:red" class="video_error pull-right"></div>
	                    <div class="form-group">
	                        <input class="form-control"  accept="video/*" type="file" id="videofile" name="videofile" />  	
	                    </div>
	                </div>
	               	<div class="clearfix"></div>
	               	<div class="text-right btn_ar">
			            <div class="col-md-12 p_right">
			           		 <input type="hidden"  name="btn_type" id="btn_type" value="2"/>
			            	 <input type="submit" name="save_continue" id="save_continue_btn" data-btnttype='1' class="btn btn-primary video_btn_type" value="SAVE & Continue">
			            	  <input type="submit" name="save_add" id="save_add_btn" data-btnttype='2'  class="btn btn-primary video_btn_type" value="SAVE & Add New">
			                <input type="hidden" name="<?php echo $csrf_name;?>" id="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
			            </div>
			       	 </div>
	               	 <div class="col-md-12">
	                    <label for="progress bar" class="control-label"></label>
	                      <div class="form-group">
	                        <div class="progress active-fade">
	                            <div class="progress-bar progress-bar-success myprogress" role="progressbar" style="width:0%">0%</div>
	                        </div>
	                    </div>
	                </div>
	        </div>
	        <div class="clearfix"></div>
	        <div class="col-md-6">
	             <div class="preview_video">
	                <h4>Video Preview</h4>
					<video width="100%" controls>
						  <source src="mov_bbb.mp4" id="preview_here">
							our browser does not support HTML5 video.
					</video>
				</div>
	        </div>
    	</form>
	</div>
</div>

