<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit Video
		<a href="<?php echo base_url('video');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
       <form class="frm_inner cmn_form" id="update_video_management" >
	        <div class="row clearfix">
	         		<div class="col-md-12">
	       				<div class="msg"></div>
	       			</div>
	                <div class="col-md-4">
	                    <label for="store_name" class="control-label">Video Name <span class="text-danger">*</span></label>
	                    <div class="form-group">
	                        <input type="text" name="video_name" value="<?php echo set_value('video_name',$video_info['video_name']); ?>" class="form-control video_name" id="video_name" />
	                        <span class="text-danger"><?php echo form_error('store_name');?></span>
	                    </div>
	                </div>
	                 <div class="col-md-4 form-group">
	                    <label>Status <span class="text-danger">*</span></label>
	                    <select name="status" id="status" class="form-control">
	                    		<option value="">--Select Status--</option>
	                    		<option value="1" <?php echo $video_info['video_status']== 1 ? 'selected=selected':'';?>>Active</option>
	                    		<option value="0" <?php echo $video_info['video_status']== 0 ? 'selected=selected':'';?>>Inactive</option>
	                    </select>
	                	<span class="text-danger"><?php echo form_error('status');?></span>
	                </div>
	                 <div class="col-md-4 ">
	                    <label for="upload" class="control-label">Upload   <span style="color:red">(Only Mp4)</span></label> <div style="color:red" class="video_error pull-right"></div>
	                    <div class="form-group">
	                        <input class="form-control"  accept="video/*" type="file" id="videofile" name="videofile" />
	                    </div>
	                </div>
	                <div class="clearfix"></div>
	                <div class="text-right btn_ar">
			            <div class="col-md-12 p_right">
			            	  <input type="hidden" name="video_id" id="video_id" value="<?php echo $video_info['video_id'];?>" />
			            	  <input type="submit" name="save_add" id="save_add_btn" data-btnttype='2'  class="btn btn-primary video_btn_type" value="Update">
			            </div>
			        </div>
	                 <div class="col-md-12">
	                    <label for="store_type" class="control-label"></label>
	                    <div class="form-group">
	                        <div class="progress">
	                             <div class="progress-bar progress-bar-success myprogress" role="progressbar" style="width:0%">0%</div>
	                        </div>
	                    </div>
	                </div>
	        </div>
	        <div class="clearfix"></div>
	             <div class="col-md-6">
	                 <h4>Video Preview
	                  <!-- 	<?php if($video_info['video_file'] !=''){ ?><a href="void:javascript();" onclick="del_video('<?php echo $video_info['video_id'];?>')"class="btn btn-danger pull-right">Delete Video</a> <?php }?> -->
	        		 </h4>
	        		 <hr>
	                 <div class="preview_video" <?php if($video_info['video_file']==''){ ?>style="display:none" <?php }?>>
						<video width="100%" controls>
						  <source src="<?php echo base_url('/uploads/videos/'.$video_info['video_file']);?>" id="preview_here">
							Your browser does not support HTML5 video.
						</video>
					</div>
	            </div>
    	</form>
	</div>
</div>
