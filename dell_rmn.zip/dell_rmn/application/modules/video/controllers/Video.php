<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Video extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin ||$this->isEditor ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('video_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "video/index";
		$total_row = $this->video_model->get_all_videos_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_video"] = $this->video_model->get_all_videos($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', "List of Video's");
		$this->template->set('page_breadcrumb', "List of Video's");
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Video');
		$this->template->set('page_breadcrumb', 'Add - Video');
		if($this->input->server('REQUEST_METHOD')=='POST'){
			if(isset($_FILES['upload_video']['name'])){
				if($_FILES['upload_video']['name'] !=""){
					$this->form_validation->set_rules('upload_video','Video','callback_upload_video');
				}
			}
			if($this->form_validation->run())
			{	
				$filename = $_FILES['upload_video']['name'];
				$ext = pathinfo($filename, PATHINFO_EXTENSION);
				$file_name=$this->video_model->get_videocnt()+1;
				$file_name=$file_name.".".$ext;
				$params = array(
						'video_file' =>$file_name,
						'video_name' => $this->input->post('video_name'),
						'video_status'=>$this->input->post('video_status'),
						'created_by' => $this->isUserID,
						'created_date' => date("Y-m-d H:i:s"),
						'updated_by' => $this->isUserID,
						'updated_date' =>date("Y-m-d H:i:s"),
				);
				$video_id=$this->video_model->add($params);
				echo "1,".$video_id;
			}else{
				echo 2;
			}
			exit;
		}
		$this->template->load('template', 'contents' , 'add_video',$data);
	}
	public function edit($id){
		$data = array();
		$data['video_info']=$this->video_model->get_video_details($id);
		if($data['video_info']['video_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Video');
			$this->template->set('page_breadcrumb', 'Edit - Video');
			if($this->input->server('REQUEST_METHOD')=='POST'){
				if(isset($_FILES['upload_video']['name'])){
					if($_FILES['upload_video']['name'] !=""){
						$this->form_validation->set_rules('upload_video','Video','callback_upload_video');
					}
				}else{
					$this->form_validation->set_rules('video_name','Video Name','trim|required');
				}
				if($this->form_validation->run())
				{
					if(isset($_FILES['upload_video']['name'])){
						$filename = $_FILES['upload_video']['name'];
						$ext = pathinfo($filename, PATHINFO_EXTENSION);
						$file_name=$id.".".$ext;
						$params = array(
								'video_file' =>$file_name,
								'video_name' => $this->input->post('video_name'),
								'video_status'=>$this->input->post('video_status'),
								'updated_by' => $this->isUserID,
								'updated_date' =>date("Y-m-d H:i:s"),
						);
					}else{
						$params = array(
								'video_name' => $this->input->post('video_name'),
								'video_status'=>$this->input->post('video_status'),
								'updated_by' => $this->isUserID,
								'updated_date' =>date("Y-m-d H:i:s"),
						);
					}
					$this->video_model->edit_video($params,$id);
					echo "1,".$id;
				}else{
					echo 2;
				}
				exit;
			}
			$this->template->load('template', 'contents' , 'edit_video',$data);
		}else{
			redirect('unauthorize');
		}
	}
	public function upload_video(){
		$config['upload_path'] = './uploads/videos/';
		$config['allowed_types']        = 'mp4';
		$filename = $_FILES['upload_video']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if($this->input->post('video_id')){
			$video_name = $this->input->post('video_id');
		}else{
			$video_name=$this->video_model->get_videocnt()+1;
		}
		
		$config['file_name'] = 	$video_name.".".$ext;
		
		$this->load->library('upload', $config);

		//check file exists or not . IF yes delete the file
		$check_file = $config['upload_path'].$config['file_name'];
		if(file_exists($check_file)){
			if (is_readable($check_file)) {
				 unlink($check_file);
			} 
		}
		if(isset($_FILES['upload_video']) && !empty($_FILES['upload_video']['name']))
		{
			if($this->upload->do_upload('upload_video',$config['file_name']))
			{
				return TRUE;
			}
			else
			{
				$this->form_validation->set_message(__FUNCTION__, $this->upload->display_errors());
				return FALSE;
			}
		}
		else
		{
			$this->form_validation->set_message(  __FUNCTION__ , "Please Select the file");
			return FALSE;
		}
	}
	
	/*
	 * Delete The Video - Vignesh -08062018
	 */
	public function remove($id){
		$data = array();
		$data['video_info']=$this->video_model->get_video_details($id);
		if($data['video_info']['video_id']){
			if($this->video_model->remove_video($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Video has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Video has been used in the application.');
			}
			redirect('video');
		}else{
			redirect('unauthorize');
		}
	}
}
