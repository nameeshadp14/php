<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist_model  extends CI_model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	function get_all_playlist_count($filter_data=null)
	{
		$this->db->where('p.playlist_status!=',-1);
		$this->db->order_by('p.playlist_name', 'ASC');
		
		if(count($filter_data)>0){
			$this->db->like('p.playlist_name',$filter_data['listname'],'both');
			$this->db->like('p.playlist_status',$filter_data['status']);
		}
		
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->from('rmn_video_playlist as p');
		return $this->db->count_all_results();
	}
	
	/*
	 * Get all Playlist details
	 */
	function get_all_playlist($filter_data=null,$params = array())
	{
		
		$this->db->where('p.playlist_status!=',-1);
		$this->db->order_by('p.playlist_name', 'ASC');
		$this->db->group_by('p.playlist_id');
		if(count($filter_data)>0){
			$this->db->like('p.playlist_name',$filter_data['listname'],'both');
			$this->db->like('p.playlist_status',$filter_data['status']);
		}
		if(isset($params) && !empty($params))
		{
			$this->db->limit($params['limit'], $params['offset']);
		}
		$this->db->join('rmn_video_playlist_mapping as pm','pm.playlist_id=p.playlist_id','left');
		$this->db->select('p.*, COUNT(pm.`playlist_id`) AS video_cnt ');
		return $this->db->get('rmn_video_playlist p')->result_array();
	}
	
	/*
	 * Add New playlist
	 */
	public function add($param){
		$this->db->insert('rmn_video_playlist',$param);
		$this->db->select('max(playlist_id) as playlist_id');
		$this->db->from('rmn_video_playlist');
		$query=$this->db->get()->row_array();
		return $query['playlist_id'];
	}
	
	/*
	 * Get the playlist details by id
	 */
	public function  get_playlist_details($id){
		$this->db->where('	playlist_id',$id);
		$this->db->where('playlist_status!=',-1);
		$this->db->select('*');
		return $this->db->get('rmn_video_playlist ')->row_array();
	}
	/*
	 * Get the playlist details by id
	 */
	public function  get_listvideos_byid($id){
		$this->db->where('playlist_id',$id);
		$this->db->select('video_id');
		return $this->db->get('rmn_video_playlist_mapping ')->result_array();
	}
	/*
	 * Update the playlist based on ID
	 */
	public function edit_playlistinfo($param,$id){
		$this->db->where('playlist_id',$id);
		return $this->db->update('rmn_video_playlist',$param);
	}
	
	/*
	 * map the playlist and videos
	 */
	public function edit_playlist($video_list,$id){
		$this->db->where('playlist_id',$id);
		$this->db->delete('rmn_video_playlist_mapping');
		
		if(count($video_list)>0){
			foreach ($video_list as $video){
				$param = array(
						'video_id' =>$video,
						'playlist_id' =>$id,
				);
				$this->db->insert('rmn_video_playlist_mapping',$param);
			}
		}
		return true;
		
	}
	/*
	 * Remove the Playlist
	 */
	public function remove_playlist($id){
		if($this->checkplayliststatus($id)== 1 ){
			$this->db->where('playlist_id',$id);
			$param=array('playlist_status'=> -1,'updated_by' => $this->isUserID,'updated_date' => date("Y-m-d H:i:s"));
			$this->db->update('rmn_video_playlist',$param);
			return 1;
		}else{
			return -1;
		}
	}

	/*
	 * Check playlist relation table exist or not
	 */
	public function checkplayliststatus($id){
		$flag=0;
		$this->db->select(" COUNT(`s`.`playlist_id`) AS playlist");
		$this->db->where('s.playlist_id',$id);
		$this->db->from('rmn_scheduler_playlist_mapping as s');
		$query=$this->db->get()->row_array();
		if($query['playlist'] ==0 ){
			return 1;
		}else{
			return -1;
		}
	}

	/*
	 * Check plalist name  exist or not for edit
	 */
	public function checkplayliststatusforedit($id,$playlist_name){
		$this->db->select('playlist_name');
		$this->db->where('playlist_name',$playlist_name);
		$this->db->where('playlist_status !=',-1);
		$this->db->where('playlist_id !=',$id);
		$query=$this->db->get('rmn_video_playlist')->row_array();
        if(count($query)>0){
			return -1;
        }else{
			return 1;
		}
	}
	
	public function checkplaylist($playlist_name){
		
		$this->db->select('*');
		$this->db->where('playlist_name',$playlist_name);
		$getplaylist=$this->db->get('rmn_video_playlist')->row_array();
		if(count($getplaylist)>0)
		{
			return -1;
		}else{
			return 1;
		}
	}
	
	
}
