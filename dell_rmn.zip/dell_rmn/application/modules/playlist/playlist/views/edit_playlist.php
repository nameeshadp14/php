<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Edit Playlist
				<a href="<?php echo base_url('playlist');?>" class="btn btn-success btn-xs pull-right">Go back</a>
		</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="playlist_management" method="post" action="">
                <div class="col-md-6">
                    <label for="store_name" class="control-label">Playlist Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="playlist_name" value="<?php echo set_value('playlist_name', $playlist_info['playlist_name']); ?>" class="form-control" id="playlist_name" />
                        <span class="text-danger"><?php echo form_error('playlist_name');?></span>
                    </div>
                </div>
               
                 <div class="col-md-6 form-group">
                    <label>Status <span class="text-danger">*</span></label>
                    <select name="status" id="status" class="form-control">
                    	<option value="">--Select Status--</option>
                    	<option value="1" <?php echo $playlist_info['playlist_status']== 1 ? 'selected=selected':'';?>>Active</option>
                    	<option value="0" <?php echo $playlist_info['playlist_status']== 0?  'selected=selected':'';?>>Inactive</option>
                    </select>
                	<span class="text-danger"><?php echo form_error('status');?></span>
                </div>
          
        </div>
        <div class="row upload_video_filter">
        	<div class="col-md-6">
                  <h2 class="cmn_tit_main">Video Preview</h2>
                    <div class="preview_video" style="display:none">
						<video width="100%" controls>
						  <source src="" id="preview_here">
							Your browser does not support HTML5 video.
						</video>
					</div>
                </div>
                
                 <div class="col-md-6 form-group cmn_form">
	                 <div class="form-group">
			            <label for="email" class="sr-only">Type something in the input field to search the list for videos:</label>
			            <input data-toggle="tooltip" class="form-control" type="text" name="myInput" id="myInput" placeholder="Search by Videos name" data-original-title="Search by Videos name">
			        </div>
			        <p id="abc"></p>
                   <h2 class="cmn_tit_main">Play List</h2>
	                 <ul class="checkboxes">
	                 <?php $mylist=array();
		                 	foreach ($my_videos as $myv){
		                 		array_push($mylist,$myv['video_id']);
		                 	}
	                 	 foreach ($list_of_videos as $video){ ?>
						  <li class="list-unstyled">
						    <label title="" for="option-0">
						    <input type="checkbox" <?php echo in_array($video['video_id'],$mylist)? "checked=checked":"";?> name="video_list[]" value="<?php echo $video['video_id'];?>"/>&nbsp;&nbsp;<a  style="text-underline:none" href="javascript:void(0);" data-url="<?php echo $video['video_file'];?>" class="playlist_preview_video"><?php echo $video['video_name'];?>&nbsp;&nbsp;<i class="fa fa-play-circle-o"></i></a>
						    </label>
						  </li>
	                	<?php } ?>
	                	
	                </ul>
                </div>
                
                <input type="hidden" name="btn_type" id="btn_type" value="2">
                <div class="text-right btn_ar">
            	<div class="col-md-12 p_right">
		            	<input type="submit" name="save_add" id="save_add_btn" data-btnttype='2'  class="btn btn-primary video_btn_type" value="Update">
		                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />
		
		            </div>
		        </div>
                
          </div>
        
        </form>
	</div>
</div>
