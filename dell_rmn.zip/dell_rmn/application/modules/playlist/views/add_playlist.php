<div class="col-md-12 bg_white">
    <h2 class="cmn_tit_main">Add Playlist
				<a href="<?php echo base_url('playlist');?>" class="btn btn-success btn-xs pull-right">Go back</a>
	</h2>
    <div class="box-body">
        <div class="row clearfix">
            <form class="frm_inner cmn_form" id="playlist_management" method="post" action="">
                <div class="col-md-6">
                    <label for="store_name" class="control-label">Playlist Name <span class="text-danger">*</span></label>
                    <div class="form-group">
                        <input type="text" name="playlist_name" value="<?php echo $this->input->post('playlist_name'); ?>" class="form-control" id="playlist_name" />
                        <span class="text-danger"><?php echo form_error('playlist_name');?></span>
                    </div>
                </div>
               
                 <div class="col-md-6 form-group">
                    <label>Status <span class="text-danger">*</span></label>
                    <select name="status" id="status" class="form-control">
                    		<option value="">--Select Status--</option>
                    		<option value="1">Active</option>
                    		<option value="0">Inactive</option>
                    </select>
                	<span class="text-danger"><?php echo form_error('status');?></span>
                </div>
                <input type="hidden" name="btn_type" id="btn_type" value="2">
        </div>
        <div class="text-right btn_ar">
            <div class="col-md-12 p_right">
               <input type="submit" name="save_continue" id="save_continue_btn" data-btnttype='1' class="btn btn-primary video_btn_type" value="Continue">
            	<input type="submit" name="save_add" id="save_add_btn" data-btnttype='2'  class="btn btn-primary video_btn_type" value="Add New">
                <input type="hidden" name="<?php echo $csrf_name;?>" value="<?php echo $csrf_hash;?>" />

            </div>
        </div>
    	</form>
	</div>
</div>