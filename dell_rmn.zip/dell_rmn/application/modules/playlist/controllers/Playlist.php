<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist extends BSS_Controller {

	public function __construct() {
		parent::__construct();
		$this->isAdmin || $this->isEditor ? true : redirect("unauthorize"); // User Logged in or not Check
		$this->load->model('playlist_model');
		$this->load->model('video/video_model');
	}
	public function index()
	{
		$data = array();
		$params=array();
		$filter_data=$this->input->get();
		$params['limit'] = RECORDS_PER_PAGE;
		$config = $this->config->item('pagination');
		$config["base_url"] =base_url() . "playlist/index";
		$total_row = $this->playlist_model->get_all_playlist_count($filter_data);
		$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$config["total_rows"] = $total_row;
		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = (($this->uri->segment(3)-1)*$config["per_page"]);
		}
		else{
			$page = 0;
		}
		$params['offset'] = $page;
		$data["list_of_playlist"] = $this->playlist_model->get_all_playlist($filter_data,$params);
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'List of Playlist');
		$this->template->set('page_breadcrumb', 'List of Playlist');
		$this->template->load('template', 'contents' , 'index',$data);
	}
	
	public function add(){
		$data = array();
		$data['csrf_name']= $this->security->get_csrf_token_name();
		$data['csrf_hash']= $this->security->get_csrf_hash();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Add - Playlist');
		$this->template->set('page_breadcrumb', 'Add - Playlist');
		if($this->input->server('REQUEST_METHOD')=='POST'){
			$this->form_validation->set_rules('playlist_name','PlayList Name','trim|required|max_length[50]');
			$this->form_validation->set_rules('status','Status','trim|required');
			if($this->form_validation->run())
			{
				 $params = array(
					'playlist_name' => $this->input->post('playlist_name'),
					'playlist_status' => $this->input->post('status'),
					'created_by' => $this->isUserID,
					'created_date' => date("Y-m-d H:i:s"),
					'updated_by' => $this->isUserID,
					'updated_date' =>date("Y-m-d H:i:s"),
	            );
				 $checkstatus=$this->playlist_model->checkplaylist($this->input->post('playlist_name'));
				 if($checkstatus==1)
				 {
				$playlist_id=$this->playlist_model->add($params);
				if($this->input->post('btn_type')==1){
					$this->session->set_flashdata('success_msg', 'New Playlist Added successfully.you can edit details here');
					redirect('playlist/edit/'.$playlist_id);
				}else{
					$this->session->set_flashdata('success_msg', 'New Playlist added successfully.');
					redirect('playlist/add');
				}
				 }
				 else{
				 	$this->session->set_flashdata('error_msg', 'Playlist already exist.');
				 }
			}
			else
			{
				$this->template->load('template', 'contents' , 'add_playlist',$data);
			}
		}
		$this->template->load('template', 'contents' , 'add_playlist',$data);
	}
	
	public function edit($id){
		$data = array();
		$data['playlist_info']=$this->playlist_model->get_playlist_details($id);
		if($data['playlist_info']['playlist_id']){
			$data['csrf_name']= $this->security->get_csrf_token_name();
			$data['csrf_hash']= $this->security->get_csrf_hash();
			$this->template->set('title', $this->config->item('app_name'));
			$this->template->set('page_title', 'Edit - Playlist');
			$this->template->set('page_breadcrumb', 'Edit - Playlist');
			$data["list_of_videos"] = $this->video_model->get_all_videos();
			$data["my_videos"] = $this->playlist_model->get_listvideos_byid($id);
			if($this->input->server('REQUEST_METHOD')=='POST'){
				$this->form_validation->set_rules('playlist_name','PlayList Name','trim|required|max_length[50]');
				$this->form_validation->set_rules('status','Status','trim|required');
				if($this->form_validation->run())
				{
					$params = array(
						'playlist_name' => $this->input->post('playlist_name'),
						'playlist_status' => $this->input->post('status'),
						'updated_by' => $this->isUserID,
						'updated_date' =>date("Y-m-d H:i:s"),
		            );
					$checkplaylist=$this->playlist_model->checkplayliststatusforedit($id,$this->input->post('playlist_name'));
					if($checkplaylist==1){
						
					$this->playlist_model->edit_playlistinfo($params,$id);
					
					$this->playlist_model->edit_playlist($this->input->post('video_list'),$id);
					$this->session->set_flashdata('success_msg', 'Playlist updated successfully.');
					redirect('playlist');
				
				}else{
					$this->session->set_flashdata('error_msg', 'Playlist Name already exist.');
				}
				}else
				{
					$this->template->load('template', 'contents' , 'edit_playlist',$data);
				}
				
			}
			$this->template->load('template', 'contents' , 'edit_playlist',$data);
		}else{
			redirect('unauthorize');
		}
	}
	/*
	 * Delete The Remoee - Vignesh -08062018
	 */
	public function remove($id){
		$data = array();
		$data['playlist_info']=$this->playlist_model->get_playlist_details($id);
		if($data['playlist_info']['playlist_id']){
			if($this->playlist_model->remove_playlist($id) == 1){
				$this->session->set_flashdata('success_msg', 'The Playlist has been deleted successfully.');
			}else{
				$this->session->set_flashdata('error_msg', 'The Playlist has been used in the application.');
			}
			redirect('playlist');
		}else{
			redirect('unauthorize');
		}
	}
}
