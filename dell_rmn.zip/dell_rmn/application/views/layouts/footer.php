 <footer>
    <div class="container-fluid ">
      <div class="col-md-8 p_left ">
        <ul class="list-unstyled list-inline">
<!--           <li><a href="#">Home</a></li> -->
<!--           <li><a href="#">About</a></li> -->
<!--           <li><a href="#">Legal Use</a></li> -->
<!--           <li><a href="#">Contact</a></li> -->
        </ul>
      </div>
      <div class="col-md-4  text-right">
        <p>Copyright &copy; <?php echo date('Y');?></p>
      </div>
    </div>
  </footer>
    <!-- jQuery -->
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>  
<script type='text/javascript' src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/additional-methods.min.js');?>"></script>
<script  type='text/javascript' src="<?php echo base_url('assets/js/moment.js');?>"></script>
<script  type='text/javascript' src="<?php echo base_url('assets/js/bootstrap-datetimepicker.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/bootbox.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/custom.js');?>"></script>

</body>
</html>
