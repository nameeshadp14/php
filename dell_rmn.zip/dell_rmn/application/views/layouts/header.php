<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <title><?php echo $title;?></title>
	 <link href="<?php echo base_url('assets/images/dell_icon.ico'); ?>" rel="icon" type="image/x-icon" />
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/font-awesome.min.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
    <!-- Custom CSS -->
 	<script type='text/javascript' src="<?php echo base_url('assets/js/jquery-1.12.4.js');?>"></script>
 </head>
<body>
   <!-- Header -->
<header class="navbar-fixed-top">
<div class="container-fluid">
	<div class="logo">
		<img src="<?php echo base_url('assets/images/dell_logo.png'); ?>" title="DELL">
	</div>
	<div class="hd_right">
		<p>Welcome <?php echo $this->session->userdata('userName')?></p>
		<div class="dropdown">
		  <a href="#" dropdown-toggle" type="button" data-toggle="dropdown"><img src="<?php echo base_url('assets/images/male_new.png'); ?>">
		  <span class="caret"></span></a>
		  <ul class="dropdown-menu">
		    <li><a href="<?php echo base_url('user/change');?>" title="Change password">Change Password</a></li>
		    <li><a href="<?php echo base_url('auth/logout'); ?>"  title="Logout">Logout</a></li>
			  </ul>
		</div>
	</div>
</div>
</header>	