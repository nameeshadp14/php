<?php echo  $this->router->fetch_class();?>
	<ul class="list-unstyled">
		<?php if(($this->isAdmin)  || ($this->isRegion)): ?>
		<li class="main_link"><img src="<?php echo base_url('assets/images/four-thumbnailsnew.png'); ?>"><span>Master pages</span>
			<ul class="list-unstyled">
				<li <?php echo $this->router->fetch_class() == 'dashboard' ? 'class="active"':''; ?>><a href="<?php echo base_url('dashboard')?>" title="Users">Dashboard</a></li>
				<?php if(($this->isAdmin) ||(($this->isAdmin) && ($this->isRegion))): ?><li <?php echo $this->router->fetch_class() == 'user' ? 'class="active"':''; ?>><a href="<?php echo base_url('user')?>" title="Users">Users</a></li>
				<li <?php echo $this->router->fetch_class() == 'region' ? 'class="active"':''; ?>><a href="<?php echo base_url('region')?>"  title="Region">Region</a></li>
				<li <?php echo $this->router->fetch_class() == 'city' ? 'class="active"':''; ?>><a href="<?php echo base_url('city')?>"  title="City">City</a></li>
			    <li <?php echo $this->router->fetch_class() == 'store' ? 'class="active"':''; ?>><a href="<?php echo base_url('store')?>"  title="Store">Store</a></li>
			    <li <?php echo $this->router->fetch_class() == 'brand' ? 'class="active"':''; ?>><a href="<?php echo base_url('brand')?>"  title="Brand">Brand</a></li>
			    <li <?php echo $this->router->fetch_class() == 'model' ? 'class="active"':''; ?>><a href="<?php echo base_url('model')?>"  title="Model">Model</a></li>
			    <li <?php echo $this->router->fetch_class() == 'asset' ? 'class="active"':''; ?> ><a href="<?php echo base_url('asset')?>"  title="Asset">Asset</a></li>
			    <?php endif; ?>
			</ul>
		</li>
		<?php endif; if(($this->isAdmin) || ($this->isEditor)):	?>
		<li class="main_link"><img src="<?php echo base_url('assets/images/play-button_new.png'); ?>"><span>Video's & Playlist</span>
			<ul class="list-unstyled">
				<li <?php echo $this->router->fetch_class() == 'video' ? 'class="active"':''; ?> ><a href="<?php echo base_url('video')?>"  title="Video's">Video's</a></li>
    			<li <?php echo $this->router->fetch_class() == 'playlist' ? 'class="active"':''; ?> ><a href="<?php echo base_url('playlist')?>"  title="Playlists">Playlists</a></li>
			</ul>
		</li>
		<li class="main_link"><img src="<?php echo base_url('assets/images/calendar-page_new.png'); ?>"><span>Group & Sheduler</span>
			<ul class="list-unstyled">
				<li <?php echo $this->router->fetch_class() == 'group' ? 'class="active"':''; ?> ><a href="<?php echo base_url('group')?>"  title="Groups">Groups</a></li>
     			<li <?php echo $this->router->fetch_class() == 'scheduler' ? 'class="scheduler"':''; ?> ><a href="<?php echo base_url('scheduler/index'.'/'.$this->regionID)?>"  title="Scheduler">Scheduler</a></li>
			</ul>
		</li>
		<?php endif; ?>
		 <?php if(($this->isAdmin) || ($this->isEditor ||($this->isUser)  || ($this->isRegion))):?>
		<li class="main_link"><img src="<?php echo base_url('assets/images/growth_one.png'); ?>"><span>Generate Report</span>
				<ul class="list-unstyled">
					<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getregionreport' ? 'class="active"':''; ?> ><a href="<?php echo base_url('report/getregionreport')?>"  title="Region">Region</a></li>
				  	<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getcityreport' ?  'class="active"':''; ?> ><a href="<?php echo base_url('report/getcityreport')?>"  title="City">City</a></li>
				  	<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getstorereport' ? 'class="active"':''; ?> ><a href="<?php echo base_url('report/getstorereport')?>"  title="Store">Store</a></li>
				 	<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getassetreport' ? 'class="active"':''; ?> ><a href="<?php echo base_url('report/getassetreport')?>"  title="Asset">Asset</a></li>
		        	<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getschedulereport' ? 'class="active"':''; ?> ><a href="<?php echo base_url('report/getschedulereport')?>"  title="Scheduler">Scheduler</a></li>
					<li <?php echo $this->router->fetch_class() == 'report' && $this->router->fetch_method()=='getstorebasedassetreport' ? 'class="active"':''; ?> ><a href="<?php echo base_url('report/getstorebasedassetreport')?>"  title="Region">Store Based Assets</a></li>
				</ul>
		</li>
		<?php endif; ?>
	</ul>

