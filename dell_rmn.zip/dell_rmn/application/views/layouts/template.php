<?php $this->load->view('layouts/header'); ?>

<div class="hm_dashboard">
	<div class="container-fluid p_left p_right main_con_data">
		<div class="left_menu">
			<?php $this->load->view('layouts/sidebar'); ?>
		</div>
		<div class="right_cont">
				<nav aria-label="breadcrumb">
					<h1 class="top_tit"><?php echo $page_title;?></h1>
					  <ol class="breadcrumb">
					    <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard')?>">Home</a></li>
					    <li class="breadcrumb-item active" aria-current="page"><?php echo $page_breadcrumb;?></li>
					  </ol>
				</nav>
			<?php if($this->session->flashdata('msg')): ?>
			    <div class="success_msg">
			    <p class="m_bottom"><?php echo $this->session->flashdata('msg'); ?></p>
			    </div>
			<?php endif; ?>	
                	<!-- Body Content -->
               	<?php if($this->session->flashdata('success_msg')): ?>
		               <div class="alert alert-success alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true" title="Close"><i class="icon fa fa-close"></i></button>
		                <p><?php echo $this->session->flashdata('success_msg'); ?></p>
		              </div>
				<?php endif; ?>
				<?php if($this->session->flashdata('error_msg')): ?>
		               <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true" title="Close"><i class="icon fa fa-close"></i></button>
		                <p><?php echo $this->session->flashdata('error_msg'); ?></p>
		              </div>
				<?php endif; ?>
               	<?php echo $contents; ?>
             <!-- Body Content -->
		</div>
	</div>
</div>
<!-- footer -->
<?php $this->load->view('layouts/footer'); ?>
<!-- footer -->
