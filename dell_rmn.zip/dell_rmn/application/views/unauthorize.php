<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Un Authorize</title>
	  <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
	 <!-- Custom CSS -->
    <link href="<?php echo base_url('assets/css/style.css');?>" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
    
</head>

<body class="">
    <!-- Login Screen -->
    <div class="container">
	    <div class="login_container">
	    
	        <div class="login">
	        <h3>Your unauthorize for this page</h3>
	        	<a href="<?php echo base_url('/dashboard');?>">Go back</a>
	         </div> <!-- End Login Screen -->  
	    </div>
    </div>
   
    <!-- jQuery -->
    <script type='text/javascript' src="<?php echo base_url('assets/js/jquery-1.12.4.js');?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script type='text/javascript' src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
    <!-- Plugin JavaScript -->
    <script type='text/javascript'  src="<?php echo base_url('assets/js/jquery.easing.min.js');?>"></script>
    <!-- Custom Theme JavaScript -->
    <script type='text/javascript' src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script>
 	 <script type='text/javascript' src="<?php echo base_url('assets/js/custom.js');?>"></script>
    

</body>

</html>
