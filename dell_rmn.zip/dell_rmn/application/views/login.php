<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $title;?></title>
	<link href="<?php echo base_url('assets/images/dell_icon.ico'); ?>" rel="icon" type="image/x-icon" />
	  <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
	 <!-- Custom CSS -->
    <link href="<?php echo base_url('assets/css/style.css');?>" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
    <style>
label.error {
    color: red;
    font-size: 12px;
}
</style>
</head>

<body class="login_bg">
		<?php if($this->session->flashdata('error_msg')): ?>
               <div class="alert alert-danger alert-dismissible" style="width: 70%; margin: auto;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true" title="Close"><i class="icon fa fa-close"></i></button>
                <p><?php echo $this->session->flashdata('error_msg'); ?></p>
              </div>
			<?php endif; ?>

<div class="container">
   	 	<div class="login_container">
	        <div class="login">
	            <img src="<?php echo base_url('assets/images/dell_logo.png'); ?>" class="img-responsive" alt="Logo-image" />
	             <form role="form" method="post" id="login_form" name="login">
	                 <div class="form-group">
	                   <input type="email" class="form-control" placeholder="Email ID" autocomplete="off"  name="email" id="email" >
	                 </div>
	                 <div class="form-group">
	                     <input type="password" class="form-control"  placeholder="Password" autocomplete="off" name="pass_word" id="pass_word">
	                 </div>
	                  <input type="hidden" name="<?php echo $csrf_fname;?>" value="<?php echo $csrf_hash;?>" />
	                 <div class="in_btn"><input type="submit" value="Sign in" class="btn"></div>
	             </form>
	         </div> <!-- End Login Screen -->  
    	</div>
</div>
    
    <!-- Login Screen -->
    
   
    <!-- jQuery -->
    <script type='text/javascript' src="<?php echo base_url('assets/js/jquery-1.12.4.js');?>"></script>
 <script type='text/javascript' src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>  
<script type='text/javascript' src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/additional-methods.min.js');?>"></script>
<script  type='text/javascript' src="<?php echo base_url('assets/js/moment.js');?>"></script>
<script  type='text/javascript' src="<?php echo base_url('assets/js/bootstrap-datetimepicker.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/custom.js');?>"></script>
    

</body>

</html>
