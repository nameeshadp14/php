<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <!-- Home Info Section Strta -->
 <div class="home_info_sec">
    	<h2 class="cmn_tit">Title</h2>
    	 <div class="bg_white">
    	 Home Page Content
    	</div>
    </div>
</div>