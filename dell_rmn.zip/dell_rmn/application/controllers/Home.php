<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends BSS_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index()
	{
		$data = array();
		$this->template->set('title', $this->config->item('app_name'));
		$this->template->set('page_title', 'Dashboard');
		$this->template->set('page_breadcrumb', 'User - Dashboard');
		$this->template->load('template', 'contents' , 'home',$data);
		
	}
}
