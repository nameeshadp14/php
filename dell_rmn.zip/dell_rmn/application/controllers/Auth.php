<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Auth
 * @property Ion_auth|Ion_auth_model $ion_auth        The ION Auth spark
 * @property CI_Form_validation      $form_validation The form validation library
 */
class Auth extends BSS_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('auth_model');
		$this->auth_model->update_sch_status();//calling a function to update the scheduler status in DB
		//$this->auth_model->update_assets_status();
	}

	public function index()
	{
		$data = array(
			'title' => $this->config->item('app_name'),
			'csrf_fname' => $this->security->get_csrf_token_name(),
			'csrf_hash' => $this->security->get_csrf_hash()
		);
		$this->load->view('login',$data);
		if ($this->input->server('REQUEST_METHOD') == 'POST'){
			$chklogin=$this->auth_model->login($this->input->post());
			if(count($chklogin)== 0){
				$this->session->set_flashdata('error_msg', 'Invalid login credential..Please try again.');
				redirect('/');
			}
			foreach ($chklogin as $val):
				if($val['is_active'] == 0):
					$this->session->set_flashdata('error_msg', 'The user is inactive.Please contact administrator');
					redirect('/');
				endif;
				$user_data = array(
					'logged_in' => TRUE,
					'user_role'=> $val['role_id'], //manager , user, admin
					'user_id'=>$val['user_id'],
					'userName'=>$val['name'],
					'region_id'=>$val['region_id'],
				);
			endforeach;
			
			$this->session->set_flashdata('success_msg', 'The user has logged in Successfully..');
			$this->session->set_userdata($user_data);
			redirect('/dashboard');
		}
	}
	
	public function logout(){
		$this->session->sess_destroy();
		redirect('/');
	}

}
