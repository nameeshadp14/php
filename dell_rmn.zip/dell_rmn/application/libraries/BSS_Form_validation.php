<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class BSS_Form_validation extends CI_Form_validation {
    protected $CI;

    public function __construct() {
        parent::__construct();
            // reference to the CodeIgniter super object
        $this->CI =& get_instance();
    }

	public function edit_unique($value, $params)  {
		
		$CI =& get_instance();
		$CI->load->database();
	
		$CI->form_validation->set_message('edit_unique', "Sorry, that %s is already being used.");
		list($table, $wherefieldid, $cur_field_id,$current_id) = explode(".", $params);
	
		$query = $CI->db->select()->from($table)->where($wherefieldid, $value)->limit(1)->get();
	
		if ($query->row() && $query->row()->$cur_field_id != $current_id)
		{
			return FALSE;
		} else {
			return TRUE;
		}
	}
	public function is_valid($value)
	{
		$CI =& get_instance();
		$CI->form_validation->set_message('is_valid', 'The %s field can not contain any spaces');
		return false;
	}
	
}