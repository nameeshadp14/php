-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 14, 2018 at 10:59 AM
-- Server version: 5.7.19
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dell_rmn`
--

-- --------------------------------------------------------

--
-- Table structure for table `rmn_asset_hearbeat`
--

DROP TABLE IF EXISTS `rmn_asset_hearbeat`;
CREATE TABLE IF NOT EXISTS `rmn_asset_hearbeat` (
  `hearbeatid` bigint(150) NOT NULL AUTO_INCREMENT,
  `asset_id` int(50) NOT NULL,
  `pingdatetime` datetime NOT NULL,
  `store_code` varchar(50) NOT NULL,
  `asset_service_tag` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`hearbeatid`),
  KEY `rmn_asset_hearbeat_fk_asset_id` (`asset_id`),
  KEY `rmn_asset_hearbeat_fk_store_code` (`store_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_asset_master`
--

DROP TABLE IF EXISTS `rmn_asset_master`;
CREATE TABLE IF NOT EXISTS `rmn_asset_master` (
  `asset_id` int(50) NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(50) NOT NULL,
  `asset_service_tag` varchar(50) DEFAULT NULL,
  `asset_reg_date` datetime DEFAULT NULL,
  `asset_expiry_date` datetime DEFAULT NULL,
  `asset_status` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive,2-Expired',
  `model_id` int(50) NOT NULL,
  `asset_store_id` int(50) NOT NULL,
  `raw_asset_id` int(50) NOT NULL,
  `asset_sessionguid` varchar(50) NOT NULL,
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`asset_id`),
  UNIQUE KEY `asset_sessionguid` (`asset_sessionguid`),
  KEY `rmn_asset_master_fk_model_id` (`model_id`),
  KEY `rmn_asset_master_fk_asset_store_id` (`asset_store_id`),
  KEY `rmn_raw_asset_master` (`raw_asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_brand_master`
--

DROP TABLE IF EXISTS `rmn_brand_master`;
CREATE TABLE IF NOT EXISTS `rmn_brand_master` (
  `brand_id` int(50) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(50) NOT NULL,
  `brand_status` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive',
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_city_master`
--

DROP TABLE IF EXISTS `rmn_city_master`;
CREATE TABLE IF NOT EXISTS `rmn_city_master` (
  `city_id` int(50) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  `reg_id` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '-1 Soft delete the record',
  PRIMARY KEY (`city_id`),
  KEY `rmn_city_master_fk_reg_id` (`reg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_group_master`
--

DROP TABLE IF EXISTS `rmn_group_master`;
CREATE TABLE IF NOT EXISTS `rmn_group_master` (
  `group_id` int(50) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_model_group_mapping`
--

DROP TABLE IF EXISTS `rmn_model_group_mapping`;
CREATE TABLE IF NOT EXISTS `rmn_model_group_mapping` (
  `mgm_mapping_id` int(50) NOT NULL AUTO_INCREMENT,
  `group_id` int(50) NOT NULL,
  `model_id` int(50) NOT NULL,
  PRIMARY KEY (`mgm_mapping_id`),
  KEY `rmn_model_group_mapping_fk_group_id` (`group_id`),
  KEY `rmn_model_group_mapping_fk_model_id` (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_model_master`
--

DROP TABLE IF EXISTS `rmn_model_master`;
CREATE TABLE IF NOT EXISTS `rmn_model_master` (
  `model_id` int(50) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(50) NOT NULL,
  `model_status` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive',
  `brand_id` int(50) NOT NULL,
  PRIMARY KEY (`model_id`),
  KEY `rmn_model_master_fk_brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_raw_asset_master`
--

DROP TABLE IF EXISTS `rmn_raw_asset_master`;
CREATE TABLE IF NOT EXISTS `rmn_raw_asset_master` (
  `raw_asset_id` int(50) NOT NULL AUTO_INCREMENT,
  `raw_asset_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`raw_asset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rmn_raw_asset_master`
--

INSERT INTO `rmn_raw_asset_master` (`raw_asset_id`, `raw_asset_name`) VALUES
(1, 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `rmn_region_master`
--

DROP TABLE IF EXISTS `rmn_region_master`;
CREATE TABLE IF NOT EXISTS `rmn_region_master` (
  `region_id` int(10) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(50) NOT NULL COMMENT 'North, South, East, West',
  `status` tinyint(1) DEFAULT '1' COMMENT '-1 Soft delete the record',
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_scheduler`
--

DROP TABLE IF EXISTS `rmn_scheduler`;
CREATE TABLE IF NOT EXISTS `rmn_scheduler` (
  `sch_id` int(50) NOT NULL AUTO_INCREMENT,
  `sch_name` varchar(50) NOT NULL,
  `region_id` int(50) NOT NULL,
  `brand_id` int(50) NOT NULL,
  `group_id` int(50) NOT NULL,
  `st_date` date DEFAULT NULL,
  `ed_date` date DEFAULT NULL,
  `is_prority` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_monday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_tuesday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_wednesday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_thursday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_friday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_saturday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `wk_sunday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-No,1-Yes',
  `sch_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-Active, 0-Inactive,2-expired',
  `is_sync_client` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-synced, 0-notsynced',
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`sch_id`),
  KEY `rmn_scheduler_fk_region_id` (`region_id`),
  KEY `rmn_scheduler_fk_brand_id` (`brand_id`),
  KEY `rmn_scheduler_fk_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_scheduler_playlist_mapping`
--

DROP TABLE IF EXISTS `rmn_scheduler_playlist_mapping`;
CREATE TABLE IF NOT EXISTS `rmn_scheduler_playlist_mapping` (
  `sch_playlist_map_id` int(50) NOT NULL AUTO_INCREMENT,
  `sch_id` int(50) NOT NULL,
  `playlist_id` int(50) NOT NULL,
  PRIMARY KEY (`sch_playlist_map_id`),
  KEY `rmn_scheduler_playlist_mapping_fk_sch_id` (`sch_id`),
  KEY `rmn_scheduler_playlist_mapping_fk_playlist_id` (`playlist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_store_master`
--

DROP TABLE IF EXISTS `rmn_store_master`;
CREATE TABLE IF NOT EXISTS `rmn_store_master` (
  `store_id` int(50) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(50) NOT NULL,
  `store_code` varchar(50) NOT NULL,
  `store_email` varchar(50) NOT NULL,
  `store_contact_name` varchar(50) DEFAULT NULL,
  `store_contact_email` varchar(50) DEFAULT NULL,
  `store_contact_number` bigint(12) NOT NULL,
  `store_type` tinyint(4) NOT NULL COMMENT 'DES,MBO,LFR',
  `region_id` int(50) NOT NULL,
  `store_address` text,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '-1 Soft delete the record',
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`store_id`),
  UNIQUE KEY `store_code` (`store_code`),
  KEY `rmn_store_master_fk_region_id` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_user`
--

DROP TABLE IF EXISTS `rmn_user`;
CREATE TABLE IF NOT EXISTS `rmn_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `role_id` int(10) NOT NULL,
  `is_active` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive',
  PRIMARY KEY (`user_id`),
  KEY `rmn_user_fk_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rmn_user`
--

INSERT INTO `rmn_user` (`user_id`, `email_id`, `password`, `name`, `role_id`, `is_active`) VALUES
(1, 'admin@baryons.net', 'e10adc3949ba59abbe56e057f20f883e', 'Admin', 1, 1),
(2, 'editor@baryons.net', 'e10adc3949ba59abbe56e057f20f883e', 'Editor', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rmn_user_role`
--

DROP TABLE IF EXISTS `rmn_user_role`;
CREATE TABLE IF NOT EXISTS `rmn_user_role` (
  `role_id` int(10) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rmn_user_role`
--

INSERT INTO `rmn_user_role` (`role_id`, `role_name`) VALUES
(1, 'Administrator'),
(2, 'Editor'),
(3, 'Viewer');

-- --------------------------------------------------------

--
-- Table structure for table `rmn_video_master`
--

DROP TABLE IF EXISTS `rmn_video_master`;
CREATE TABLE IF NOT EXISTS `rmn_video_master` (
  `video_id` int(50) NOT NULL AUTO_INCREMENT,
  `video_name` varchar(50) NOT NULL,
  `video_file` varbinary(50) NOT NULL,
  `video_status` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive',
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_video_playlist`
--

DROP TABLE IF EXISTS `rmn_video_playlist`;
CREATE TABLE IF NOT EXISTS `rmn_video_playlist` (
  `playlist_id` int(50) NOT NULL AUTO_INCREMENT,
  `playlist_name` varchar(50) NOT NULL,
  `playlist_status` tinyint(1) NOT NULL COMMENT '1-Active, 0-Inactive',
  `created_by` int(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` int(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`playlist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rmn_video_playlist_mapping`
--

DROP TABLE IF EXISTS `rmn_video_playlist_mapping`;
CREATE TABLE IF NOT EXISTS `rmn_video_playlist_mapping` (
  `video_playlist_mapping_id` int(100) NOT NULL AUTO_INCREMENT,
  `playlist_id` int(50) NOT NULL,
  `video_id` int(50) NOT NULL,
  PRIMARY KEY (`video_playlist_mapping_id`),
  KEY `rmn_video_playlist_mapping_fk_playlist_id` (`playlist_id`),
  KEY `rmn_video_playlist_mapping_fk_video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rmn_asset_hearbeat`
--
ALTER TABLE `rmn_asset_hearbeat`
  ADD CONSTRAINT `rmn_asset_hearbeat_fk_asset_id` FOREIGN KEY (`asset_id`) REFERENCES `rmn_asset_master` (`asset_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_asset_hearbeat_fk_store_code` FOREIGN KEY (`store_code`) REFERENCES `rmn_store_master` (`store_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_asset_master`
--
ALTER TABLE `rmn_asset_master`
  ADD CONSTRAINT `rmn_asset_master_fk_asset_store_id` FOREIGN KEY (`asset_store_id`) REFERENCES `rmn_store_master` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_asset_master_fk_model_id` FOREIGN KEY (`model_id`) REFERENCES `rmn_model_master` (`model_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_raw_asset_master` FOREIGN KEY (`raw_asset_id`) REFERENCES `rmn_raw_asset_master` (`raw_asset_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_city_master`
--
ALTER TABLE `rmn_city_master`
  ADD CONSTRAINT `rmn_city_master_fk_reg_id` FOREIGN KEY (`reg_id`) REFERENCES `rmn_region_master` (`region_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_model_group_mapping`
--
ALTER TABLE `rmn_model_group_mapping`
  ADD CONSTRAINT `rmn_model_group_mapping_fk_group_id` FOREIGN KEY (`group_id`) REFERENCES `rmn_group_master` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_model_group_mapping_fk_model_id` FOREIGN KEY (`model_id`) REFERENCES `rmn_model_master` (`model_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_model_master`
--
ALTER TABLE `rmn_model_master`
  ADD CONSTRAINT `rmn_model_master_fk_brand_id` FOREIGN KEY (`brand_id`) REFERENCES `rmn_brand_master` (`brand_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_scheduler`
--
ALTER TABLE `rmn_scheduler`
  ADD CONSTRAINT `rmn_scheduler_fk_brand_id` FOREIGN KEY (`brand_id`) REFERENCES `rmn_brand_master` (`brand_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_scheduler_fk_group_id` FOREIGN KEY (`group_id`) REFERENCES `rmn_group_master` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_scheduler_fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `rmn_region_master` (`region_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_scheduler_playlist_mapping`
--
ALTER TABLE `rmn_scheduler_playlist_mapping`
  ADD CONSTRAINT `rmn_scheduler_playlist_mapping_fk_playlist_id` FOREIGN KEY (`playlist_id`) REFERENCES `rmn_video_playlist` (`playlist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_scheduler_playlist_mapping_fk_sch_id` FOREIGN KEY (`sch_id`) REFERENCES `rmn_scheduler` (`sch_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_store_master`
--
ALTER TABLE `rmn_store_master`
  ADD CONSTRAINT `rmn_store_master_fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `rmn_region_master` (`region_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_user`
--
ALTER TABLE `rmn_user`
  ADD CONSTRAINT `rmn_user_fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `rmn_user_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rmn_video_playlist_mapping`
--
ALTER TABLE `rmn_video_playlist_mapping`
  ADD CONSTRAINT `rmn_video_playlist_mapping_fk_playlist_id` FOREIGN KEY (`playlist_id`) REFERENCES `rmn_video_playlist` (`playlist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rmn_video_playlist_mapping_fk_video_id` FOREIGN KEY (`video_id`) REFERENCES `rmn_video_master` (`video_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
