<?php
session_start();
spl_autoload_extensions(".php");
spl_autoload_register();
$app_url=application_url();

use pingidentity\opentoken\agent;
$myagent = new Agent();
$user_info=array();
# Use the read method to extract the token values
$myvalues = $myagent->readTokenFromHTTPRequest();
if ($myvalues)
{
   # Found some values – print each of them
   foreach ($myvalues as $key => $value)
   {     
	$user_info[$key]= $value ;
   }
   
   $user_id=$user_info['subject'];
   header("Location:$app_url/user?email=$user_id");

}
else
{
   # No values – print the error message
   echo "Error reading token: " . $myagent->lastError;
}
function application_url(){
	$protocol = 'https';
	$app_name=explode('/',$_SERVER['REQUEST_URI']);
    return $protocol. "://" .  $_SERVER['HTTP_HOST'].'/'.$app_name[1];
}
?> 