<?php
//$headers = get_headers("https://insight-dev.panda.org:444/gftn/");
//print_r($headers);
 $headers = apache_request_headers();

    foreach ($headers as $header => $value) {
        echo "$header: $value <br />\n";
    }