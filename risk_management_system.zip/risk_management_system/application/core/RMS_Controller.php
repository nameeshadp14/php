<?php

class RMS_Controller extends CI_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->helper('url');
		$this->load->library('session');
		$this->load->helper(array('form', 'url','custom_helper'));
		$this->load->library('form_validation');
		$this->load->library('template');
		//check the login redirection
		$this->isLogged=$this->session->userdata('rms_logged_in')?true:false;
		$this->isAdmin = $this->session->userdata('rms_urole_id') == "5" ? true : false;
		$this->isManager = $this->session->userdata('rms_urole_id') == "38" ? true : false;
		$this->isOwner = $this->session->userdata('rms_urole_id') == "39" ? true : false;
		$this->isUserID = $this->session->userdata('user_id');
		$this->isUserName = $this->session->userdata('user_name');
		$this->isOfficeID = $this->session->userdata('office_id');
		$this->isOfficeName = $this->session->userdata('office_name');
		
		/****Role list****/
		$this->riskEleId=3435;
		$this->riskRegisterEleId=3436;
		$this->departmentEleId=3437;
		$this->riskEffectEleId=3438;
		$this->riskSourceEleId=3439;
		$this->riskIndicatorEleId=3440;
		$this->riskRegisterMappingEleId=4435;
		$this->user_mang=3441;
		$this->report = 3442;
		//$this->deactivated=3443;
		if( $this->router->fetch_class()== "user") {
			if ($this->router->fetch_method() != "logout") {
				if ($this->session->userdata('rms_logged_in')) {
					redirect('/risk_register/risk_register_mapping');
				}
			}
		}else{
			if($this->session->userdata('rms_logged_in') !=1) {
				redirect('/user');
			}
		}
	
    }
}
