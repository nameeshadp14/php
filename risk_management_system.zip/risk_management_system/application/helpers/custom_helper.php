<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if ( ! function_exists('date_formate_ymd')){
	function date_formate_ymd($date){
		
		if($date!='')://echo $date;die;
			$date = str_replace('/', '-', $date);
			return date('Y-m-d', strtotime($date));
		else:
			return NULL;
		endif;

	}
}
if ( ! function_exists('date_formate')){
	function date_formate($date){
		if($date!=''){
			return date('d M Y',strtotime($date));
		}else{
			return NULL;
		}
		
	}
}

/***Add a color in risk Evaluation field based on the value*****/
if ( ! function_exists('classStyle')){
	function classStyle($id){
		switch ($id) {
			case 1:
				return 'background-color:red;width:100px';
			case 2:
				return 'background-color:rgb(255, 165, 0);width:66px;margin-left:0px';
			case 3:
				return 'background-color:green;width:33px;margin-left:34px';
			default:
				return 'background-color:transparent;width:0;margin-left:0px';
				break;
		}
		
	}
}


/*****Adding a class to text based on the risk value*****/
if ( ! function_exists('className')){
	function className($id){
		switch ($id) {
			case 3:
				return 'low';
			case 2:
				return 'medium';
			case 1:
				return 'high';
			default:
				return null;
				break;
		}

	}
}
/***risk calculation *****/
if ( ! function_exists('riskCalculation')){
	function riskCalculation($likehood,$impact){
		return ($likehood*$impact)+$impact;
	}
}
/*****risk evaluaion calculating****/
if ( ! function_exists('riskEvaluvation')){
	function riskEvaluvation($risk){
		if($risk==0){
			return null;
		}
		else if($risk<6){
			return 3;
		}else if($risk>=6 && $risk<=17){
			return 2;
		}
		else if($risk>=18){
			return 1;
		}
	}
}

