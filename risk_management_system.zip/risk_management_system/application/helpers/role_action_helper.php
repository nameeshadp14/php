<?php
 if (!defined('BASEPATH')) {
     exit('No direct script access allowed');
 }

if (!function_exists('action_authorization')) {
    function action_authorization($id, $action)
    {
    	//return true;
        $CI = &get_instance();
        $CI->load->library('session');
        $app_id = $CI->config->item('app_id');
        $CI->db->select($action);
        $CI->db->where('ELEMENT_ID', $id);
        $CI->db->where('APPLICATION_ID', $app_id);
        $CI->db->where('ROLE_ID', $CI->session->userdata('rms_urole_id'));
        $result = $CI->db->get('INSIGHT_ACTION')->row();
        if (count($result) == 0) {
            redirect('wwferror/access_denied');
        }else{
        	if($result->$action==0){
        		 redirect('wwferror/access_denied');
        	}else{
        		return true;
        	}
        }
    }
}

if (!function_exists('check_action_permission')) {
    function check_action_permission($id, $action)
    {
    	
        $CI = &get_instance();
        $CI->load->library('session');
        $app_id = $CI->config->item('app_id');
        $CI->db->select($action);
        $CI->db->where('ELEMENT_ID', $id);
        $CI->db->where('APPLICATION_ID', $app_id);
        $CI->db->where('ROLE_ID', $CI->session->userdata('rms_urole_id'));
        $result = $CI->db->get('INSIGHT_ACTION')->row();

        if (count($result) == 0) {
            return false;
        } else {
        	if($result->$action==0){
        		return false;
        	}else{
        		return true;
        	}
           
        }
    }
}

if (!function_exists('check_access_permission')) {
	function check_access_permission($id=null, $action)
	{//return true;
		$CI = &get_instance();
		$CI->load->library('session');
		if($CI->session->userdata('rms_urole_id')!=5){
			$CI->db->select($action);
			if($id!=null){
				$CI->db->where('RISK_REGISTER_ID', $id);
			}
			$CI->db->where('USER_ID', $CI->session->userdata('user_id'));
			$result = $CI->db->get('RMS_RISK_REGISTER_USER_MAPPING')->row();
			if (count($result) == 0) {
				return false;
			} else {
				if($result->$action==0){
					return false;
				}else{
					return true;
				}
				 
			}
		}else{
			return true;
		}
	}
}
if (!function_exists('curdActions')) {
    function curdActions($id)
    {
        $actionID = 0;
        $canView = 0;
        $canAdd = 0;
        $canEdit = 0;
        $canDelete = 0;
        $CI = &get_instance();
        $role_id = $CI->config->item('role_id');
        $app_id = $CI->config->item('app_id');
        $CI->db->select('*');
        $CI->db->where('ELEMENT_ID', $id);
        $CI->db->where('APPLICATION_ID', $app_id);
        $CI->db->where('ROLE_ID', $role_id);
        $result = $CI->db->get('INSIGHT_ACTION')->row();
        if (count($result) > 0) {
            $actionID = $result->ACTION_ID;
        }
        if (isset($result->CAN_VIEW) && $result->CAN_VIEW == 1) {
            $canView = 1;
        }
        if (isset($result->CAN_ADD) && $result->CAN_ADD == 1) {
            $canAdd = 1;
        }
        if (isset($result->CAN_EDIT) && $result->CAN_EDIT == 1) {
            $canEdit = 1;
        }
        if (isset($result->CAN_DELETE) && $result->CAN_DELETE == 1) {
            $canDelete = 1;
        }

        return $actionID.':'.$canView.':'.$canAdd.':'.$canEdit.':'.$canDelete;
    }
}
if (!function_exists('curdRRActions')) {
    function curdRRActions($rrid,$userid)
    {
        $rrMappingID = 0;
        $canView = 0;
        $canEdit = 0;
        $CI = &get_instance();
		$CI->db->select('*');
        $CI->db->where('RISK_REGISTER_ID', $rrid);
        $CI->db->where('USER_ID', $userid);
        $result = $CI->db->get('RMS_RISK_REGISTER_USER_MAPPING')->row();
        if (count($result) > 0) {
            $rrMappingID = $result->RISK_REGISTER_USER_MAPPING_ID;
        }
        if (isset($result->CAN_VIEW) && $result->CAN_VIEW == 1) {
            $canView = 1;
        }
        
        if (isset($result->CAN_EDIT) && $result->CAN_EDIT == 1) {
            $canEdit = 1;
        }
        

        return $rrMappingID.':'.$canView.':'.$canEdit;
    }
}
   