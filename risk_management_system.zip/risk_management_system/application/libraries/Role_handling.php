<?php 
class Role_handling{
		public function login_status(){
				if(isset($_SESSION['id'])){
					return true;
				}else{
					return false;
				}
		}
		public function role(){
			if(isset($_SESSION['role'])){
				switch ($_SESSION['role']) {
					case 1:
						return array(
						'isAdmin'=>true,
						'isManager'=>false,
						'isUser'=>false,
						'isSuperAdmin'=>false
						);
					case 2:
						return array(
						'isAdmin'=>false,
						'isManager'=>true,
						'isUser'=>false,
						'isSuperAdmin'=>false
						);
					case 3:
						return array(
						'isAdmin'=>false,
						'isManager'=>false,
						'isUser'=>true,
						'isSuperAdmin'=>false
						);
					case 4:
						return array(
						'isAdmin'=>false,
						'isManager'=>false,
						'isUser'=>false,
						'isSuperAdmin'=>true
						);
					default:
						return array(
						'isAdmin'=>false,
						'isManager'=>false,
						'isUser'=>true,
						'isSuperAdmin'=>false
						);						
				}
			}else{
				return array(
						'isAdmin'=>false,
						'isManager'=>false,
						'isUser'=>false,
						'isSuperAdmin'=>false
						);	
			}
		}
}?>