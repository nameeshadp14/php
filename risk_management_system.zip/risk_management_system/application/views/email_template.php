<div align="center" >
	<table align="center" border="1" cellpadding="0" cellspacing="0" width="600" style="border-collapse: collapse; font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;">
		<tr>
			<td width="260" valign="top">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr bgcolor="#fec761">
						
					</tr>
					
				</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#ffffff" style="padding: 40px 30px 0 30px;">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td style="padding: 5px 0 5px 5px;">
							Dear <b style="color:#EA5E2F"><?php echo $manager?> ,</b>
						</td>
					</tr>
					<tr>
						<td style="padding: 20px 8px 9px 8px;">
							<?php echo $message?>
							
						</td>
					</tr>
					
					<tr>
						<td>
							<table width="230" border="0" align="center" cellpadding="0" cellspacing="0" style="padding: 15px 0px 40px 0px;">
								<tbody>
									<tr style="height:3.75pt">
										<td align="center" style="background:#EA5E2F;padding:0px 0px 0px 0px;height:40px;font-size:15px;border:2px solid #d1d1d1;color:#ffffff;"><a href="<?php echo $url;?>">Click here to update <?php echo $audit_title?></a></td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					
					
					
				</table>
			</td>
		</tr>
		<tr style="background-color: #EEEEEE;">
			<td style="padding: 8px 0 0 34px;">
				<h5>Thanks,<br>Support Team</h5>
			</td>
		</tr>
		<tr>
			<td bgcolor="#EA5E2F" style="padding: 30px 30px 30px 30px;" align="center">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr >
						<td width="75%" style="color: #FFFFFF;">
							Copyright © 2018<br/>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</div>