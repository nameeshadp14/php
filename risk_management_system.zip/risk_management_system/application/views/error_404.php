<div class="row m_left m_right">
	<!-- left  Content Start -->
    <div class="col-md-12 p_left">
    	<div class="bg_white">
			<div class="err_404 ">
			
			<img src="<?php echo base_url().'assets/images/404_error.jpg';?>">
			
			</div>
    	</div>
		
	</div>
</div>