<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo 	base_url('assets/images/favicon.ico')?>" type="image/gif">
     <title><?php echo $title;?></title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/font-awesome.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fixedColumns.dataTables.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/editor.dataTables.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery.dataTables.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/buttons.dataTables.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/select.dataTables.min.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
    <!-- Custom CSS -->
 </head>
<body>
   <!-- Header -->
  <header>
    <div class="container-fluid ">
      <div class="logo col-md-3 p_left">
        <a href="<?php echo $this->config->item('landing_url'); ?>" >
        <img src="<?php echo base_url('assets/images/logo.jpg'); ?>" class="img-responsive" alt="logo" >
       
        <h5>
          Insight</h5>
        <h5>Risk Management System	</h5>
         </a>
      </div>
      	<?php if($this->isLogged){?>
       <div class="top_menu_hd col-md-7 p_left text-center">
		<ul class="list-unstyled list-inline">
			<?php if(check_action_permission($this->riskRegisterMappingEleId,'CAN_VIEW')){?>
				<li class="<?php if($this->uri->segment(2)=='risk_register_mapping' && $this->uri->segment(3)=='') echo "active"?>">
					<a href="<?php echo base_url('risk_register/risk_register_mapping'); ?>">Risk Register List</a>
				</li>
			<?php }
			/*if(check_action_permission($this->riskEleId,'CAN_VIEW')){?>
			 <li class="<?php if($this->uri->segment(2)=='risk') echo "active"?>">
					<a href="<?php echo base_url('risk_register/risk'); ?>">Risk List</a>
				</li>	
			<?php }*/
			 if(check_action_permission($this->departmentEleId,'CAN_VIEW') || check_action_permission($this->riskEffectEleId,'CAN_VIEW') || check_action_permission($this->riskSourceEleId,'CAN_VIEW') || check_action_permission($this->riskIndicatorEleId,'CAN_VIEW') || check_action_permission($this->user_mang,'CAN_VIEW') || check_access_permission('','CAN_VIEW')){?>
			<li class="sub-menu "><a href="#">Administration</a>
				<ul>
					<?php if(check_access_permission('','CAN_VIEW') || $this->isAdmin){?>			
						<li class="<?php if($this->uri->segment(2)=='risk_register') echo 'active'?>"><a href="<?php echo base_url('risk_register')?>">Risk Registers Administration</a></li>
					<?php }
					if(check_action_permission($this->departmentEleId,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(2)=='department_list') echo 'active'?>"><a href="<?php echo base_url('master/department_list')?>">Department</a></li>
					<?php }
					if(check_action_permission($this->riskEffectEleId,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(2)=='risk_effect_list') echo 'active'?>"><a href="<?php echo base_url('master/risk_effect_list')?>">Risk Effect</a></li>
					<?php }
					if(check_action_permission($this->riskSourceEleId,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(2)=='risk_source_list') echo 'active'?>"><a href="<?php echo base_url('master/risk_source_list')?>">Risk Source</a></li>
					<?php }
					
					if(check_action_permission($this->riskIndicatorEleId,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(2)=='risk_indicator_list') echo 'active'?>"><a href="<?php echo base_url('master/risk_indicator_list')?>">Key Risk Indicator</a></li>
					<?php }
					if(check_action_permission($this->user_mang,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(1)=='user_management') echo 'active'?>"><a href="<?php echo base_url('user_management')?>">User Management</a></li>
					<?php }
					if(check_action_permission($this->user_mang,'CAN_VIEW')){?>
						<li class="<?php if($this->uri->segment(3)=='deactivated') echo 'active'?>"><a href="<?php echo base_url('risk_register/risk_register_mapping/deactivated')?>">Deactivated Risk Registers</a></li>
					<?php }
					if(check_action_permission($this->user_mang,'CAN_VIEW')){?>
						<li class="<?php //if($this->uri->segment(3)=='deactivated') echo 'active'?>"><a href="<?php echo base_url('master/region_list')?>">Region Master</a></li>
					<?php }?>
				</ul>
			</li>
			<?php }
			if(check_action_permission($this->report,'CAN_VIEW')){?>			
			<li class="<?php if($this->uri->segment(1)=='reports') echo 'active'?>"><a href="<?php echo base_url('risk_register/risk'); ?>">Report</a></li>
			<?php }?>
		</ul>
	  </div>
      <div class="head_con col-md-2 p_right text-right">
      
        	<p><?php echo $this->isUserName?><a href="<?php echo base_url(); ?>user/logout" >Logout</a></p>
        
      </div>
      <?php }?>
    </div>
  </header>
