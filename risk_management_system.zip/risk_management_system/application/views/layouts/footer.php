 <footer>
    <div class="container-fluid">
      <div class="col-md-8 p_left">
        <ul class="list-unstyled list-inline">
          <li><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Legal Use</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4  text-right">
        <p>Copyright &copy; <?php echo date('Y');?></p>
      </div>
    </div>
  </footer>
    <!-- jQuery -->
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery-1.12.4.js');?>"></script> 
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>  
<script type='text/javascript' src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery.dataTables.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/dataTables.bootstrap.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/dataTables.buttons.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jszip.min.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/buttons.html5.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/select.js');?>"></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/dataTables.editor.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/dataTables.fixedColumns.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/buttons.colVis.min.js');?>"></script>

<script type='text/javascript' src="<?php echo base_url('assets/js/custom.js');?>"></script>
<input type="hidden" value="<?php echo base_url();?>" id="base_url">
	</body>

</html>
