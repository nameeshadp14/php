url = window.location.href;
base_url = $('#base_url').val();
var editor;
$(document).ready(function() {
    var base_url = $('#base_url').val();
    var master_table = $('.master_table').DataTable({
        aoColumnDefs: [{
            bSortable: false,
            aTargets: [0,-1]
        }]
    });
    
    
    var pathArray = window.location.pathname.split( '/' ); //to get the status from the url.
    var segment_3 = pathArray[4]; 
    var sts=1;
    if(segment_3=='deactivated'){
    	sts=0;
    }
    
    
    if ($('body').find('.master_table_rrr').length) {
        var master_table_rr = $('.master_table_rrr').DataTable({
			language: {
                processing: '<img src="' + base_url + 'assets/images/loading.gif">'
            },
            "processing": true,
            "serverSide": true,  
            
            //alert(sts);
            ajax: base_url + '/risk_register/ajax_rr_list/' + sts + "?" + location.search.substring(1),
            columns: [{
                    data: 'S_NO',orderable:false
                },
                {
                    data: 'RISK_REGISTER_NAME'
                },
                {
                    data: 'COUNTRY_NAME'
                },
                {
                    data: 'OFFICE_NAME'
                },
                {
                	data:'IS_CLOSED',
                	render: function(data, type, row, meta){
                		if(type === 'display'){
                			if(data==1){
                				data='<div>Closed</div>';
                			}
                			else{
                				data='<div>Opened</div>';
                			}
                		}
                		return data;
                	}
                },
                {
                    data: 'RISK_REGISTER_ID',
                    render: function(data, type, row, meta){
                        if(type === 'display'){
                        	if(window.location.href.indexOf("risk_register_mapping") > -1) {
                        		data = '<a href="'+base_url+'risk_register/risk_register_mapping_risk/' + data + '">View</a>';
                        	}else{
                        		data = '<a href="'+base_url+'risk_register/risk_register_edit/' + data + '">Edit</a>';
                        	}
                        }
                        
                        return data;
                    },orderable:false
                },
                
               /* {
                	data: 'RISK_REGISTER_ID',
                	 render: function(data, type, row, meta){
                		 if(type === 'display'){
                			 if(segment_3=='deactivated'){  //To check the status from the url.
                				 data = '<a   onclick="return activate();" href="'+base_url+'risk_register/risk_register_status_deactivated/' + data + '">Activate</a>';
 
                			 }
                			 else{ 
                    		     data = '<a  onclick="return deactivate()"  href="'+base_url+'risk_register/risk_register_status_update/' + data + '">Deactivate</a>';
 
                			 }
                				 
                		    
                		 }
                		 return data;
                	 },orderable:false
                },*/
            ],
            aoColumnDefs: [{
                bSortable: false,
                aTargets: [-1]
            }]
        });
    }
    
    
    if ($('body').find('.master_table_rr').length) {
        var master_table_rr = $('.master_table_rr').DataTable({
			language: {
                processing: '<img src="' + base_url + 'assets/images/loading.gif">'
            },
            "processing": true,
            "serverSide": true,  
            
            //alert(sts);
            ajax: base_url + '/risk_register/ajax_rr_list/' + sts + "?" + location.search.substring(1),
            columns: [{
                    data: 'S_NO',orderable:false
                },
                {
                    data: 'RISK_REGISTER_NAME'
                },
                {
                    data: 'COUNTRY_NAME'
                },
                {
                    data: 'OFFICE_NAME'
                },
                {
                	data:'IS_CLOSED',
                	render: function(data, type, row, meta){
                		if(type === 'display'){
                			if(data==1){
                				data='<div>Closed</div>';
                			}
                			else{
                				data='<div>Opened</div>';
                			}
                		}
                		return data;
                	}
                },
                {
                    data: 'RISK_REGISTER_ID',
                    render: function(data, type, row, meta){
                        if(type === 'display'){
                        	if(window.location.href.indexOf("risk_register_mapping") > -1) {
                        		data = '<a href="'+base_url+'risk_register/risk_register_mapping_risk/' + data + '">View</a>';
                        	}else{
                        		data = '<a href="'+base_url+'risk_register/risk_register_edit/' + data + '">Edit</a>';
                        	}
                        }
                        
                        return data;
                    },orderable:false
                },
               
                {
                	data: 'RISK_REGISTER_ID',
                	 render: function(data, type, row, meta){
                		 if(type === 'display'){
                			 if(segment_3=='deactivated'){  //To check the status from the url.
                				 data = '<a   onclick="return activate();" href="'+base_url+'risk_register/risk_register_status_deactivated/' + data + '">Activate</a>';
 
                			 }
                			 else{ 
                    		     data = '<a  onclick="return deactivate()"  href="'+base_url+'risk_register/risk_register_status_update/' + data + '">Deactivate</a>';
 
                			 }
                				 
                		    
                		 }
                		 return data;
                	 },orderable:false
                },
            ],
            aoColumnDefs: [{
                bSortable: false,
                aTargets: [-1]
            }]
        });
    }
    $('.role_table').DataTable({
        "ordering": false
    });
    

    if ($('body').find('.risk_list_add').length) {
        /******Datatable inline editor for list of risk******/
        var default_risk_effect = [];
        var default_risk_source = [];
        var default_likelihood = [];
        var default_impact = [];
        var default_movement_six_month_list = [];
        var default_key_risk_indicator=[];
        /*****Getting the master data******/
        $.getJSON(base_url + '/risk_register/master_json_data', function(data) {
            console.log(data);
            $.each(data, function(index) {
                if (index == 'risk_effect_list') {
                    default_risk_effect = data[index];
                } else if (index == 'risk_source_list') {
                    default_risk_source = data[index];
                } else if (index == 'likelihood_rating_list') {
                    default_likelihood = data[index];
                } else if (index == 'impact_rating_list') {
                    default_impact = data[index];
                } else if (index == 'movement_six_month_list') {
                    default_movement_six_month_list = data[index];
                } else if (index == 'key_risk_indicator') {
                	default_key_risk_indicator = data[index];
                }
               
            });
            editor.field('RISK_EFFECT_CATEGORY').update(default_risk_effect);
            editor.field('RISK_SOURCE_CATEGORY').update(default_risk_source);
            editor.field('GROSS_LIKELIHOOD_ID').update(default_likelihood);
            editor.field('NET_LIKELIHOOD_ID').update(default_likelihood);
            editor.field('GROSS_IMPACT_ID').update(default_impact);
            editor.field('NET_IMPACT_ID').update(default_impact);
            editor.field('SIX_MONTHS').update(default_movement_six_month_list);
            editor.field('RISK_KEY_INDICATOR_ID').update(default_key_risk_indicator);

        });

        /****Submitting the form inline*****/
        editor = new $.fn.dataTable.Editor({
            ajax: base_url + "/risk_register/update_risk",
            table: "#excel",
            processing: true,
            /****Below method used to submit the row data in inline editor****/
            formOptions: {
                inline: {
                    submit: 'allIfChanged'
                }
            },
            fields: [
				{
				    label: "No.",
				    name: "S_NO",
				},
                {
                    label: "Risk Name:",
                    name: "RISK_NAME",
                },
                {
                    label: "Process",
                    name: "PROCESS",
                },
                {
                    label: "Sub-process",
                    name: "SUBPROCESS"
                },
                {
                    label: "Risk Description",
                    name: "MOVEMENT_LAST_SIX_MONTHS_DESC",
                },
                {
                	label:"Risk Event",
                	name:"RISK_EVENT",
                },
                {
                    label: "Gross Likelihood",
                    name: "GROSS_LIKELIHOOD_ID",
                    type: "select",
                    ipOpts: default_likelihood
                },

                {
                    label: "Net Likelihood",
                    name: "NET_LIKELIHOOD_ID",
                    type: "select",
                    ipOpts: default_likelihood
                },
                {
                    label: "Gross Impact",
                    name: "GROSS_IMPACT_ID",
                    type: "select",
                    ipOpts: default_impact
                },

                {
                    label: "Net Impact",
                    name: "NET_IMPACT_ID",
                    type: "select",
                    ipOpts: default_impact
                },
                {
                    label: "Risk Effect:",
                    name: "RISK_EFFECT_CATEGORY",
                    type: "select",
                    "ipOpts": default_risk_effect
                }, 
                {
                    label: "Risk Source:",
                    name: "RISK_SOURCE_CATEGORY",
                    type: "select",
                    ipOpts: default_risk_source
                },
                {
                    label: "Gross Risk:",
                    name: "GROSS_RISK"
                },
                {
                    label: "Gross Evaluation:",
                    name: "RISK_EVALUATION_ID"
                },
                {
                	label:"Preventive Controls:",
                	name:"PREVENTIVE_CONTROLS"
                },
                {
                	label:"Detective Controls:",
                	name:"DETECTIVE_CONTROLS"
                },
                {
                	label:"Risk Treatment Action Plan:",
                	name:"RISK_TREATMENT_ACTION_PLAN"
                },
                {
                	label:"Key Risk Indicator",
                	name:"RISK_KEY_INDICATOR_ID",
                	type: "select",
                	ipOpts:default_key_risk_indicator
                },
                {
                    label: "Net Risk:",
                    name: "NET_RISK"
                },
                {
                    label: "Net Evaluation:",
                    name: "NET_EVALUATION_ID"
                },
                {
                    label: "Responsibility for risk and action plan",
                    name: "RESPONSIBILTY",
                },
                {
                    label: "Movement in last six months",
                    name: "SIX_MONTHS",
                    type: "select",
                    'ipOpts': default_movement_six_month_list
                }, {
                    label: "Implementation On",
                    name: "IMPLEMENTATION",
                    type: "datetime",
                    format: 'YYYY-MM-DD',
                }, {
                    label: "Edit",
                    name: "edit",
                }
            ]
        });
        /*****Displaying the list of risks****/
        var excelTable = $('#excel').DataTable({
			language: {
                processing: '<img src="' + base_url + 'assets/images/loading.gif">'
            },
            fixedColumns: {
                leftColumns: 1
            },
            "processing": true,
            "serverSide": true,
            "aLengthMenu": [[ 10, 25, 50, 100,500,1000], [ 10, 25, 50, 100,500,1000]],
            dom: "lBfrtip",
            scrollX: true,
            ajax: base_url + "/risk_register/list_editor_risk/" + $('#rr_id').val() + "?" + location.search.substring(1),
            columns: [
	            {
	            	data:'S_NO' ,orderable:false,
	            	className: "hideClick",
	            },
	             
                {
                    data: 'RISK_NAME'
                },
                {
                    data: 'PROCESS'
                },
                {
                    data: 'SUBPROCESS'
                },
                {
                	data:'MOVEMENT_LAST_SIX_MONTHS_DESC'
                },
                
                {
                	data:'RISK_EVENT'
                },
                {
                    data: "RISK_SOURCE_CATEGORY"
                },
                {
                    data: "RISK_EFFECT_CATEGORY"
                },
                {
                    data: "GROSS_LIKELIHOOD_ID",visible:false
                },
                {
                    data: "GROSS_IMPACT_ID",visible:false
                },
                {
                    data: "GROSS_RISK",
                    className: "hideClick"
                },
                {
                    data: "RISK_EVALUATION_ID",
                    className: "hideClick"
                },
                {
                	data: "PREVENTIVE_CONTROLS",
                },
                {
                	data: "DETECTIVE_CONTROLS",
                },
                {
                    data: "NET_LIKELIHOOD_ID",visible:false
                },
                {
                    data: "NET_IMPACT_ID",visible:false
                },
                {
                    data: "NET_RISK",
                    className: "hideClick"
                },
                {
                    data: "NET_EVALUATION_ID",
                    className: "hideClick"
                },
                {
                	data:"RISK_TREATMENT_ACTION_PLAN",
                },
                {
                    data: 'RESPONSIBILTY',
                },
                {
                    data: "IMPLEMENTATION",
                },
                {
                	data:"RISK_KEY_INDICATOR_ID",
                },
                {
                    data: "SIX_MONTHS",visible:false
                },
                {
                    data: "edit",orderable:false
                }
            ],
            order: [1, 'asc'],

            buttons: [{
                    extend: 'colvis',
                    className: 'btn btn-primary',
                    //columns: ':visible:not(:-child)'
                },
                {
                    extend: 'excel',
                    exportOptions: {
                        modifier: {
                            search: 'applied'
                        }
                    },
                    text: 'Export Risk Results',
                    className: 'btn btn-primary',
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                }
            ]
        });

        /****Validating the fields while editing****/
        editor.on('preSubmit', function(e, o, action) {
            if (action !== 'remove') {
                var RISK_NAME = this.field('RISK_NAME');
                var PROCESS = this.field('PROCESS');
                var SUBPROCESS = this.field('SUBPROCESS');
                if (!RISK_NAME.isMultiValue()) {
                    if (!RISK_NAME.val()) {
                        RISK_NAME.error('Risk name required');
                    }
                }
                if (!PROCESS.isMultiValue()) {
                    if (!PROCESS.val()) {
                        PROCESS.error('Process required');
                    }
                }
                if (!SUBPROCESS.isMultiValue()) {
                    if (!SUBPROCESS.val()) {
                        SUBPROCESS.error('sub process required');
                    }
                }
                if (this.inError()) {
                    return false;
                }
            }
        });
        /****Enabling the editor ***/
        $('#excel').on('click', 'tbody tr td:not(:last-child)', function(e) {
            editor.inline(this, {
                submitOnBlur: true
            });

        });
        $('#excel').on('click', 'tbody tr td:first-child', function(e) {
            editor.inline(this, {
                submitOnBlur: true
            });

        });
    }
   
});


/***Menu active class**/
$('body header ul li a').each(function() {
    let href = $(this).attr('href');
    if (href == url) {
        $(this).parent().addClass('active');
        $(this).parent().parent().parent().addClass('active');
    }
})


/***Datepicker***/

$('body').on('focus', ".impt_date", function() {
    $(this).datepicker({
        dateFormat: 'dd/mm/yy',
        changeMonth: true,
        changeYear: true,
        yearRange: "-100:+0",
    })
});



var login = $("#login").validate({
    rules: {
        email: {
            required: true,
            email: true
        },
        pass_word: "required"
    },
    messages: {
        email: "Please enter a valid email address",
        pass_word: "Please enter a valid password"
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }
});

/********************** Risk form validation*********************/
$("#risk_rgst").validate({
    rules: {
        rregister: {
            required: true,
            remote: {
                url: '/risk_management_system/risk_register/ajax_risk_register',
                type: "post",
                data: {
                    risk_rgst_id: $('#risk_rgst_id').val(),
                    rregister: function() {
                        return $('#rregister').val();
                    }
                }
            }
        },
        rcountry: {
            required: true
        },
        rofc: {
            required: true
        }
    },
    messages: {
        rregister: {
            required: "Please Enter Risk Register Name",
            remote: "Entered value already Exits"
        },
        rcountry: {
            required: "Please select a country"
        },
        rofc: {
            required: "Please select a office"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");

    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

})
/********************** Risk form validation*********************/

/******Risk Register Blick upload****************/

$("#bluckupoad").validate({
    rules: {
        risk_register: {
            required: true,
        }
    },
    messages: {
        rregister: {
            required: "Please Enter Risk Register Name",
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");

    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

})

//**********************Risk Register Bluck Upload********************/

/********************** Risk form validation*********************/
$("#risk").validate({
    ignore: false,
    rules: {
        rname: {
            required: true,
        },
        rdentified: {
            required: true,
        },
        rprocess: {
            required: true,
        },
        rsprocess: {
            required: true,
        },
        rowner: {
            required: true,
        },
        office: {
            required: true,
        },
        dept: {
            required: true,
        },
        rregister: {
            required: true,
        },
        rievent: {
            required: true,
        },
        risource: {
            required: true,
        },
        rieffect: {
            required: true,
        },
        pcontrol:{
        	required: true,
        },
        dcontrol:{
        	required: true,
        },
    },
    submitHandler: function(form, e) {
        var val = '';
        $('.ech_lp').each(function() {
            if ($(this).find('.trt_act_plan').val() == '' && $(this).find('.imp_status').val() != '') {

                val = 1;
                $(this).find('.trt_act_plan').after('<em id="dept-error" class="error help-block">This field is required.</em>');
            }
            if ($(this).find('.trt_act_plan').val() != '' && $(this).find('.imp_status').val() == '') {
                val = 1;
                $(this).find('.imp_status').after('<em id="dept-error" class="error help-block">This field is required.</em>');
            }
        });
        if (val == '') {
            return true;
        } else {
            if (!$('#advance_fields').hasClass('in')) {
                $('.panel-title a').click();
            }
            val = '';
            return false;
        }

    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");


    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

})
/********************** Risk form validation*********************/



jQuery.validator.addMethod("NoSpace", function(value, element) {
    return !value.startsWith(" ") && value != "";
}, "No space allowed");
/*********************Start Risk Effect master validation**********************/
$("#risk_effect_master").validate({
    rules: {
        eft_cat: {
            required: true,
            NoSpace: true,
            remote: {
                url: '/risk_management_system/master/ajax_risk_effect',
                type: "post",
                data: {
                    rsk_eft_id: $('#rsk_eft_id').val(),
                    eft_cat: function() {
                        return $('#eft_cat').val();
                    }
                }
            }
        }
    },
    messages: {
        eft_cat: {
            required: "Please Enter Risk Effect category",
            remote: "Enter value already Exits"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

});
/*********************End Risk Effect master validation**********************/


/*********************Start of Region master validation**************************NAMEESHA*********************************/
$("#region_master").validate({
    rules: {
        reg_name: {
            required: true,
            NoSpace: true,
            /*remote: {
                url: '/risk_management_system/master/ajax_risk_effect',
                type: "post",
                data: {
                	reg_id: $('#reg_id').val(),
                	reg_name: function() {
                        return $('#reg_name').val();
                    }
                }
            }*/
        },
        'reg_offc[]': {
			required: true,
			needsSelection:true,
		},
    },
    ignore: ':hidden:not("#reg_offc")', // Tells the validator to check the hidden select

    messages: {
    	reg_name: {
            required: "Please Enter Region Name",
           // NoSpace:"Space is not allowed",
            remote: "Entered value already Exits"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

});

/*********************Start of Region master validation***********************************************************/


/*********************Start Risk Source master validation**********************/
$("#risk_source_master").validate({

    rules: {
        rsk_src: {
            required: true,
            NoSpace: true,
            remote: {
                url: '/risk_management_system/master/ajax_risk_source',
                type: "post",
                data: {
                    rsk_src_id: $('#rsk_src_id').val(),
                    rsk_src: function() {
                        return $('#rsk_src').val();
                    }
                }
            }
        }
    },
    messages: {
        rsk_src: {
            required: "Please Enter Risk Source category",
            remote: "Enter value already Exits"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

});
/*********************End Risk source master validation**********************/


/*********************Start Risk Control master validation**********************/
$("#risk_control_master").validate({
    rules: {
        rsk_cntrl: {
            required: true,
            NoSpace: true,
            remote: {
                url: '/risk_management_system/master/ajax_risk_control',
                type: "post",
                data: {
                    rsk_cntrl_id: $('#rsk_cntrl_id').val(),
                    rsk_cntrl: function() {
                        return $('#rsk_cntrl').val();
                    }
                }
            }
        }
    },
    messages: {
        rsk_cntrl: {
            required: "Please enter Control Name",
            remote: "Already data exits for selected combination"
        },
        rsk_cntrl_type: {
            required: "Please enter Control Type",
            remote: "Already data exits for selected combination"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

});
/*********************End Risk Control master validation**********************/

/*********************Start Risk Source master validation**********************/
$("#risk_indicator_master").validate({

    rules: {
        rsk_indicator: {
            required: true,
            NoSpace: true,
            remote: {
                url: '/risk_management_system/master/ajax_risk_indicator',
                type: "post",
                data: {
                    rsk_indicator_id: $('#rsk_indicator_id').val(),
                    rsk_indicator: function() {
                        return $('#rsk_indicator').val();
                    }
                }
            }
        }
    },
    messages: {
        rsk_indicator: {
            required: "Please Enter Key Indicator",
            remote: "Enter value already Exits"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }

});
/*********************End Risk source master validation**********************/

//Clone the controls

$("#add_cntrl").on('click', function() {
    ln = $('.cntr_clone .row').length + parseInt(1);
    pcontrol = '<div class="col-md-5 form-group"><label>Controls</label><input type="text" class="form-control" placeholder="Preventive Controls" name="pcontrol[' + ln + ']"></div>';
    dcontrol = '<div class="col-md-5 form-group"><label></label><input type="text" class="form-control" placeholder="Detective and Reactive Controls" name="dcontrol[' + ln + ']"></div>';
    del = '<div  class="col-md-1 del_reco"><i class="glyphicon glyphicon-trash"></i></div>';
    $('.cntr_clone .add_ht_cnt').append('<div class="row m_left m_right ">' + pcontrol + dcontrol + del + '</div>');
})



//Clone the controls

$("#key_risk_indicator").on('click', function() {
	var base_url=$('#base_url').val();
    $.ajax({
        url: base_url + 'master/ajax_indicator',
        type: 'post',
        dataType: 'json',
        success: function(data) {
            //ln=$('.krap_cln .col-md-4').length+$('.add_div .col-md-5').length;
            indicator = htmlCreate(data, 'Key Risk Indicator', 'krindcator[]', 2, 'p_left');
            del = '<div  class="col-md-1 del_reco"><i class="glyphicon glyphicon-trash"></i></div>';
            $('.add_div').append(indicator + del);
        }
    })
})

function htmlCreate(data, labelName, inputName, forOP, className) {
    var output = '<div class="col-md-5 form-group ' + className + '"><label>' + labelName + '</label><select name="' + inputName + '" class="form-control"><option value="">---Select Here---</option>';
    var html = $.map(data, function(lcn) {
        if (forOP == 1) {
            return ('<option value="' + lcn.RISK_CONTROL_ID + '">' + lcn.CONTROL_TYPE + '</option>');
        } else {
            return ('<option value="' + lcn.RISK_KEY_INDICATOR_ID + '">' + lcn.RISK_KEY_INDICATOR_DESC + '</option>');
        }

    }).join('');
    return output + html + '</select></div>';
}
$('.b_btm').on('click', '.del_reco i', function() {
    var id = $(this).parent().parent().attr('id');
    if (id == 'dl_ic') {
        $(this).parent().prev().detach();
        $(this).parent().detach();

    } else {
        $(this).parent().parent().detach();
    }
    //	$(this).parent().parent().detach();
});

/*****************************Start User Role Management *****************************/
$("#usr_dtl_form").validate({
    rules: {
        uemail: {
            required: true,
            email: true
        }

    },
    message: {
        uemail: {
            required: "Please enter email id",
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }
});

$("#add_role").validate({
    rules: {
        office: {
            required: true
        },
        role: {
            required: true
        }

    },
    message: {
        office: {
            required: "Please Select a office",
        },
        role: {
            required: "Please select a Role",
        }
    },
    submitHandler: function(form, e) {
        e.preventDefault();
        var office_id = $("#office_id").val();
        var role_id = $(".role_usr").val();

        var office = $("#office_id option:selected").html();
        var role = $(".role_usr option:selected").html();
        data = $('.role_table tbody').find('td:contains(' + office + ')').parent();

        td = [];
        for (i = 0; i < data.length; i++) {
            td.push(data[i].cells[1].innerText) //to get the 2nd td text for selected office if exits
        }
        if ($.inArray(role, td) !== -1) {
            $('#err_msg').html('<div class="error_msg"><p class="m_bottom">Selected office & role are already added.</p></div>');
        } else {
            $('#err_msg').html(' ');
            appendTd(office, role, office_id, role_id);
        }
        $("#office_id").val('');
        $(".role_usr").val('');
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }
});
$('#rol_tb').validate({
    submitHandler: function(form, e) {
        var base_url = $('#base_url').val();
        //	alert(base_url);return false;
        e.preventDefault();
        var form_data = $('#rol_tb').serialize();
        $.ajax({
            url: $('#rol_tb').attr('action'),
            type: 'POST',
            data: form_data,
            success: function(data) {
                if (data > 0) {
                    window.location.href = base_url + 'user_management/user_roles/' + data;
                    //$('#err_msg').html('<div class="success_msg"><p class="m_bottom">Selected Role assigned to to user</p></div>');

                } else {
                    $('#err_msg').html('<div class="error_msg"><p class="m_bottom">Something went wrong please try after some time</p></div>');
                }
            }
        })
    }
})
/***Department Master form validation ***/

$("#department").validate({
    rules: {
        dept_name: {
            required: true,
            remote: {
                url: '/risk_management_system/master/ajax_department',
                type: "post",
                data: {
                    dept_id: $('#dept_id').val(),
                    dept_name: function() {
                        return $('#dept_name').val();
                    }
                }
            }
        }

    },
    messages: {
        dept_name: {
            required: "Please enter Department  name",
            remote: "This Department name alredy exits"
        }
    },
    errorElement: "em",
    errorPlacement: function(error, element) {
        // Add the `help-block` class to the error element
        error.addClass("help-block");

        if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
        } else {
            error.insertAfter(element);
        }
    },
    highlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-error").removeClass("has-success");

    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).parents(".col-sm-5").addClass("has-success").removeClass("has-error");
    }
});
/***Department Master form validation ***/
$('.role_usr').on('change', function() {
    var val = $(this).val();

    if (val == 5) {
        var primary_office = $('#prm_ofc_id').val();
        $('#office_id').val(primary_office);
        $('#office_id').parent().addClass('rm_pnt');
    } else {
        $('#office_id').parent().removeClass('rm_pnt');
    }
})

/*************************Start of append td at the last*****************************/
function appendTd(office, role, office_id, role_id) {
    office_td = office + '<input type="hidden" name="office_nm[]" value="' + office_id + '">';
    role_td = role + '<input type="hidden" name="role_nm[]" value="' + role_id + '">';
    role_app_id = '<input type="hidden" name="app_role_id[]" value="0">'
    var delet = '<svg class="rm_rol_td" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 459 459" style="enable-background:new 0 0 459 459;" xml:space="preserve"><path d="M76.5,408c0,28.05,22.95,51,51,51h204c28.05,0,51-22.95,51-51V102h-306V408z M408,25.5h-89.25L293.25,0h-127.5l-25.5,25.5    H51v51h357V25.5z"></path></svg>'
    var table = $('.role_table').DataTable();
    table.row.add([office_td, role_td, delet + role_app_id]).draw(false);
    table.order([1, 'asc']).draw();
    table.page('last').draw(false);
    //$('.role_table').DataTable().row.add().draw('false');
}


/*************************end of append td at the last*****************************/

/********Delete a role form table*******************/
$('.role_table').on('click', '.rm_rol_td', function() {
    var table = $('.role_table').DataTable();
    $this = $(this);
    $('#confirm').modal({
            backdrop: 'static',
            keyboard: false
        })
        .one('click', '#delete', function(e) {
            table
                .row($this.parents('tr'))
                .remove()
                .draw();
            $(this).next().click();
        });
})

/********Delete a role form table*******************/

function SetSingleView(checkedValue, elemID) {
    if (checkedValue) {
        var elem = $("#" + elemID + "V");
        elem.prop('checked', true);
    }
    checkAllCheckbox();
}

function SetAllView(checkedValue, valueToCheck) {
    var elemID;
    if ((valueToCheck == 'v') && (!checkedValue)) {
        var allowedUncheck = true;
        $('input[type=checkbox]').each(function() {
            elemID = $(this).attr('id');
            console.log(elemID);
            if (elemID) {
                if ((elemID != "CanView") && (elemID != "CanAdd") && (elemID != "CanEdit") && (elemID != "CanDelete")) {
                    //alert(elemID.toLowerCase().indexOf('a'));
                    if (elemID.toLowerCase().indexOf('a') >= 0) {
                        if ($(this).is(":checked")) {
                            allowedUncheck = false;
                        }
                    }
                    if (elemID.toLowerCase().indexOf('e') >= 0) {
                        if ($(this).is(":checked")) {
                            allowedUncheck = false;
                        }
                    }
                    if (elemID.toLowerCase().indexOf('d') >= 0) {
                        if ($(this).is(":checked")) {
                            allowedUncheck = false;
                        }
                    }
                }
            }

        });
        if (!allowedUncheck) {
            $("#CanView").prop('checked', true);
            alert("You cannot uncheck View if Add/Edit/Delete is checked");
            return;
        }
    }
    $('input[type=checkbox]').each(function() {
        elemID = $(this).attr('id');
        //  alert(elemID);
        if (elemID) {
            if ((elemID != "CanView") && (elemID != "CanAdd") && (elemID != "CanEdit") && (elemID != "CanDelete")) {
                if (elemID.toLowerCase().indexOf(valueToCheck) >= 0) {
                    if (checkedValue) {
                        $(this).prop('checked', true);
                    } else {
                        $(this).prop('checked', false);
                    }
                }
            }
        }


    });

    if (checkedValue) {
        if (valueToCheck == 'v') {
            $("#CanView").prop('checked', true);
        } else {
            SetAllView(checkedValue, 'v')
        }
    }
}


function CheckCheckedValue(checkedValue, elemID) {
    if (!checkedValue) {
        var elemAdd = $("#" + elemID + "A");
        var elemEdit = $("#" + elemID + "E");
        var elemDelete = $("#" + elemID + "D");
        var elemView = $("#" + elemID + "V");
        var elemChecked = false;

        if (elemAdd.is(":checked")) {
            elemChecked = true;
        }
        if (elemEdit.is(":checked")) {
            elemChecked = true;
        }
        if (elemDelete.is(":checked")) {
            elemChecked = true;
        }
        if (elemChecked) {
            elemView.prop('checked', true);
            alert("You cannot uncheck View if Add/Edit/Delete is checked");
        }
    }
}

/**********************Search Role actions for a role************************/
$('#srch_btn').on('click', function() {
    var role = $('#role_act').val();
    var page = $('#page').val();
    var spage = $('#sub-page').val();
    var base_url = $('#base_url').val();
    $.ajax({
        url: base_url + 'user_management/ajax_role_action',
        type: 'GET',
        data: {
            role_act: role,
            page: page,
            spage: spage
        },
        success: function(data) {
            $('.tbl_data').html(data);
            checkAllCheckbox();
        }
    })
})

/*************Check Parent Checkbox of column **********************/

function checkAllCheckbox() {
    var checkAllView = true;
    var checkAllAdd = true;
    var checkAllEdit = true;
    var checkAllDelete = true;
    $('tbody input[type=checkbox]').each(function() {
        elemID = $(this).attr('id');
        if (elemID.toLowerCase().indexOf('v') >= 0 && checkAllView) {
            if ($(this).is(":checked")) {
                checkAllView = true;
            } else {
                checkAllView = false;
            }
        }
        if (elemID.toLowerCase().indexOf('a') >= 0 && checkAllAdd) {
            if ($(this).is(":checked")) {
                checkAllAdd = true;
            } else {
                checkAllAdd = false;
            }
        }
        if (elemID.toLowerCase().indexOf('e') >= 0 && checkAllEdit) {
            if ($(this).is(":checked")) {
                checkAllEdit = true;
            } else {
                checkAllEdit = false;
            }
        }
        if (elemID.toLowerCase().indexOf('d') >= 0 && checkAllDelete) {
            if ($(this).is(":checked")) {
                checkAllDelete = true;
            } else {
                checkAllDelete = false;
            }
        }
    });
    $("#CanView").prop('checked', checkAllView);
    $("#CanAdd").prop('checked', checkAllAdd);
    $("#CanEdit").prop('checked', checkAllEdit);
    $("#CanDelete").prop('checked', checkAllDelete);
}
/****User Management***/
$('#gimpact, #glikelihood , #nlikelihood, #nimpact').on('change', function() {
    var id = $(this).attr('id');
    calculateRisk(id);
})


function calculateRisk(id) {
    var evl_hdn = '';
    var gn = '#' + id.charAt(0);
    var likelihood = $(gn + 'likelihood').val();
    var impact = $(gn + 'impact').val();
    if (likelihood != '' && impact != '') {
        var risk = (likelihood * impact) + parseInt(impact);
        $(gn + 'risk').val(risk);
        $(gn + 'mtr #pass_type').removeClass();
        $(gn + 'reval').val(risk);
        if (risk == 0) {
            $(gn + 'mtr #rsk_ev').css({
                "background-color": "transparent",
                "width": "0"
            });
        } else if (risk < 6) {
            evl_hdn = 3;
            $(gn + 'mtr #pass_type').addClass('low');
            $(gn + 'mtr #meter').css({
                "background-color": "green",
                "width": "33px",
                "margin-left": "34px"
            });
        } else if (risk >= 6 && risk <= 17) {
            evl_hdn = 2;
            $(gn + 'mtr #pass_type').addClass('medium');
            $(gn + 'mtr #meter').css({
                "width": "66px",
                "background-color": "rgb(255, 165, 0)",
                "margin-left": "0px"
            });
        } else if (risk >= 18) {
            evl_hdn = 1;
            $(gn + 'mtr #pass_type').addClass('high');
            $(gn + 'mtr #meter').css({
                "background-color": "red",
                "width": "100px",
                "margin-left": "0px"
            });

        }
    } else {
        evl_hdn = '';
        $('#reval').val('');
        $(gn + 'risk').val('');
        $(gn + 'mtr #pass_type').removeClass();
        $(gn + 'mtr #meter').css({
            "background-color": "transparent",
            "width": "0"
        });
    }
    $(gn + 'reval_hdn').val(evl_hdn);
}
/***************Risk Calculation*****************/

/*****Info for I symbol**********/



$('.glyphicon-info-sign').on('click', function() {
    var i = $(this).attr('data-target');
    $('.hide_info , .glyphicon-triangle-top').hide();
    $(i + 'hover_show').show();
    $(i + 'arrow').show();
    $('.row').removeClass('info_i');
    $(this).closest('.row').addClass('info_i');
})
$('.hide_i').on('click', function() {
    $('.hide_info, .glyphicon-triangle-top').hide();
    $('.row').removeClass('info_i');
})

/************Adding Risk action treatment plan**********************/
$('#rsk_act_pn').on('click', function() {
    var base_url = $('#base_url').val();
    $.ajax({
        url: base_url + 'risk_register/action_plan',
        success: function(data) {
            $('.arsk_act').append(data);
        }
    })
})



/****Risk register user action********/
$('#rgs_act_id').on('click', function() {
    var role = $('#role_act').val();
    var risk_reg = $('#risk_reg').val();
    var office= $('#office_1').val();  //To add Office filter.
    var user = $('#users').val();
    var base_url = $('#base_url').val();
    $.ajax({
        url: base_url + 'user_management/ajax_rr_role_action',
        type: 'GET',
        data: {
            role_act: role,
            risk_reg: risk_reg,
            ofc:office,
            user: user
        },
        success: function(data) {
            $('.tbl_data').html(data);
            checkAllCheckbox();
        }
    })
})

$('#office_1').on('change',function(){//alert('helo');
	var base_url = $('#base_url').val();
	
    $.ajax({
        url: base_url + 'user_management/user_for_region',
        type: 'GET',
        data: {
        	office_id:$('#office_1').val(),
        },
        success: function(data) {
            $('#users').append(data);
        }
    })
	
	 
})

//Function to show pop-up for confirmation of Activate and deactivate risk register. 
function activate(){
	var act=confirm('Do you want to Activate the Risk Register!!!');
	//event.defaultprevent();
	if(act==true){
		return true;
	}
	else{
		return false;
	}
		
  }
function deactivate(){
	var deact=confirm('Do you want to Deactivate the Risk Register!!!');
	//event.defaultprevent();
	if(deact==true){
		return true;
	}
	else{
		return false;
	}

}

//Conffirmation box for delete data	
$(".remove_data").on('click',function(e){//debugger;
    e.preventDefault();
    var link = $(this).attr('href');
	bootbox.confirm({
	    message: "Do you want delete this data?",
	    buttons: {
	        confirm: {
	            label: 'Confirm',
	            className: 'btn-success'
	        },
	        cancel: {
	            label: 'Cancel',
	            className: 'btn-danger'
	        }
	    },
	    callback: function (result) {
	        if(result==true){
	        	window.location.href = link;
	        }
	    }
	});
});
